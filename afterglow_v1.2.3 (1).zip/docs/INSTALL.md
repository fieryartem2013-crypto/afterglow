# AfterGlow — установка (v1.2.0)

## 1. Раскладка папок
Скопируйте **содержимое** `garrysmod/` из архива в ваш серверный `garrysmod/`:

- `gamemodes/helix` → фреймворк (не обновляйте вручную — см. PINNED.txt)
- `gamemodes/afterglow` → схема
- `addons/afterglow` → SWEP/энтити
- `cfg/*` → примеры конфигов (подставьте hostname/rcon/работshop-коллекцию)

## 2. Конфигурация
`cfg/server.cfg`:
```
hostname "AfterGlow | City-17 / Quarantine Zone | Helix"
gamemode afterglow
```
База данных: Helix по умолчанию SQLite — для продакшена настройте MySQL
в `gamemodes/helix/gamemode/config/sv_mysql.lua` (или через mysql-модуль).

## 3. Первый вход
1. Запустите сервер картой City-17-подобной (rp_city17, c17 или своя).
2. Зайдите игроком — откроется **AGCharMenu**: «+ НОВЫЙ ГРАЖДАНИН».
3. После входа в консоль сервера выдайте себе маршалла:
   ```
   lua_run local p=player.GetBySteamID("STEAM_0:x:xxxxx")
           local pl=ix.plugin.Get("20_ag_admin")
           pl.groups = pl.groups or ix.data.Get("ag_groups", {}, true, true) or {}
           pl.groups[p:SteamID64()]="marshall" pl:SaveGroups()
           p:SetNetVar("agGroup","marshall")
   ```
   (Или вставьте в `garrysmod/lua/autorun/server/ag_owner.lua` одноразовый скрипт
    выдачи по SteamID64 — пример ниже.)

### ag_owner.lua (пример разовой выдачи)
```lua
hook.Add("PlayerInitialSpawn", "AGOwnerGrant", function(ply)
    local SID = ply:SteamID64()
    if (SID ~= "76561198000000000") then return end -- ← ваш SteamID64
    timer.Simple(3, function()
        local pl = ix.plugin.Get("20_ag_admin")
        pl.groups = pl.groups or ix.data.Get("ag_groups", {}, true, true) or {}
        pl.groups[SID] = "marshall"
        pl:SaveGroups()
        ply:SetNetVar("agGroup", "marshall")
        ply:Notify("Вам выдан ранг: MARSHALL")
    end)
end)
```

## 4. Проверка
- `TAB` / `F1` → единое меню AfterGlow (не ixMenu).
- У стаффа: вкладка **ТИКЕТЫ**, ESP в noclip (опция в настройках меню).
- `/aggroups` в консоли → таблица 21 ранга.

## 5. Обновление с v1.0.0
Архив v1.2.0 — полная замена: удалите старые `gamemodes/afterglow|hlarp`
и `addons/...` и раскатайте заново. Данные персонажей (SQLite/MySQL) совместимы.
