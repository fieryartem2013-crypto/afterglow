# AfterGlow UI (00_ag_ui) — API компонентов

HL:A-стиль: тёмные панели, блюр, неон (cyan #00D4FF), сканлайны,
tech-уголки. Всё в неймспейсе `ix.ag`.

## Палитра `ix.ag.C`
`bg bgPanel bgPanelLite stroke neon neonSoft amber green violet red
text textDim textMute` + `ix.ag.Hex("#RRGGBB")`.

## Компоненты (vgui)
| Имя | Назначение |
|-----|-----------|
| AGPanel | Панель: блюр, кромка, уголки. SetEdgeColor(color); хуки `DoCustom(w,h)`, `PaintOver(w,h)` |
| AGFrame | Дочь AGPanel — окно с заголовком SetTitle и крестиком |
| AGButton | Кнопка: SetVariant(primary/ghost/danger/amber/green), SetFont, SetIcon(Material), `PaintOver(w,h)` |
| AGScrollPanel | Скролл с стилиз. полосой |
| AGToggle | Чек: SetLabel, SetChecked, OnChange(state) |
| AGNumSlider | Слайдер: SetRange(min,max,val,decimals), SetLabel, OnValueChanged(v) |
| AGProgressBar | Шкала: SetLabel, SetColor, SetFraction; `bar.live = fn` — автообновление |
| AGModelView | 3D-превью: ShowModel(path), SetFOV(n); вращение ЛКМ, зум колесом |
| AGTooltip | инфо-карта |
| AGPrompt | модал ввода |

## Функции
```lua
ix.ag.DrawBlur(panel, amount)          -- блюр под панелью (+scissor)
ix.ag.DrawShadow(x,y,w,h)              -- мягкая тень (BSHADOWS или fallback)
ix.ag.DrawTechCorners(x,y,w,h,len,th,col)
ix.ag.DrawNeonEdge(x,y,w,col,alpha)
ix.ag.DrawScanlines(x,y,w,h,gap)
ix.ag.WrapText(text, font, maxW)       -- перенос строк
ix.ag.FormatTime(sec)
ix.ag.Dampen(speed, cur, target)       -- плавная интерполяция
ix.ag.DampenColor(speed, c1, c2)
ix.ag.Click(bHoverOnly)                -- UI-звук (опция agMenuSounds)
ix.ag.ShowTooltip(title,col) → tip     -- tip:AddText/AddRow → ix.ag.PlaceTooltip(tip)
ix.ag.HideTooltip()
ix.ag.Prompt(title, default, cb)
```

## Опции (ix.option → вкладка Настройки)
`agBlur agScanlines agAnimations agMenuSounds agEspNoclipOnly`
(категория AfterGlow UI) + `agAdminEspInfo` (AfterGlow Admin).

## Реестр вкладок единого меню
```lua
ix.ag.RegisterMenuTab({
    id = "mytab", name = "МОЯ ВКЛАДКА", icon = "icon16/star.png",
    order = 6, visible = function() return true end,
    build = function(menu, parent)
        local pnl = parent:Add("Panel") pnl:Dock(FILL) return pnl
    end
})
```
