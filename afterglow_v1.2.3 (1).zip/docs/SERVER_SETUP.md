# HL:A RP — Пошаговая настройка сервера Garry's Mod

Полный гайд от пустой машины до работающего сервера. Ожидаемое время: 2–4 часа на чистом хосте (без ожидания скачивания контента).

---

## Шаг 0. Требования

- **Железо/ВМ:** 4 vCPU, 8 ГБ RAM, 40 ГБ SSD, Linux (Debian/Ubuntu) или Windows. Garry's Mod — single-thread-ориентирован: берите хост с сильной одноядерной частотой.
- **Сеть:** UDP 27015 открыт (плюс TCP 27015 для RCON по желанию).
- **GSLT-токен** для листинга сервера: создаётся бесплатно на странице управления игровыми серверами Steam (steamcommunity.com → «Game Server Account Management», AppID 4000).
- **Доступ:** root/sudo + SteamCMD.

---

## Шаг 1. Установка выделенного сервера Garry's Mod

Dedicated-сервер Garry's Mod — **AppID 4020**, ветка рекомендуется **x86-64** (лучше производительность, `sv_hibernate_think`, меньше OOM). Параметр `-beta x86-64` добавляется к `app_update` ([официальная wiki](https://wiki.facepunch.com/gmod/Downloading_a_Dedicated_Server)).

```bash
# Linux
mkdir -p ~/steamcmd ~/gmodds && cd ~/steamcmd
wget https://steamcdn-a.akamaihd.net/client/installer/steamcmd_linux.tar.gz
tar -xzf steamcmd_linux.tar.gz

./steamcmd.sh +force_install_dir ~/gmodds \
  +login anonymous \
  +app_update 4020 -beta x86-64 validate \
  +quit
```

```bat
:: Windows (steamcmd в tекущей папке)
steamcmd.exe +force_install_dir C:\gmodds ^
  +login anonymous ^
  +app_update 4020 -beta x86-64 validate ^
  +quit
```

> Отдельный нюанс именно для Linux-хостов: актуальная 64-битная ветка — обязательный `-beta x86-64`; сборка «из коробки» без параметра потянет устаревшую ветку ([пример хостера](https://nexus-games.com/us/blog/gmod-server-hosting-free-2026/)).

---

## Шаг 2. Монтирование контента (CSS + Episodes)

Почти все карты `rp_*` и оружейные паки требуют **Counter-Strike: Source**; часть props/моделей Цитадели — Episodic/EP2.

```bash
# CSS dedicated-контент (AppID 232330, anonymous)
./steamcmd.sh +force_install_dir ~/gmodcss \
  +login anonymous \
  +app_update 232330 validate \
  +quit
```

Откройте `deploy/garrysmod/cfg/mount.cfg` (лежит в пакете) и пропишите реальные пути:

```
"mountcfg"
{
	"cstrike"	"/home/<ваш_юзер>/gmodcss/cstrike"
	// "episodic"	".../Half-Life 2/episodic"
	// "ep2"	".../Half-Life 2/ep2"
}
```

- Episodic-контент: копируется из **легально купленного клиента** HL2:EP1/EP2 (папки `episodic`, `ep2`) на сервер; либо берите workshop-контент-паки с моделями Цитадели (проверяйте лицензии).
- `mount.cfg` копируется в `garrysmod/cfg/` сервера.

---

## Шаг 3. Helix Framework + наша схема

Фреймворк: [github.com/NebulousCloud/helix](https://github.com/NebulousCloud/helix) — ставится папкой `gamemodes/helix`; своя схема пишется поверх него (скелет есть в репозитории [helix-skeleton](https://github.com/nebulouscloud/helix-skeleton), также можно смотреть готовый пример [helix-hl2rp](https://github.com/nebulouscloud/helix-hl2rp); [официальная инструкция](https://github.com/NebulousCloud/helix/blob/master/docs/manual/getting-started.md)).

```bash
cd ~/gmodds/garrysmod/gamemodes
git clone https://github.com/NebulousCloud/helix.git helix
# фиксируем версию (рекомендуем — пин на конкретный коммит):
cd helix && git log -1 --format=%H && cd ..
```

Дальше — копируем дерево нашего пакета:

```bash
# из папки afterglow_server (там, где лежит deploy/)
cp -r deploy/garrysmod/* ~/gmodds/garrysmod/
```

Проверьте, что получилась структура: `~/gmodds/garrysmod/gamemodes/afterglow/schema/sh_schema.lua` и `~/gmodds/garrysmod/addons/afterglow/lua/...`.

> Наш пакет — это уже готовая схема `afterglow` (не копия skeleton). Папки `gamemodes/skeleton` не нужны.

---

## Шаг 4. Workshop-коллекция и контент

### 4.1. Соберите коллекцию (Steam → Workshop → Collections → Create)

Минимальный набор:

| Элемент | Зачем | Поиск |
|---|---|---|
| **HL:A Combine Grunt/Suppressor/Charger/Captain — PM/NPC** | Модели дивизионов ОВА и GRID | «HL:Alyx Combine Grunt» — порты カルト_くん и др. (см. подборку [Half-Life: Alyx Addons](https://steamcommunity.com/workshop/filedetails/?id=1924936838)) |
| **TFA VOX — HL:A VOX-паки** | Озвучка юнитов/диспетчера | «TFA VOX alyx combine» (зависят от соотв. моделей) |
| **ULib + ULX** | Администрирование (CAMI-совместимы с Helix) | «ULX» — официальные Ulysses (id 557962238 / 557962280) |
| **weapon_medkit** | Класс HELIX/медик | «weapon medkit» — классический аддон |
| **Карта QZ/С17** | Мир | «rp quarantine», «rp_city17», «zombie quarantine map»; критерии: силовые поля как func_brush, район блоков, стройплощадка-цитадель на фоне |
| **Оружейный пак (опционально)** | ARC9/TFA/M9K — только если хотите заменить сток | выбирайте ОДИН пак и поправьте loаdout в `classes/` |
| **Штурмовой щит (опционально)** | Для Charger | «combine riot shield gmod» |

### 4.2. Подключение

Создайте стартовый скрипт `start.sh` рядом с `~/gmodds`:

```bash
#!/bin/bash
cd ~/gmodds
./srcds_run -game garrysmod -console -64 \
  +gamemode afterglow \
  +map rp_имя_карты \
  +maxplayers 64 \
  -tickrate 33 \
  +host_workshop_collection <ВАШ_ID_КОЛЛЕКЦИИ> \
  +sv_setsteamaccount <ВАШ_GSLT_ТОКЕН> \
  -port 27015
```

- CSS-модели из мастерской клиенты скачают автоматически по коллекции.
- Lua/SWEP/SENT нашего аддона раздаются плагином `downloads` (если запакуете `addons/afterglow` в workshop — закомментируйте в нём `resource.AddFile` блок и добавьте id в `WORKSHOP_IDS`).

---

## Шаг 5. server.cfg и администрирование

В пакете есть готовый `deploy/garrysmod/cfg/server.cfg`. Проверьте/заполните:

- `hostname`, `rcon_password`, при желании `sv_password` (закрытый бета-запуск).
- Сетевые ограничения уже выставлены под tickrate 33 и RP нагрузку.

**Права админа (ULX через CAMI, родная связка для Helix):**

1. Зайдите на сервер, создайте персонажа.
2. В консоли сервера (srcds): `ulx adduser "ВашНик" superadmin` или через SteamID: `ulx adduserid STEAM_0:X:XXXX superadmin`.
3. Дальше выдача прав — `/menu` в игре → вкладка администрирования/ULX.

Логирование Helix включено по умолчанию (`data/helix/logs`).

---

## Шаг 6. (Опционально) MySQL

Helix по умолчанию работает на SQLite (`garrysmod/sv.db`) — для <40 онлайна этого достаточно и это удобно при бэкапах. Для MySQL:

1. Модуль `gmsv_mysqloo` (linux64: `gmsv_mysqloo_linux64.dll` в `garrysmod/lua/bin/`).
2. В `garrysmod/cfg/server.cfg`: не нужен ключ; коннект задаётся плагином — создайте `schema/plugins/database/sh_plugin.lua` по образцу `helix/docs` (хук `SetupDatabase` / переменные `ix.db.*`) или используйте community-гайд.

---

## Шаг 7. Первый вход: настройка мира карты

Порядок действий в игре (админ с superadmin, на карте):

```text
1) lua_run PrintAfterGlowHelp()     -- подсказка-чеклист в консоль любой клиентской консоли rcon'ом (или напечатана при первом старте в логе сервера)
2) /SpawnAdd citizen            -- плаза/блоки
   /SpawnAdd оборона            -- НЕКСУС (название фильтруется по подстроке: citizen | оборона | ова | сопротивление | администрация)
   /SpawnAdd ова                -- казармы КЗ
   /SpawnAdd сопротивление      -- подвалы трущоб
   /SpawnAdd администрация      -- муниципальный блок
3) Зоны КЗ (диагональ куба):
   /QZPos1 (у прицела) -> /QZPos2 -> /QZCreate КЗ-Сектор7 1
   /QZPos1 -> /QZPos2 -> /QZCreate КЗ-Глубь 2
4) /QZSpawnAdd 1                -- точки обычной фауны (10–20 шт по КЗ-1)
   /QZSpawnAdd 2                -- ядовитая фауна (КЗ-2, 8–15 шт)
   /QZSpawnAdd 1 ceiling        -- барнаклы под потолками/мостами
5) /ResinAdd                    -- тайники смолы (8–15 шт, разброс)
6) /TerminalAdd 1 … 3           -- терминалы у силовых полей
   /TerminalLink                -- целясь в func_brush поля (терминал берётся ближайший ≤600 юн.)
7) /WorkbenchAdd                -- 1–2 верстака в трущобах ячеек
```

Всё переживает рестарт (`garrysmod/data/helix/<schema>/`).

**Проверочный раунд командами:**
- Выдать перчатки себе: `/CharGiveGravGloves <имя>` → проверить притягивание смолы.
- Крафт: положите 4+ смолы → верстак → улучшение SMG → перевзять оружие.
- Взлом: ЭМП или терминал → провести/провалить → убедиться в сообщениях у «CP».

---

## Шаг 8. Тестовая эксплуатация

Прогоните тест-матрицу из `docs/design_doc.md` (раздел 8) с 5–8 людьми, особенно:

1. Разогрев под 30+ ботами/игроками: `net_graph 3` у клиентов; серверная `stats` — frame time < 10 мс стабильного с директором NPC работающим.
2. Длительная сессия 3 часа: утечки сущностей (журнал `data/helix/logs`, ошибки Lua в консоль должны быть пусты).
3. Перезапуск хоста: весь мир на месте (зоны/терминалы/спавны/тайники).

---

## Шаг 9. Эксплуатация и бэкапы

- **Бэкап ежедневно:** `garrysmod/data/helix/`, `garrysmod/sv.db` (или дамп MySQL), `garrysmod/cfg/`, свой workshop-id лист.
- **Обновления:** Helix и аддоны — сначала на стейдж-копии; GMod DS обновлять тем же steamcmd-запросом с `validate` и тем же `-beta x86-64`.
- **Дежурство:** отключённый сервер при пустоте не дешевле `sv_hibernate_think 1` — NPC/таймеры спят.

---

## Troubleshooting

| Симптом | Причина | Лечение |
|---|---|---|
| ERROR-текстуры, розовые модели | нет CSS-контента у клиента (в коллекции нет CSS-workshop-пака) | добавить в коллекцию CSS-контент-паки (id на gmodstore/Workshop); проверить `mount.cfg` на сервере |
| Сервер не виден в списке | нет GSLT / firewall | `+sv_setsteamaccount`, UDP 27015 |
| Луа-ошибки `attempt to index nil 'ix.hacking'` | плагин отключён/удалён, а SENT его дёргает | вернуть плагин; все вызовы защищены `if (ix.hacking...)` — значит смотреть первую ошибку выше в консоли |
| Не работает мини-игра, пустая панель | клиент не скачал lua | settings в плагине `downloads` (`resource.AddFile` либо workshop) |
| Модели CP/OW «гражданские» | классовая модель не нашлась | проверить пути в `classes/*.lua` `CLASS.models` после установки HL:A паков |
| Фильтр не тратится | игрок в noclip / зона не покрывает позицию | noclip дебафф снят намеренно; проверить `/QZList` и куб зоны |
| ULX-команды не видны | ULX не в коллекции | оба аддона (ULib+ULX) в коллекцию, рестарт |

Готово — сервер поднимается, мир живёт, КЗ кашляет. Удачной сессии!
