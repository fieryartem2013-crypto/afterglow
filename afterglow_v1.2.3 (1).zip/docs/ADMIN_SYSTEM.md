# AfterGlow Admin — 21 ранг, права, команды, ESP, тикеты

## Иерархия рангов (вес ASC → сверху вниз по силе)

| Вес | Ключ | Название | Цвет (hex) | Префикс |
|----:|------|----------|-----------|---------|
| 21 | marshall | Маршалл | #F5F5F5 | MARSHALL |
| 20 | arkham_team | Arkham Team | #A855F7 | ARKHAM |
| 19 | spec_admin | Спец. администратор | #8B5CF6 | SPEC |
| 18 | tech_admin | Технический админ | #64748B | TECH |
| 17 | developer | Разработчик | #22D3EE | DEV |
| 16 | manager_head | Главный менеджер | #F97316 | H-MANAGER |
| 15 | deputy_head | Заместитель главы | #FB923C | DEPUTY |
| 14 | junior_dev | Младший разработчик | #67E8F9 | DEV-JR |
| 13 | manager | Менеджер | #EAB308 | MANAGER |
| 12 | inspector | Инспектор | #14B8A6 | INSPECTOR |
| 11 | curator_admin | Куратор админов | #EF4444 | CUR-ADMIN |
| 10 | curator_recruitment | Куратор рекрутинга | #84CC16 | CUR-RECRUIT |
|  9 | curator_events | Куратор ивентов | #EC4899 | CUR-EVENT |
|  8 | curator_helper | Куратор-помощник | #4ADE80 | CUR-HELP |
|  7 | rar_admin | RAR администратор | #DC2626 | RAR-ADMIN |
|  6 | rar_eventer | RAR ивентер | #F472B6 | RAR-EVENT |
|  5 | sr_admin | Ст. администратор | #F87171 | SR-ADMIN |
|  4 | sr_eventer | Ст. ивентер | #E879F9 | SR-EVENT |
|  3 | admin | Администратор | #F59E0B | ADMIN |
|  2 | eventer | Ивентер | #C084FC | EVENT |
|  1 | moderator | Модератор | #38BDF8 | MOD |

Определение: `schema/plugins/20_ag_admin/sh_usergroups.lua`
(`ix.ag.GROUPS` + `ix.ag.GROUP_ORDER`). Цвет используется в префиксах
скорборда, ESP-рамках и футере меню.

## Права (perms)
Ключи: `ticket warn kick ban unban freeze spectate goto bring esp noclip
setname setfaction setgroup give spawn config logs physgun toolgun`.
`"*"` — все права. Проверки: `ply:AGHasPerm("kick")`, вес: `ply:AGGroupIndex()`.

- **Иммунитет:** действие на цель невозможно, если `индекс цели >= индексу исполнителя`
  (на себя — можно).
- **Бан:** ранг < 12 — максимум 7 дней, без пермы. Перма (`0 мин`) — с DEPUTY (15) и выше.
- **setgroup:** нельзя выдать ранг ≥ своему; `marshall` назначает только marshall.

## Команды (чат/консоль say)
| Команда | Аргументы | Право |
|---------|-----------|-------|
| /agspectate | [игрок] | spectate (повтор — выход) |
| /aggoto | игрок | goto |
| /agbring | игрок | bring |
| /agfreeze | игрок | freeze (переключение) |
| /agwarn | игрок причина | warn |
| /agwarns | игрок | warn |
| /agkick | игрок [причина] | kick |
| /agban | игрок минуты [причина] | ban (0 = перма) |
| /agunban | SteamID | unban |
| /agsetname | игрок новое_имя | setname |
| /agsetfaction | игрок фракция | setfaction |
| /agsetgroup | игрок ранг | setgroup |
| /aggroups | — | перечень рангов |

Хранилище: `ix.data` (`data/helix/ag_groups.json`, `ag_bans.json`, `ag_warns/*`).

## Admin ESP (cl_adminesp.lua)
- Рендер: HUDPaint, ранг с правом `esp`.
- Опция «ESP только в noclip» — в меню: Настройки → AfterGlow UI.
- По игроку: holo-скобки, имя+[префикс], SteamID, HP/ARMOR (зел/крас),
  фракция (цвет фракции), текущее оружие, пинг, WARNS n, FROZEN,
  «👁 SPECTATING», дистанция.
- Рамка пульсирует красно-оранжевым при наличии нарушений.

## Тикеты
Игрок: контекстное меню в списке игроков → «Пожаловаться» (указывает цель).
Стафф: вкладка **ТИКЕТЫ** единого меню (право `ticket`): взять в работу /
закрыть с итогом. Все события дублируются нотификациями стаффу.

## Совместимость с SAM/xAdmin2/ULX
При загрузке после них все 21 группа регистрируются в CAMI (`Initialize`).
Можно мэппить их средствами вашей админки; команды `/ag…` остаются
авторитетными (иммунитет и лимиты здесь).
