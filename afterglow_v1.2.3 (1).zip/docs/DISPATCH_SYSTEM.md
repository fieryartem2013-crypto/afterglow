# Диспатч Альянса (plugins/ag_dispatch)

## Доступ
- Стафф с правом `dispatch` (ранг admin и выше).
- ИЛИ персонаж фракции `administration` (Администрация Сити-17).

## Использование
- Команда `/agdispatch` → AGDispatchPanel:
  - 4 кнопки быстрых тревог (Прорыв QZ / Уклонист / Комендантский час / Очистка);
  - библиотека из 6 пресетов со стоковыми звуками cityvoice HL2 (есть у всех клиентов);
  - кастомная директива до 220 символов + выбор важности (ИНФО/ПРЕДУПРЕЖДЕНИЕ/ТРЕВОГА).
- Кулдаун `dispatchCooldown` (по умолчанию 12с) на диспатчера.

## Зрители
- Полноэкранный AGDispatchBanner: неоновая полоса, пульс важности, стрелки,
  тег ДИСПАТЧ АЛЬЯНСА + текст; звук cityvoice/klaxon/warningbell.
- Дублирование в чат цветной рамкой.
- Логирование `ix.log.AddRaw`.

## API
```lua
-- сервер:
local pl = ix.plugin.Get("ag_dispatch")
pl:Broadcast("ТЕКСТ", 2, "ОВА-CO", "npc/overwatch/cityvoice/f_anticivilevidence_3_spkr.wav")
-- pl:CanDispatch(ply) → bool
```
