# ГСР (CWU) — станочный геймплей (plugins/cwu + entities ix_cwu_*)

## Энтити (спавн: admin, категория "AfterGlow — ГСР")
| Энтити | Назначение |
|--------|-----------|
| ix_cwu_workbench | Станок переработки: стейджинг сырья → 4 типа работ → продукция + токены на CID |
| ix_cwu_aircleaner | Очиститель воздуха: деградирует, обслуживается рабочими; исправный — локальный иммунитет от токсина QZ (радиус `cwuCleanerRadius`) |
| ix_cwu_terminal | Терминал нарядов: взять/сдать/отказаться от наряда, прогресс по квотам, награда + чек заслуг |

## Экономика (plugins/cwu/sh_plugin.lua → PLUGIN.recipes)
| Работа | Вход | Выход | Токены | Время |
|--------|------|-------|-------:|------:|
| СОРТИРОВКА | 2× Вторсырьё | 1× Отсортированные детали | +4 | 6с |
| ОЧИСТКА ФИЛЬТРОВ | 1× Грязный фильтр | 1× Фильтр противогаза (100%) | +8 | 8с |
| СБОРКА РАЦИОНОВ | 3× Компоненты рациона | 1× Запечатанный рацион | +6 | 7с |
| ПРЕССОВАНИЕ ЛОМА | 2× Детали + 1× Вторсырьё | 1× Металлический блок | +10 | 10с |

Наряды (PLUGIN.orders): ration5, clean3, press4, sort10 — награды токенами
+ «Чек заслуг ГСР» (item merit_check, обмен `cwuMeritValue` ☼).

## Хуки для интеграции
- `CWUQuotaProduced(ply, quotaKey)` — на каждую готовую продукцию (увеличивает прогресс наряда).
- `CwuCleanerServiced(ply, cleaner)` — обслуживание выполнено.
- `OnPlayerConsumedRation(ply)` — съеден запечатанный рацион.
- `AGZoneToxinImmune(ply, zone)` (shared server hook в quarantine) — отмена токсина; cwu реализует его возле исправных очистителей.

## Конфиги (ix.config)
`cwuMeritValue cwuCleanerRadius cwuCleanerDrain cwuCleanerDecay cwuCleanerServiceTime cwuCleanerReward`
