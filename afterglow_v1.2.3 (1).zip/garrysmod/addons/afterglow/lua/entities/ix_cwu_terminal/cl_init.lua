include("shared.lua")

function ENT:Draw()
	self:DrawModel()
	local ply = LocalPlayer()
	if (ply:GetPos():DistToSqr(self:GetPos()) > 500 * 500) then return end
	local pos = self:GetPos() + self:GetUp() * 40
	local ang = self:GetAngles()
	ang:RotateAroundAxis(ang:Forward(), 90)
	ang:RotateAroundAxis(ang:Right(), 90)
	cam.Start3D2D(pos, ang, 0.06)
		draw.SimpleText("ГСР // ТЕРМИНАЛ НАРЯДОВ", "AG.Small", 0, 0, ix.ag.C.neon, TEXT_ALIGN_CENTER)
		draw.SimpleText("E — открыть задачи", "AG.Tiny", 0, 14, ix.ag.C.textDim, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end
