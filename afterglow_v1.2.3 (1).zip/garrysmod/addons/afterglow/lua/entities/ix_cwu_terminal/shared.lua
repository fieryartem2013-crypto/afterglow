ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Терминал нарядов ГСР"
ENT.Author = "AfterGlow Team"
ENT.Category = "AfterGlow — ГСР"
ENT.Spawnable = true
ENT.AdminOnly = true
