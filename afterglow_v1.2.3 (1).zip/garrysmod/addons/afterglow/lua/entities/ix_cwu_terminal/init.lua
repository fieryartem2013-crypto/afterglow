AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props_combine/combine_interface001.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local phys = self:GetPhysicsObject()
	if (IsValid(phys)) then phys:Wake() end
end

function ENT:Use(activator)
	if (!IsValid(activator) or !activator:IsPlayer()) then return end
	if ((self.nextUse or 0) > CurTime()) then return end
	self.nextUse = CurTime() + 0.75

	local plugin = ix.plugin.Get("cwu")
	if (!plugin) then
		activator:Notify("Модуль ГСР не загружен на сервере.")
		return
	end
	plugin:OpenTerminal(self, activator)
end
