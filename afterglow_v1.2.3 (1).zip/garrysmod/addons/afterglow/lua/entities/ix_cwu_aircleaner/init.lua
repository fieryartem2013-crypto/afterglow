AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props_combine/combine_mine01.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetNWFloat("cond", 100)
	local phys = self:GetPhysicsObject()
	if (IsValid(phys)) then phys:Wake() end

	local plugin = ix.plugin.Get("cwu")
	if (plugin) then plugin:RegisterCleaner(self) end
end

function ENT:Use(activator)
	if (!IsValid(activator) or !activator:IsPlayer()) then return end
	if ((self.nextUse or 0) > CurTime()) then return end
	self.nextUse = CurTime() + 1

	local cond = self:GetNWFloat("cond", 100)
	if (cond >= 95) then
		activator:Notify("Очиститель исправен (" .. math.floor(cond) .. "%). Обслуживание не требуется.")
		return
	end

	local plugin = ix.plugin.Get("cwu")
	if (!plugin) then
		activator:Notify("Модуль ГСР не загружен на сервере.")
		return
	end
	plugin:ServiceCleaner(self, activator)
end
