include("shared.lua")

function ENT:Draw()
	self:DrawModel()

	local ply = LocalPlayer()
	if (ply:GetPos():DistToSqr(self:GetPos()) > 700 * 700) then return end

	local cond = self:GetNWFloat("cond", 100)
	local pos = self:GetPos() + self:GetUp() * 48
	local ang = self:GetAngles()
	ang:RotateAroundAxis(ang:Forward(), 90)
	ang:RotateAroundAxis(ang:Right(), 90)

	cam.Start3D2D(pos, ang, 0.07)
		local col = cond > 60 and ix.ag.C.green or (cond > 25 and ix.ag.C.amber or ix.ag.C.red)
		draw.RoundedBox(0, -150, -44, 300, 88, Color(8, 12, 17, 230))
		surface.SetDrawColor(col)
		surface.DrawOutlinedRect(-150, -44, 300, 88, 2)
		draw.SimpleText("ОЧИСТИТЕЛЬ ВОЗДУХА", "AG.SmallB", 0, -32, ix.ag.C.neon, TEXT_ALIGN_CENTER)
		draw.SimpleText(("СОСТОЯНИЕ: %d%%"):format(cond), "AG.Small", 0, -10, col, TEXT_ALIGN_CENTER)
		surface.SetDrawColor(30, 38, 48, 255)
		surface.DrawRect(-130, 8, 260, 12)
		surface.SetDrawColor(col)
		surface.DrawRect(-130, 8, 260 * (cond / 100), 12)
		draw.SimpleText(cond < 95 and "E — ОБСЛУЖИТЬ (1× гр. фильтр + 1× детали)" or "СЕКТОР ОЧИЩЕН",
			"AG.Tiny", 0, 28, ix.ag.C.textDim, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end
