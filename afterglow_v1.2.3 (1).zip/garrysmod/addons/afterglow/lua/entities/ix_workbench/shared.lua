ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Верстак сопротивления"
ENT.Category = "HL:A RP"
ENT.Spawnable = false
ENT.AdminOnly = true

function ENT:SetupDataTables()
	self:NetworkVar("String", 0, "BenchTitle")
end
