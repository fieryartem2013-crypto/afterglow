AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

util.AddNetworkString("ixWorkbenchOpen")

function ENT:Initialize()
	self:SetModel("models/props_junk/wood_crate001a.mdl") -- замените на модель верстака из контент-пака
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetBenchTitle("ВЕРСТАК :: АПГРЕЙД/БИО-КРАФТ")

	local phys = self:GetPhysicsObject()
	if (IsValid(phys)) then
		phys:Wake()
		phys:EnableMotion(false)
	end
end

function ENT:Use(activator)
	if (!IsValid(activator) or !activator:IsPlayer()) then return end
	if (activator:GetPos():DistToSqr(self:GetPos()) > 160 * 160) then return end

	net.Start("ixWorkbenchOpen")
		net.WriteEntity(self)
	net.Send(activator)

	self:EmitSound("ambient/machines/machine4.wav", 50, 110)
end
