include("shared.lua")

function ENT:Draw()
	self:DrawModel()

	local pos = self:GetPos() + Vector(0, 0, 22)
	local ang = LocalPlayer():EyeAngles()
	ang = Angle(0, ang.y - 90, 90)

	local dist = LocalPlayer():GetPos():DistToSqr(self:GetPos())
	if (dist > 300 * 300) then return end

	cam.Start3D2D(pos, ang, 0.06)
		draw.SimpleText(self:GetBenchTitle() or "ВЕРСТАК",
			"DermaDefault", 0, 0, Color(140, 240, 120, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("[E] — работать",
			"DermaDefault", 0, 18, Color(200, 200, 200, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	cam.End3D2D()
end
