AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props_interiors/vendingmachinesoda01a.mdl") -- замените на модель терминала
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:SetNWString("ixState", "secure") -- secure | hacked | alarm

	local phys = self:GetPhysicsObject()
	if (IsValid(phys)) then
		phys:Wake()
		phys:EnableMotion(false)
	end
end

function ENT:Use(activator)
	if (!IsValid(activator) or !activator:IsPlayer()) then return end
	if (activator:GetPos():DistToSqr(self:GetPos()) > 160 * 160) then return end
	if (!activator:GetCharacter()) then return end

	-- GRID обслуживает через /TerminalReset; остальным — взлом
	if (ix.hacking and ix.hacking.BeginHack) then
		ix.hacking.BeginHack(activator, self)
	end
end
