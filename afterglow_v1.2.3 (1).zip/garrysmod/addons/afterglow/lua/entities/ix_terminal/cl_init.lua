include("shared.lua")

local STATE_COLORS = {
	secure = Color(80, 180, 255),
	hacked = Color(120, 255, 120),
	alarm = Color(255, 80, 80)
}

local STATE_TEXT = {
	secure = "ЗАЩИЩЁН",
	hacked = "ВЗЛОМАН — контур открыт",
	alarm = "ТРЕВОГА"
}

function ENT:Draw()
	self:DrawModel()

	local dist = LocalPlayer():GetPos():DistToSqr(self:GetPos())
	if (dist > 350 * 350) then return end

	local pos = self:GetPos() + self:GetUp() * 58
	local ang = LocalPlayer():EyeAngles()
	ang = Angle(0, ang.y - 90, 90)

	local state = self:GetNWString("ixState", "secure")
	local col = STATE_COLORS[state] or STATE_COLORS.secure
	local pulse = (math.sin(CurTime() * (state == "alarm" and 10 or 3)) + 1) * 0.5

	cam.Start3D2D(pos, ang, 0.08)
		draw.SimpleText("ТЕРМИНАЛ ГВ :: УЗЕЛ КОНТУРА",
			"DermaDefault", 0, -10, Color(200, 220, 240, 230), TEXT_ALIGN_CENTER)
		draw.SimpleText(STATE_TEXT[state] or state,
			"DermaDefault", 0, 10, ColorAlpha(col, 160 + 95 * pulse), TEXT_ALIGN_CENTER)
		draw.SimpleText("[E] — доступ",
			"DermaDefault", 0, 30, Color(150, 150, 160, 200), TEXT_ALIGN_CENTER)
	cam.End3D2D()
end
