ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Терминал Альянса"
ENT.Category = "HL:A RP"
ENT.Spawnable = false
ENT.AdminOnly = true
