ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Станок ГСР (переработка)"
ENT.Author = "AfterGlow Team"
ENT.Category = "AfterGlow — ГСР"
ENT.Spawnable = true
ENT.AdminOnly = true
