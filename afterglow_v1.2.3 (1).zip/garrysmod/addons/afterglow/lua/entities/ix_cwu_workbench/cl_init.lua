include("shared.lua")

function ENT:Draw()
	self:DrawModel()

	local ply = LocalPlayer()
	if (ply:GetPos():DistToSqr(self:GetPos()) > 600 * 600) then return end

	local pos = self:GetPos() + self:GetUp() * 55
	local ang = self:GetAngles()
	ang:RotateAroundAxis(ang:Forward(), 90)
	ang:RotateAroundAxis(ang:Right(), 90)

	cam.Start3D2D(pos, ang, 0.08)
		local busy = self:GetNWBool("cwuBusy", false)
		local prog = self:GetNWFloat("cwuProg", 0)
		draw.RoundedBox(0, -160, -50, 320, 100, Color(8, 12, 17, 230))
		surface.SetDrawColor(busy and ix.ag.C.amber or ix.ag.C.green)
		surface.DrawOutlinedRect(-160, -50, 320, 100, 2)
		draw.SimpleText("ГСР // ПЕРЕРАБОТКА", "AG.SmallB", 0, -34, ix.ag.C.neon, TEXT_ALIGN_CENTER)
		draw.SimpleText(busy and ("СБОРКА… " .. math.floor(prog * 100) .. "%%") or "НАЖМИТЕ E — РАБОТАТЬ",
			"AG.Small", 0, -10, busy and ix.ag.C.amber or ix.ag.C.green, TEXT_ALIGN_CENTER)
		if (busy) then
			surface.SetDrawColor(30, 38, 48, 255)
			surface.DrawRect(-140, 10, 280, 16)
			surface.SetDrawColor(ix.ag.C.amber)
			surface.DrawRect(-140, 10, 280 * prog, 16)
		end
	cam.End3D2D()
end
