AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props_wasteland/laundry_washer003.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	local phys = self:GetPhysicsObject()
	if (IsValid(phys)) then phys:Wake() end
end

function ENT:Use(activator)
	if (!IsValid(activator) or !activator:IsPlayer()) then return end
	if ((self.nextUse or 0) > CurTime()) then return end
	self.nextUse = CurTime() + 0.5

	local plugin = ix.plugin.Get("cwu")
	if (!plugin) then
		activator:Notify("Модуль ГСР не загружен на сервере.")
		return
	end

	-- занят другим оператором
	if (IsValid(self.cwuOperator) and self.cwuOperator != activator
		and self.cwuOperator:GetPos():DistToSqr(self:GetPos()) < 300 * 300) then
		activator:Notify("Станок занят: " .. self.cwuOperator:Nick())
		return
	end

	plugin:OpenWorkbench(self, activator)
end

function ENT:Think()
	if (IsValid(self.cwuOperator)) then
		if (self.cwuOperator:GetPos():DistToSqr(self:GetPos()) > 300 * 300) then
			self.cwuOperator = nil
			self.cwuStaged = {}
		end
	end
	self:NextThink(CurTime() + 0.5)
	return true
end
