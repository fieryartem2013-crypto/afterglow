-- ============================================================
-- Граво-перчатки Рассела — shared
-- ПКМ: энергетический толчок (отпихнуть лёгкие пропы)
-- ЛКМ: магнитное притягивание лёгкого предмета к носителю
-- Трекинг/поглощение лута — schema/plugins/gravigloves.
-- ============================================================
SWEP.PrintName = "Граво-перчатки"
SWEP.Author = "Arena Studio"
SWEP.Instructions = "ЛКМ — притянуть лёгкий предмет. ПКМ — энерготолчок."
SWEP.Category = "HL:A RP"

SWEP.Spawnable = false
SWEP.AdminOnly = true

SWEP.ViewModel = "models/weapons/c_arms.mdl"
SWEP.WorldModel = ""
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"
SWEP.Secondary = table.Copy(SWEP.Primary)

SWEP.HoldType = "normal"

function SWEP:Initialize()
	self:SetHoldType(self.HoldType)
end

function SWEP:PrimaryAttack()
	if (CLIENT) then return end
	local owner = self:GetOwner()
	if (!IsValid(owner)) then return end

	local reach = ix.config and ix.config.Get("gravReach", 420) or 420
	local maxMass = ix.config and ix.config.Get("gravMaxMass", 20) or 20

	local tr = util.TraceLine({
		start = owner:GetShootPos(),
		endpos = owner:GetShootPos() + owner:GetAimVector() * reach,
		filter = owner
	})

	local ent = tr.Entity
	if (!IsValid(ent)) then
		self:SetNextPrimaryFire(CurTime() + 0.25)
		return
	end

	-- Запреты: живое/тяжёлое/чужое "держимое"
	if (ent:IsPlayer() or ent:IsNPC()) then
		owner:Notify("Магнит не цепляет живое.")
		self:SetNextPrimaryFire(CurTime() + 0.5)
		return
	end

	local phys = ent:GetPhysicsObject()
	if (!IsValid(phys)) then
		self:SetNextPrimaryFire(CurTime() + 0.35)
		return
	end

	if (ent:GetClass() != "ix_item" and phys:GetMass() > maxMass) then
		owner:Notify("Слишком тяжело для перчаток (лимит " .. maxMass .. " кг).")
		self:SetNextPrimaryFire(CurTime() + 0.5)
		return
	end

	-- Импульс к владельцу + регистрация в трекере плагина
	local speed = ix.config and ix.config.Get("gravPullSpeed", 1100) or 1100
	local dir = (owner:GetShootPos() - ent:GetPos()):GetNormalized()
	phys:Wake()
	phys:SetVelocity(dir * speed + Vector(0, 0, 60))

	if (ix.gravgloves) then
		ix.gravgloves.Track(ent, owner)
	end

	ent:EmitSound("weapons/physcannon/physcannon_charge1.wav", 55, 90)
	self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
	self:SetNextPrimaryFire(CurTime() + 0.55)
end

function SWEP:SecondaryAttack()
	if (CLIENT) then return end
	local owner = self:GetOwner()
	if (!IsValid(owner)) then return end

	-- короткий энерготолчок: расшвыривает лёгкие пропы перед собой
	local ownerPos = owner:GetShootPos()
	for _, ent in ipairs(ents.FindInSphere(ownerPos + owner:GetAimVector() * 96, 96)) do
		if (ent != owner and !ent:IsPlayer() and !ent:IsNPC()) then
			local phys = ent:GetPhysicsObject()
			if (IsValid(phys) and phys:GetMass() <= 40) then
				phys:Wake()
				phys:SetVelocity(owner:GetAimVector() * 500 + Vector(0, 0, 120))
			end
		end
	end

	util.Effect("StunstickImpact", EffectData():SetOrigin(ownerPos + owner:GetAimVector() * 48))
	owner:EmitSound("weapons/physcannon/physcannon_fire1.wav", 60, 120)
	self:SetNextSecondaryFire(CurTime() + 1.0)
end

function SWEP:Reload() end
