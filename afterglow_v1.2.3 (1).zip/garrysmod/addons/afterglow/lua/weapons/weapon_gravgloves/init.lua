AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function SWEP:Deploy()
	self:SendWeaponAnim(ACT_VM_DRAW)
	return true
end
