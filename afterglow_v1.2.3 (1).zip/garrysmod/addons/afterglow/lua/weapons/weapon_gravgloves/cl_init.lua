include("shared.lua")

function SWEP:DrawWorldModel() end -- перчатки невидимы от 3-го лица (модель-то от рук)

-- Лёгкая индикация готовности магнита над прицельным курсором
function SWEP:DrawHUD()
	local owner = self:GetOwner()
	if (!IsValid(owner)) then return end

	local reach = ix.config and ix.config.Get("gravReach", 420) or 420
	local maxMass = ix.config and ix.config.Get("gravMaxMass", 20) or 20
	local tr = util.TraceLine({
		start = owner:GetShootPos(),
		endpos = owner:GetShootPos() + owner:GetAimVector() * reach,
		filter = owner
	})

	local x, y = ScrW() / 2, ScrH() / 2
	local ok = false
	if (IsValid(tr.Entity) and !tr.Entity:IsPlayer() and !tr.Entity:IsNPC()) then
		local phys = tr.Entity:GetPhysicsObject()
		ok = IsValid(phys) and (tr.Entity:GetClass() == "ix_item" or phys:GetMass() <= maxMass)
	end

	local col = ok and Color(120, 220, 255) or Color(120, 120, 120, 140)
	surface.SetDrawColor(col)
	surface.DrawRect(x - 8, y - 1, 6, 2)
	surface.DrawRect(x + 2, y - 1, 6, 2)
	surface.DrawRect(x - 1, y - 8, 2, 6)
	surface.DrawRect(x - 1, y + 2, 2, 6)

	if (ok) then
		draw.SimpleText("ЗАХВАТ", "ixSmallFont", x, y + 22, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end
