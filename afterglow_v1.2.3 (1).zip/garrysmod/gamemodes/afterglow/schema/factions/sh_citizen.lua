FACTION.name = "Гражданское население"
FACTION.description = "Жители восстанавливаемого Города 17: нелегалы Пустошей, зарегистрированные горожане и работники ГНА."
FACTION.color = Color(150, 150, 150)
FACTION.isDefault = true
FACTION.models = {
	"models/humans/group01/male_01.mdl",
	"models/humans/group01/male_02.mdl",
	"models/humans/group01/female_01.mdl",
	"models/humans/group01/female_02.mdl"
}

FACTION_CITIZEN = FACTION.index
