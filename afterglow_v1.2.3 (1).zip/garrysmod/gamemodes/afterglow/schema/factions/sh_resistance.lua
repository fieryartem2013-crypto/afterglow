FACTION.name = "Сопротивление"
FACTION.description = "Ячейки выживших, техники и освобождённые вортигонты. Базируются в трущобах и на краю Карантинной Зоны."
FACTION.color = Color(200, 120, 40)
FACTION.models = {
	"models/humans/group02/male_02.mdl",
	"models/humans/group02/male_04.mdl",
	"models/humans/group02/female_01.mdl",
	"models/humans/group02/female_03.mdl"
}
FACTION.isDefault = false

FACTION_RESISTANCE = FACTION.index
