FACTION.name = "Администрация города"
FACTION.description = "Коллаборанты-чиновники гражданской администрации: регистрация, пропаганда, распределение рационов."
FACTION.color = Color(230, 220, 170)
FACTION.models = {
	"models/odessa.mdl",
	"models/mossman.mdl",
	"models/monk.mdl"
}
FACTION.isDefault = false

FACTION_ADMINISTRATION = FACTION.index
