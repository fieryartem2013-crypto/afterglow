FACTION.name = "Силы ОВА (Overwatch)"
FACTION.description = "Военный корпус Альянса. Задействуется в Карантинной Зоне и при кодах тревоги в городе."
FACTION.color = Color(170, 40, 40)
FACTION.models = {
	"models/combine_soldier.mdl"
}
FACTION.isDefault = false

function FACTION:OnCharacterCreated(client, character)
	local digits = string.format("%05d", math.random(0, 99999))
	character:SetData("digits", digits)
	character:SetData("rank", "GRN")
	character:SetName("OW-K.GRN." .. digits)
end

FACTION_OVERWATCH = FACTION.index
