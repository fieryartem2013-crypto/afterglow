FACTION.name = "Гражданская Оборона"
FACTION.description = "Ранние формирования Гражданской Обороны. Люди в форме Альянса: патруль, медицина, следствие, инженерия."
FACTION.color = Color(50, 90, 160)
FACTION.models = {
	"models/police.mdl"
}
FACTION.isDefault = false

-- Авто-генерация позывного: CP-C17.UNION-RCT.XXXXX
function FACTION:OnCharacterCreated(client, character)
	local digits = string.format("%05d", math.random(0, 99999))
	character:SetData("digits", digits)
	character:SetData("rank", "RCT")
	character:SetName("CP-C17.UNION-RCT." .. digits)

	local inventory = character:GetInventory()
	if (inventory) then
		inventory:Add("cidcard", 1, {
			name = character:GetName(),
			cid = digits
		})
	end
end

FACTION_CP = FACTION.index
