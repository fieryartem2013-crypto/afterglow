-- Чек заслуг ГСР: обмен у руководства/кассы.
ITEM.name = "Чек заслуг ГСР"
ITEM.description = "Жёлтый купон с кодом допуска: подтверждает перевыполнение нормы. Обменивается на токены."
ITEM.model = "models/props_lab/clipboard.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Документы"
ITEM.price = 20

ITEM.functions.use = {
	name = "Обменять на токены",
	icon = "icon16/money.png",
	OnCanRun = function(item) return true end,
	OnRun = function(item)
		local client = item.player
		local char = IsValid(client) and client:GetCharacter()
		if (!char) then return false end
		char:GiveMoney(ix.config.Get("cwuMeritValue", 20))
		if (IsValid(client)) then
			client:Notify("Чек заслуг погашен: +" .. ix.config.Get("cwuMeritValue", 20) .. " ☼ на ваш CID.")
		end
		return true
	end
}
