ITEM.name = "Самодельная рация"
ITEM.description = "Спаянный из пультов и гарнитур ГВ приёмопередатчик. Одна фиксированная «частота повстанцев»."
ITEM.model = "models/props_lab/citizenradio.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Снаряжение"
ITEM.price = 200
-- Логика эфира: plugins/radio (chat-класс radio_res)
