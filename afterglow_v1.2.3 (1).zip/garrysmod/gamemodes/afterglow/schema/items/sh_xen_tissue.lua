ITEM.name = "Био-ткань Зена"
ITEM.description = "Склизкий лоскут экзогенной плоти. Тёплый. Торговцы КЗ и медики берут не глядя."
ITEM.model = "models/Gibs/HGIBS.mdl" -- замените на кастомную модель
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Компоненты"
ITEM.price = 0
