ITEM.name = "ЭМЗ-заряд «Громила»"
ITEM.description = "Самодельный импульсный заряд: клеится на силовое поле брашей Альянса и гасит его на ~25 секунд. Громко пищит."
ITEM.model = "models/props_combine/combine_mine01.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Диверсия"
ITEM.price = 400

ITEM.functions.plant = {
	name = "Установить",
	icon = "icon16/bomb.png",
	OnRun = function(item)
		local client = item:GetOwner()
		if (IsValid(client) and ix.hacking) then
			return ix.hacking.PlantEMP(client) -- true => удалить заряд из инвентаря
		end
		return false
	end
}
