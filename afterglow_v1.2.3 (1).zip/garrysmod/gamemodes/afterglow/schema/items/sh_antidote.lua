ITEM.name = "Антидот «Зен-А»"
ITEM.description = "Мутная сыворотка из желёз хедкрабов. Жжёт. Снимает заражение спорами на любой стадии."
ITEM.model = "models/healthvial.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Медицина"
ITEM.price = 50

ITEM.functions.inject = {
	name = "Ввести",
	icon = "icon16/heart_add.png",
	OnCanRun = function(item)
		local client = item:GetOwner()
		return IsValid(client) and client:GetCharacter()
			and (client:GetCharacter():GetData("wounds", {}).infection or 0) > 0
	end,
	OnRun = function(item)
		local client = item:GetOwner()
		if (IsValid(client)) then
			ix.medical.CureInfection(client)
			client:EmitSound("items/medshot4.wav")
		end
		return true
	end
}
