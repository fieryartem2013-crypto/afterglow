ITEM.name = "Шина"
ITEM.description = "Жёсткая фиксация конечности. Запускает заживление перелома (~5 минут покоя)."
ITEM.model = "models/props_junk/gascan001a.mdl"
ITEM.width = 1
ITEM.height = 2
ITEM.category = "Медицина"
ITEM.price = 20

ITEM.functions.apply = {
	name = "Наложить",
	icon = "icon16/heart_add.png",
	OnCanRun = function(item)
		local client = item:GetOwner()
		return IsValid(client) and client:GetCharacter()
			and client:GetCharacter():GetData("wounds", {}).fracture
			and !client:GetCharacter():GetData("wounds", {}).splinted
	end,
	OnRun = function(item)
		local client = item:GetOwner()
		if (IsValid(client)) then
			ix.medical.ApplySplint(client)
		end
		return true
	end
}
