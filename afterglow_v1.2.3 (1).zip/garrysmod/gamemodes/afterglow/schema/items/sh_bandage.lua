ITEM.name = "Бинт"
ITEM.description = "Относительно чистая ткань. Останавливает кровотечение (снимает 1 уровень, медик — 2)."
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Медицина"
ITEM.price = 10

ITEM.functions.apply = {
	name = "Перевязать",
	icon = "icon16/heart_add.png",
	OnCanRun = function(item)
		local client = item:GetOwner()
		return IsValid(client) and client:GetCharacter()
			and (client:GetCharacter():GetData("wounds", {}).bleed or 0) > 0
	end,
	OnRun = function(item)
		local client = item:GetOwner()
		if (IsValid(client)) then
			ix.medical.TreatBleed(client, ix.medical.IsMedic(client) and 2 or 1)
			client:EmitSound("items/smallmedkit1.wav")
		end
		return true
	end
}
