ITEM.name = "Железа хедкраба"
ITEM.description = "Комковатая железа из-под панциря. База для антидота против спор при переработке на верстаке."
ITEM.model = "models/Gibs/HGIBS.mdl" -- замените на кастомную модель
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Компоненты"
ITEM.price = 0
