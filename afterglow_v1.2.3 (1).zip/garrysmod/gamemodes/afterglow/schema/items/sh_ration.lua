ITEM.name = "Рацион лояльности"
ITEM.description = "Серая банка с штампом ГВ. Нутриентная паста, вода и, если повезёт, пара токенов."
ITEM.model = "models/props_junk/garbage_metalcan001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Рационы"
ITEM.price = 15

ITEM.functions.open = {
	name = "Вскрыть",
	icon = "icon16/box.png",
	OnRun = function(item)
		local client = item:GetOwner()
		if (!IsValid(client) or !client:GetCharacter()) then return false end

		local character = client:GetCharacter()
		local tokens = math.random(5, 15) -- игровая «мелочь» в пакете

		character:GiveMoney(tokens)
		client:Notify("Внутри: нутриентная паста, пакетик воды и " .. tokens .. " токенов.")

		-- шанс мелкого бонуса
		if (math.random() < 0.15) then
			character:GetInventory():Add("bandage", 1)
			client:Notify("На дне обнаруживается бинт. День становится лучше.")
		end

		client:EmitSound("items/battery_pickup.wav")
		return true
	end
}
