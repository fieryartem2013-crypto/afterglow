-- Смола — главный ресурс ремесла Сопротивления.
ITEM.name = "Смола"
ITEM.description = "Янтарный кристалл из протоков Зена. Внутри, кажется, медленно течёт свет. Рабочий материал верстаков."
ITEM.model = "models/props_junk/rock001a.mdl" -- замените на кастомную «смолу»
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Компоненты"
ITEM.price = 0

function ITEM:GetDescription()
	local amount = self:GetData("amount", 1)
	if (amount > 1) then
		return self.description .. " Единиц: " .. amount .. "."
	end
	return self.description
end

-- Слияние кусков смолы (drag&drop одного куска на другой)
ITEM.functions.combine = {
	OnCanRun = function(item, data)
		local other = ix.item.instances[data[1]]
		return other and other.uniqueID == "resin"
	end,
	OnRun = function(item, data)
		local other = ix.item.instances[data[1]]
		if (other) then
			other:SetData("amount", math.min(99, other:GetData("amount", 1) + item:GetData("amount", 1)))
		end
		return true -- удалить «перетащенный» кусок
	end
}
