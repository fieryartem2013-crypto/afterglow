-- Сменный фильтр противогаза. amount = заряд 0..100.
ITEM.name = "Фильтр противогаза"
ITEM.description = "Цилиндр с активированным углём и грубой мембраной. Пахнет озоном и старой бумагой. Заряд: примерно %s%%."
ITEM.model = "models/props_junk/plasticbucket001a.mdl" -- замените на модель фильтра
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Снаряжение"
ITEM.price = 30

function ITEM:GetDescription()
	return string.format(self.description, math.floor(self:GetData("amount", 100)))
end

-- Вставить в надетый (или первый попавшийся) противогаз
ITEM.functions.load = {
	name = "Вставить в противогаз",
	icon = "icon16/arrow_in.png",
	OnCanRun = function(item)
		local inv = item:GetInventory()
		if (!inv) then return false end
		for _, v in pairs(inv:GetItems()) do
			if (v.uniqueID == "gasmask" and v:GetData("filter", 0) < 100) then
				return true
			end
		end
		return false
	end,
	OnRun = function(item)
		local inv = item:GetInventory()
		local mask
		-- приоритет — надетому противогазу
		for _, v in pairs(inv:GetItems()) do
			if (v.uniqueID == "gasmask" and v:GetData("equipped", false) and v:GetData("filter", 0) < 100) then
				mask = v
				break
			end
		end
		if (!mask) then
			for _, v in pairs(inv:GetItems()) do
				if (v.uniqueID == "gasmask" and v:GetData("filter", 0) < 100) then
					mask = v
					break
				end
			end
		end

		if (mask) then
			local add = item:GetData("amount", 100)
			mask:SetData("filter", math.min(100, mask:GetData("filter", 0) + add))
			local owner = item:GetOwner()
			if (IsValid(owner)) then
				owner:Notify("Фильтр установлен. Заряд: " .. math.floor(mask:GetData("filter", 0)) .. "%.")
				owner:EmitSound("items/ammo_pickup.wav")
			end
		end
		return true -- удалить фильтр из инвентаря
	end
}
