ITEM.name = "Склянка ворт-эссенции"
ITEM.description = "Мерцающая зелень вортагонтской сущности. Регенерация ~30 HP за минуту, изгоняет споровую заразу."
ITEM.model = "models/props_lab/jar01b.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Медицина"
ITEM.price = 0

ITEM.functions.drink = {
	name = "Выпить",
	icon = "icon16/status_online.png",
	OnRun = function(item)
		local client = item:GetOwner()
		if (IsValid(client)) then
			ix.medical.UseEssence(client)
		end
		return true
	end
}
