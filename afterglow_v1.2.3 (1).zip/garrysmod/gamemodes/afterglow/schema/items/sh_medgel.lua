ITEM.name = "Гелевый пластырь ГВ"
ITEM.description = "Порция станкового медгеля в ампуле. Нейтрализует плазменные ожоги (иначе лечение блокируется)."
ITEM.model = "models/props_lab/jar01a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Медицина"
ITEM.price = 25

ITEM.functions.apply = {
	name = "Нанести",
	icon = "icon16/heart_add.png",
	OnCanRun = function(item)
		local client = item:GetOwner()
		return IsValid(client) and client:GetCharacter()
			and client:GetCharacter():GetData("wounds", {}).burn
	end,
	OnRun = function(item)
		local client = item:GetOwner()
		if (IsValid(client)) then
			ix.medical.TreatBurn(client)
			client:EmitSound("items/medshot4.wav")
		end
		return true
	end
}
