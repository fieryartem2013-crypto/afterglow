-- Противогаз раннего образца ГВ. Расходник — фильтр (item filter).
-- ПОДРОБНО: логика расхода/урона — plugins/quarantine.
ITEM.name = "Противогаз ГВ-4"
ITEM.description = "Гражданский противогаз первых лет оккупации. Грубая резина, один сменный фильтр. Без фильтра — лишь мокрая тряпка на лице."
ITEM.model = "models/props_junk/gascan001a.mdl" -- замените на модель противогаза из контент-пака
ITEM.width = 2
ITEM.height = 2
ITEM.category = "Снаряжение"
ITEM.price = 120

-- Данные: equipped (bool), filter (0..100)

ITEM.functions.wear = {
	name = "Надеть",
	icon = "icon16/tick.png",
	OnCanRun = function(item)
		return !item:GetData("equipped", false)
	end,
	OnRun = function(item)
		item:SetData("equipped", true)
		local owner = item:GetOwner()
		if (IsValid(owner)) then
			owner:Notify("Вы надеваете противогаз. Щелчок клапана, тесный шлем.")
			owner:EmitSound("npc/combine_soldier/gear2.wav")
		end
		return false -- не удалять предмет
	end
}

ITEM.functions.unwear = {
	name = "Снять",
	icon = "icon16/cross.png",
	OnCanRun = function(item)
		return item:GetData("equipped", false)
	end,
	OnRun = function(item)
		item:SetData("equipped", false)
		local owner = item:GetOwner()
		if (IsValid(owner)) then
			owner:Notify("Вы снимаете противогаз.")
			owner:EmitSound("npc/combine_soldier/gear5.wav")
		end
		return false
	end
}

ITEM.functions.unload = {
	name = "Извлечь фильтр",
	icon = "icon16/arrow_out.png",
	OnCanRun = function(item)
		return !item:GetData("equipped", false) and item:GetData("filter", 0) > 0
	end,
	OnRun = function(item)
		local left = item:GetData("filter", 0)
		item:SetData("filter", 0)
		local owner = item:GetOwner()
		if (IsValid(owner) and owner:GetCharacter()) then
			local ok, err = owner:GetCharacter():GetInventory():Add("filter", 1, {amount = math.floor(left)})
			if (!ok) then
				ix.item.Spawn("filter", owner:GetShootPos() + owner:GetAimVector() * 24, nil, nil, {amount = math.floor(left)})
			end
			owner:Notify("Фильтр извлечён (осталось " .. math.floor(left) .. "%).")
		end
		return false
	end
}
