ITEM.name = "Аптечка ГВ"
ITEM.description = "Базовый паёк медицины Альянса: +25 HP. Не лечит спец-ranы (см. бинты/гель/антидот)."
ITEM.model = "models/Items/HealthKit" -- HL2 healthkit
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Медицина"
ITEM.price = 35

ITEM.functions.heal = {
	name = "Использовать",
	icon = "icon16/heart_add.png",
	OnRun = function(item)
		local client = item:GetOwner()
		if (IsValid(client)) then
			ix.medical.HealBasic(client, 25)
		end
		return true
	end
}
