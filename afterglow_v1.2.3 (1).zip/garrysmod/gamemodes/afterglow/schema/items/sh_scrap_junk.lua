-- Вторсырьё: гнутые трубки, пластик, бытовой хлам.
ITEM.name = "Вторсырьё"
ITEM.description = "Мешанина из пластика, ткани и погнутой арматуры. ГСР принимает такое на переработку."
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Сырьё ГСР"
ITEM.price = 2
ITEM.bDropOnDeath = true
