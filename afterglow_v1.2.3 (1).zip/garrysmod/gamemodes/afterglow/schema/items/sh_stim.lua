ITEM.name = "Шприц-тюбик ГВ"
ITEM.description = "Стимулятор Альянса: +25 HP быстро и прилив сил. Передозировка (3+ за 5 минут) бьёт по телу."
ITEM.model = "models/healthvial.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Медицина"
ITEM.price = 40

ITEM.functions.inject = {
	name = "Вколоть",
	icon = "icon16/lightning.png",
	OnRun = function(item)
		local client = item:GetOwner()
		if (IsValid(client)) then
			ix.medical.UseStim(client)
		end
		return true
	end
}
