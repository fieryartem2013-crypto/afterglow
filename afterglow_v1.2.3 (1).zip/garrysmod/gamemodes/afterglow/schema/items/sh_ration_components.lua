-- Компоненты рациона: картриджи пищепасты и упаковка.
ITEM.name = "Компоненты рациона"
ITEM.description = "Картридж пищевой пасты и пустая упаковка. На станке ГСР собирается в полноценный рацион."
ITEM.model = "models/props_c17/canister_propane01a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Сырьё ГСР"
ITEM.price = 3
