-- Запечатанный рацион: продукция ГСР, обменивается на стандартный рацион.
ITEM.name = "Запечатанный рацион"
ITEM.description = "Серая упаковка с печатью Альянса: готовый паёк, собранный руками ГСР."
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Питание"
ITEM.price = 8

ITEM.functions.use = {
	name = "Съесть",
	icon = "icon16/cup.png",
	OnCanRun = function(item) return true end,
	OnRun = function(item)
		local client = item.player
		if (IsValid(client)) then
			client:EmitSound("npc/barnacle/barnacle_crunch2.wav", 55)
			client:Notify("Паста безвкусная, но сытная.")
			hook.Run("OnPlayerConsumedRation", client)
		end
		return true
	end
}
