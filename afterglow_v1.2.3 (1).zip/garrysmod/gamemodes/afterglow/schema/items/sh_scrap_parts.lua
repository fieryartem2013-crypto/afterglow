-- Отсортированные детали: выход сортировки.
ITEM.name = "Отсортированные детали"
ITEM.description = "Чистые винты, провода и пластины, разложенные по ячейкам. Годятся для сборки и пресса."
ITEM.model = "models/props_junk/shoe001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Сырьё ГСР"
ITEM.price = 4
ITEM.bDropOnDeath = true
