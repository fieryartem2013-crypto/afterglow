-- Металлический блок: прессованный лом.
ITEM.name = "Металлический блок"
ITEM.description = "Аккуратный брус спрессованного лома с маркировкой ГСР. Уходит на фабрики Альянса."
ITEM.model = "models/props_debris/metal_panel01a.mdl"
ITEM.width = 2
ITEM.height = 1
ITEM.category = "Сырьё ГСР"
ITEM.price = 12
