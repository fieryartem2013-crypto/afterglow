ITEM.name = "CID-карта"
ITEM.description = "Пластик гражданской идентификации. Имя: %s. CID: %s."
ITEM.model = "models/props_lab/clipboard.mdl" -- замените на кастомную модель карты
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Документы"
ITEM.price = 0
ITEM.bDropOnDeath = true

function ITEM:GetDescription()
	return string.format(self.description,
		self:GetData("name", "НЕТ ДАННЫХ"),
		tostring(self:GetData("cid", "00000")))
end

ITEM.functions.show = {
	name = "Предъявить",
	icon = "icon16/vcard.png",
	OnRun = function(item)
		local client = item:GetOwner()
		if (IsValid(client)) then
			ix.chat.Send(client, "me", "предъявляет CID-карту: "
				.. item:GetData("name", "НЕТ ДАННЫХ")
				.. ", CID " .. tostring(item:GetData("cid", "00000")))
		end
		return false
	end
}
