-- Грязный фильтр: снимается с очистителей воздуха.
ITEM.name = "Грязный фильтр"
ITEM.description = "Бумажно-угольный цилиндр, чёрный от зеновой слизи. Ещё можно отмыть на станке ГСР."
ITEM.model = "models/props_junk/plasticbucket001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.category = "Сырьё ГСР"
ITEM.price = 3
ITEM.bDropOnDeath = true
