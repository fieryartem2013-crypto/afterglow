-- ============================================================
-- HL:A RP — sv_schema.lua (server)
-- ============================================================

-- Консольная шпаргалка для первичной настройки мира.
-- Запуск из консоли сервера: lua_run PrintAfterGlowHelp()  (или rcon)
function PrintAfterGlowHelp()
	MsgN("================ AFTERGLOW BOOTSTRAP ================")
	MsgN("Порядок настройки карты (админ, в игре):")
	MsgN(" 1. /SpawnAdd citizen | cp | overwatch | resistance | administration")
	MsgN(" 2. /QZPos1 (угол зоны) -> /QZPos2 (противоположный) -> /QZCreate <имя> <уровень 1-2>")
	MsgN(" 3. /QZSpawnAdd <1|2>            — точки появления фауны Зена в QZ")
	MsgN(" 4. /ResinAdd                    — точки тайников смолы")
	MsgN(" 5. /TerminalAdd <tier 1-3>      — терминалы Альянса (взлом)")
	MsgN("    /TerminalLink (целься в брашь силового поля рядом с терминалом)")
	MsgN(" 6. /WorkbenchAdd                — верстак сопротивления (смола/улучшения)")
	MsgN(" 7. Готово. Данные хранятся в garrysmod/data/helix/...")
	MsgN("===================================================")
end

-- Удобный хук: при загрузке карты напомнить о чек-листе, если мир пуст
function Schema:InitPostEntity()
	timer.Simple(30, function()
		local zones = ix.data.Get("qzZones", {}, false, false)
		if (#zones == 0) then
			MsgN("[AfterGlow] Зоны карантина не настроены! lua_run PrintAfterGlowHelp()")
		end
	end)
end
