-- ============================================================
-- AFTERGLOW STAFF HIERARCHY — 21 РАНГ
-- Индекс = вес ранга (больше = выше). Иммунитет: нельзя
-- воздействовать на ранг >= своему (индекс >= своего индекса).
-- ============================================================

ix.ag.GROUPS = {
	-- [key] = {index, name, color, prefix, perms, staff}
	-- staff=true → показывается в блоке «Стафф онлайн»

	user = {index = 0, name = "Игрок", color = ix.ag.Hex("#7C8D9A"), prefix = "", perms = {}, staff = false},

	-- ---------- МЛАДШИЙ РЯД ----------
	moderator = {index = 1, name = "Модератор", color = ix.ag.Hex("#38BDF8"), prefix = "MOD", staff = true, perms = {
		"ticket", "warn", "spectate", "goto", "bring", "freeze", "kick", "esp", "logs", "noclip"
	}},
	eventer = {index = 2, name = "Ивентер", color = ix.ag.Hex("#C084FC"), prefix = "EVENT", staff = true, perms = {
		"goto", "bring", "freeze", "esp", "spectate", "noclip", "spawn"
	}},
	admin = {index = 3, name = "Администратор", color = ix.ag.Hex("#F59E0B"), prefix = "ADMIN", staff = true, perms = {
		"ticket", "warn", "spectate", "goto", "bring", "freeze", "kick", "ban", "esp", "logs", "noclip", "setname"
	}},

	-- ---------- СТАРШИЙ РЯД ----------
	sr_eventer = {index = 4, name = "Ст. ивентер", color = ix.ag.Hex("#E879F9"), prefix = "SR-EVENT", staff = true, perms = {
		"goto", "bring", "freeze", "kick", "esp", "spectate", "noclip", "spawn", "setname"
	}},
	sr_admin = {index = 5, name = "Ст. администратор", color = ix.ag.Hex("#F87171"), prefix = "SR-ADMIN", staff = true, perms = {
		"ticket", "warn", "spectate", "goto", "bring", "freeze", "kick", "ban", "esp", "logs", "noclip", "setname", "setfaction"
	}},

	-- ---------- RAR-LAYER (редкостно-администраторский) ----------
	rar_eventer = {index = 6, name = "RAR ивентер", color = ix.ag.Hex("#F472B6"), prefix = "RAR-EVENT", staff = true, perms = {
		"goto", "bring", "freeze", "kick", "esp", "spectate", "noclip", "spawn", "setname", "physgun"
	}},
	rar_admin = {index = 7, name = "RAR администратор", color = ix.ag.Hex("#DC2626"), prefix = "RAR-ADMIN", staff = true, perms = {
		"ticket", "warn", "spectate", "goto", "bring", "freeze", "kick", "ban", "esp", "logs", "noclip", "setname", "setfaction", "physgun"
	}},

	-- ---------- КУРАТОРСТВО ----------
	curator_helper = {index = 8, name = "Куратор-помощник", color = ix.ag.Hex("#4ADE80"), prefix = "CUR-HELP", staff = true, perms = {
		"ticket", "spectate", "logs", "esp", "goto"
	}},
	curator_events = {index = 9, name = "Куратор ивентов", color = ix.ag.Hex("#EC4899"), prefix = "CUR-EVENT", staff = true, perms = {
		"goto", "bring", "freeze", "kick", "esp", "spectate", "noclip", "spawn", "setname", "physgun"
	}},
	curator_recruitment = {index = 10, name = "Куратор рекрутинга", color = ix.ag.Hex("#84CC16"), prefix = "CUR-RECRUIT", staff = true, perms = {
		"ticket", "logs", "spectate", "esp", "setfaction"
	}},
	curator_admin = {index = 11, name = "Куратор админов", color = ix.ag.Hex("#EF4444"), prefix = "CUR-ADMIN", staff = true, perms = {
		"ticket", "warn", "spectate", "goto", "bring", "freeze", "kick", "ban", "unban", "esp", "logs", "noclip", "setname", "setfaction", "physgun"
	}},

	-- ---------- ИНСПЕКЦИЯ И МЕНЕДЖМЕНТ ----------
	inspector = {index = 12, name = "Инспектор", color = ix.ag.Hex("#14B8A6"), prefix = "INSPECTOR", staff = true, perms = {
		"ticket", "logs", "spectate", "esp", "goto", "bring", "noclip"
	}},
	manager = {index = 13, name = "Менеджер", color = ix.ag.Hex("#EAB308"), prefix = "MANAGER", staff = true, perms = {
		"ticket", "warn", "kick", "ban", "unban", "freeze", "esp", "logs", "noclip", "setname", "setfaction", "give"
	}},
	junior_dev = {index = 14, name = "Младший разработчик", color = ix.ag.Hex("#67E8F9"), prefix = "DEV-JR", staff = true, perms = {
		"noclip", "esp", "spectate", "goto", "bring", "spawn", "physgun", "toolgun"
	}},
	deputy_head = {index = 15, name = "Заместитель главы", color = ix.ag.Hex("#FB923C"), prefix = "DEPUTY", staff = true, perms = {
		"ticket", "warn", "kick", "ban", "unban", "freeze", "esp", "logs", "noclip", "setname", "setfaction", "give", "setgroup", "physgun"
	}},
	manager_head = {index = 16, name = "Главный менеджер", color = ix.ag.Hex("#F97316"), prefix = "H-MANAGER", staff = true, perms = {
		"ticket", "warn", "kick", "ban", "unban", "freeze", "esp", "logs", "noclip", "setname", "setfaction", "give", "setgroup", "config", "physgun", "spawn"
	}},

	-- ---------- ТЕХНИЧЕСКИЙ СЛОЙ ----------
	developer = {index = 17, name = "Разработчик", color = ix.ag.Hex("#22D3EE"), prefix = "DEV", staff = true, perms = {
		"noclip", "esp", "spectate", "goto", "bring", "spawn", "physgun", "toolgun", "config", "logs", "give"
	}},
	tech_admin = {index = 18, name = "Технический админ", color = ix.ag.Hex("#64748B"), prefix = "TECH", staff = true, perms = {
		"noclip", "esp", "spectate", "goto", "bring", "spawn", "physgun", "toolgun", "config", "logs", "give", "ban", "unban", "kick"
	}},

	-- ---------- ВЕРХНЯЯ ИНФРАСТРУКТУРА ----------
	spec_admin = {index = 19, name = "Спец. администратор", color = ix.ag.Hex("#8B5CF6"), prefix = "SPEC", staff = true, perms = {"*"}},
	arkham_team = {index = 20, name = "Arkham Team", color = ix.ag.Hex("#A855F7"), prefix = "ARKHAM", staff = true, perms = {"*"}},
	marshall = {index = 21, name = "Маршалл", color = ix.ag.Hex("#F5F5F5"), prefix = "MARSHALL", staff = true, perms = {"*"}}
}

-- упорядоченный список (для UI-перечислений)
ix.ag.GROUP_ORDER = {
	"marshall", "arkham_team", "spec_admin", "tech_admin", "developer",
	"manager_head", "deputy_head", "junior_dev", "manager", "inspector",
	"curator_admin", "curator_recruitment", "curator_events", "curator_helper",
	"rar_admin", "rar_eventer", "sr_admin", "sr_eventer", "admin", "eventer", "moderator"
}

function ix.ag.GroupData(key)
	return ix.ag.GROUPS[key] or ix.ag.GROUPS.user
end

function ix.ag.GroupHasPerm(group, perm)
	local data = ix.ag.GroupData(group)
	for _, p in ipairs(data.perms) do
		if (p == "*" or p == perm) then return true end
	end
	return false
end

-- цвет/префикс (client drawing)
function ix.ag.GroupColor(key) return ix.ag.GroupData(key).color end
function ix.ag.GroupPrefix(key) return ix.ag.GroupData(key).prefix end
