-- Панель тикетов (вкладка в едином меню, видна стаффу с правом ticket)
local PANEL = {}

local STATE_COLORS = {
	[0] = ix.ag.C.red,
	[1] = ix.ag.C.amber,
	[2] = ix.ag.C.green
}
local STATE_NAMES = {[0] = "ОТКРЫТ", [1] = "В РАБОТЕ", [2] = "ЗАКРЫТ"}

ix.ag.tickets = ix.ag.tickets or {}

net.Receive("agTicket", function()
	local op = net.ReadUInt(4)
	if (op == 2) then -- sync
		ix.ag.tickets = net.ReadTable()
		if (IsValid(ix.gui.agTicketsPanel)) then
			ix.gui.agTicketsPanel:Rebuild()
		end
	end
end)

function PANEL:Init() end

function PANEL:PerformLayout(w, h)
	if (self.built or w < 50 or h < 50) then return end
	self.built = true
	ix.gui.agTicketsPanel = self

	local head = self:Add("Panel")
	head:Dock(TOP)
	head:SetTall(38)
	head.Paint = function(_, hw, hh)
		draw.SimpleText("СИСТЕМА ТИКЕТОВ // ЖАЛОБЫ ИГРОКОВ", "AG.MediumB", 4, hh / 2, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(#ix.ag.tickets .. " всего", "AG.Small", hw - 8, hh / 2, ix.ag.C.textDim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end

	self.scroll = self:Add("AGScrollPanel")
	self.scroll:Dock(FILL)
	self.scroll:DockMargin(0, 6, 0, 0)

	self:Rebuild()
end

function PANEL:Rebuild()
	if (!IsValid(self.scroll)) then return end
	self.scroll:Clear()

	local ply = LocalPlayer()
	local y = 0
	local sorted = {}
	for _, t in ipairs(ix.ag.tickets) do sorted[#sorted + 1] = t end
	table.sort(sorted, function(a, b) return (a.state or 0) < (b.state or 0) or (a.id or 0) > (b.id or 0) end)

	if (#sorted == 0) then
		local empty = self.scroll:Add("Panel")
		empty:SetPos(0, 0)
		empty:SetSize(self.scroll:GetWide() - 10, 60)
		empty.Paint = function(_, ew, eh)
			draw.SimpleText("Активных тикетов нет", "AG.Medium", ew / 2, eh / 2, ix.ag.C.textMute, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		return
	end

	for _, t in ipairs(sorted) do
		local hgt = 92
		local card = self.scroll:Add("Panel")
		card:SetPos(0, y)
		card:SetSize(self.scroll:GetWide() - 12, hgt)
		card.t = t
		card.Paint = function(c, cw, ch)
			local st = c.t.state or 0
			local col = STATE_COLORS[st] or ix.ag.C.text
			surface.SetDrawColor(8, 12, 17, 235)
			surface.DrawRect(0, 0, cw, ch)
			surface.SetDrawColor(col)
			surface.DrawRect(0, 0, 4, ch)
			surface.SetDrawColor(col.r, col.g, col.b, 18)
			surface.DrawRect(4, 0, cw - 4, ch)

			draw.SimpleText(("ТИКЕТ #%d   •   %s"):format(c.t.id, STATE_NAMES[st] or "?"), "AG.SmallB", 12, 8, col)
			draw.SimpleText(("от: %s (%s)   →   на: %s"):format(c.t.player or "?", c.t.steam or "?", c.t.target or "—"),
				"AG.Small", 12, 26, ix.ag.C.text)
			draw.SimpleText("«" .. (c.t.text or "") .. "»", "AG.Small", 12, 44, ix.ag.C.neon, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, cw - 24)
			if (st >= 1) then
				draw.SimpleText("взял: " .. (c.t.admin or "—"), "AG.Tiny", 12, ch - 14, ix.ag.C.amber)
			end
			if (st == 2 and c.t.resolution ~= "") then
				draw.SimpleText("итог: " .. c.t.resolution, "AG.Tiny", 120, ch - 14, ix.ag.C.green)
			end
		end

		if (ply.AGHasPerm and ply:AGHasPerm("ticket")) then
			if (t.state == 0) then
				local claim = card:Add("AGButton")
				claim:SetText("ВЗЯТЬ В РАБОТУ")
				claim:SetSize(130, 26)
				claim:SetPos(card:GetWide() - 278, 58)
				claim:SetVariant("primary")
				claim.DoClick = function()
					ix.ag.Click()
					net.Start("agTicket") net.WriteUInt(1, 4) net.WriteUInt(t.id, 16) net.SendToServer()
				end
			end
			if (t.state == 0 or t.state == 1) then
				local close = card:Add("AGButton")
				close:SetText("ЗАКРЫТЬ")
				close:SetSize(120, 26)
				close:SetPos(card:GetWide() - 140, 58)
				close:SetVariant("amber")
				close.DoClick = function()
					ix.ag.Prompt("ЗАКРЫТИЕ #" .. t.id .. ": итог", "", function(res)
						net.Start("agTicket") net.WriteUInt(2, 4) net.WriteUInt(t.id, 16) net.WriteString(res) net.SendToServer()
					end)
				end
			end
		end

		y = y + hgt + 6
	end
end

vgui.Register("AGTicketsPanel", PANEL, "Panel")

-- вкладка в едином меню (только стаффу с правом ticket)
hook.Add("InitPostEntity", "AGTicketsTab", function()
	if (ix.ag.RegisterMenuTab) then
		ix.ag.RegisterMenuTab({
			id = "tickets",
			name = "ТИКЕТЫ",
			icon = "icon16/report.png",
			order = 5,
			visible = function()
				local p = LocalPlayer()
				return p.AGHasPerm and p:AGHasPerm("ticket")
			end,
			build = function(menu, parent)
				local pnl = parent:Add("AGTicketsPanel")
				pnl:Dock(FILL)
				return pnl
			end
		})
	end
end)
