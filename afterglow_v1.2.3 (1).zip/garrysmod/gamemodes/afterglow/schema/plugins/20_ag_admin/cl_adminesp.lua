-- ============================================================
-- ADMIN ESP (HL:A-style): рендерится в HUDPaint, только стафф
-- с правом "esp". Опция agEspNoclipOnly — только в noclip.
-- Цвет рамки = цвет ранга игрока; данные о нарушениях горят
-- красно-оранжевым.
-- ============================================================
local PLUGIN = PLUGIN

ix.option.Add("agAdminEspInfo", ix.type.bool, true, {
	category = "AfterGlow Admin", phrase = "ESP: расширенная информация"
})

local function DrawTagText(x, y, text, col, align, shadow)
	if (shadow ~= false) then
		draw.SimpleText(text, "AG.Tiny", x + 1, y + 1, Color(0, 0, 0, 180), align)
	end
	draw.SimpleText(text, "AG.Tiny", x, y, col, align)
	return y + 11
end

function PLUGIN:HUDPaint()
	local client = LocalPlayer()
	if (!client:IsValid() or !client.AGHasPerm or !client:AGHasPerm("esp")) then return end

	local noclipOnly = ix.option.Get("agEspNoclipOnly", true)
	local inNoclip = client:GetMoveType() == MOVETYPE_NOCLIP
	if (noclipOnly and !inNoclip) then return end
	if (!client:GetCharacter()) then return end

	local full = ix.option.Get("agAdminEspInfo", true)
	clientESP = clientESP or {}

	for _, target in player.Iterator() do
		if (target == client or !IsValid(target) or !target:Alive()) then continue end
		local dSqr = client:GetPos():DistToSqr(target:GetPos())
		if (dSqr > 4096 * 4096) then continue end

		local pos = target:GetPos() + Vector(0, 0, 2)
		local top = target:LocalToWorld(target:OBBMaxs())
		local bottom = target:LocalToWorld(target:OBBMins())

		local sTop = top:ToScreen()
		local sBottom = bottom:ToScreen()
		if (!sTop.visible and !sBottom.visible) then continue end

		local h = math.abs(sBottom.y - sTop.y)
		local w = h * 0.45
		local cx = (sTop.x + sBottom.x) / 2

		local group = target.AGGroup and target:AGGroup() or "user"
		local gData = ix.ag.GroupData(group)
		local col = gData.color

		-- пульс при нарушениях (варны / фриз)
		local warns = target:GetNetVar("agWarns", 0)
		local frozen = target:GetNetVar("agFrozen", false)
		if ((warns > 0 or frozen) and full) then
			local pulse = (math.sin(RealTime() * 6) * 0.5 + 0.5)
			col = Color(Lerp(pulse, col.r, 255), Lerp(pulse, col.g, 90), Lerp(pulse, col.b, 20))
		end

		-- рамка с уголками (HL:A holo-brackets)
		local alpha = 160 + 80 * math.sin(RealTime() * 2)
		surface.SetDrawColor(col.r, col.g, col.b, math.max(alpha, 90))
		local bw, bh = w, h
		local x1, y1 = cx - bw / 2, sTop.y
		-- углы
		local l = 9
		surface.DrawRect(x1, y1, l, 2)
		surface.DrawRect(x1, y1, 2, l)
		surface.DrawRect(x1 + bw - l, y1, l, 2)
		surface.DrawRect(x1 + bw - 2, y1, 2, l)
		surface.DrawRect(x1, y1 + bh - 2, l, 2)
		surface.DrawRect(x1, y1 + bh - l, 2, l)
		surface.DrawRect(x1 + bw - l, y1 + bh - 2, l, 2)
		surface.DrawRect(x1 + bw - 2, y1 + bh - l, 2, l)

		-- инфо-плашка справа от рамки
		if (full) then
			local ix_ = x1 + bw + 8
			local iy_ = sTop.y
			local char = target:GetCharacter()
			local faction = char and ix.faction.indices[char:GetFaction()]

			iy_ = DrawTagText(ix_, iy_, (gData.prefix ~= "" and "[" .. gData.prefix .. "] " or "") .. (char and char:GetName() or target:Nick()),
				(gData.prefix ~= "") and gData.color or ix.ag.C.text, TEXT_ALIGN_LEFT)
			iy_ = DrawTagText(ix_, iy_, target:SteamID(), ix.ag.C.textDim, TEXT_ALIGN_LEFT)
			iy_ = DrawTagText(ix_, iy_, ("HP %d/%d  ARMOR %d"):format(target:Health(), target:GetMaxHealth(), target:Armor()),
				target:Health() > 40 and ix.ag.C.green or ix.ag.C.red, TEXT_ALIGN_LEFT)
			if (faction) then
				iy_ = DrawTagText(ix_, iy_, faction.name, faction.color, TEXT_ALIGN_LEFT)
			end
			local wep = target:GetActiveWeapon()
			if (IsValid(wep)) then
				iy_ = DrawTagText(ix_, iy_, "→ " .. wep:GetClass(), ix.ag.C.amber, TEXT_ALIGN_LEFT)
			end
			iy_ = DrawTagText(ix_, iy_, "ping " .. target:Ping(), ix.ag.C.textMute, TEXT_ALIGN_LEFT)

			if (warns > 0) then
				iy_ = DrawTagText(ix_, iy_, "⚠ WARNS: " .. warns, ix.ag.C.amber, TEXT_ALIGN_LEFT)
			end
			if (frozen) then
				iy_ = DrawTagText(ix_, iy_, "❄ FROZEN", ix.ag.C.combine, TEXT_ALIGN_LEFT)
			end

			-- индикатор спектейта
			local obs = target:GetObserverTarget()
			if (IsValid(obs)) and obs == client then
				DrawTagText(cx, sBottom.y + 6, "👁 SPECTATING", ix.ag.C.neon, TEXT_ALIGN_CENTER)
			end
		else
			DrawTagText(cx, sTop.y - 14, target:Nick(), col, TEXT_ALIGN_CENTER)
		end

		-- дистанция снизу
		DrawTagText(cx, sBottom.y + 18, math.floor(math.sqrt(dSqr)) .. "u", ix.ag.C.textMute, TEXT_ALIGN_CENTER)
	end

	-- шапка-подсказка ESP
	if (inNoclip) then
		surface.SetFont("AG.Tiny")
		draw.SimpleText("ADMIN ESP: ACTIVE  [" .. (noclipOnly and "noclip-only" or "always") .. "]", "AG.Tiny",
			ScrW() / 2, 8, ColorAlpha(ix.ag.C.neon, 140 + 90 * math.sin(RealTime() * 3)), TEXT_ALIGN_CENTER)
	end
end
