-- ============================================================
-- AFTERGLOW ADMIN (ag_admin) — ядро
-- 21-ранговая иерархия (sh_usergroups), persistence через ix.data,
-- тикеты, баны/варны. Команды — sv_commands.lua, ESP — cl_adminesp.lua.
-- ============================================================
PLUGIN.name = "AfterGlow Admin"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "21-ранговая админ-система: права, иммунитет, баны, варны, тикеты, ESP."

local PLUGIN = PLUGIN  -- захват глобала: в колбэках hook.Add/net.Receive глобал PLUGIN после загрузки указывает на другой плагин/nil

if (SERVER) then
	util.AddNetworkString("agTicket")
	util.AddNetworkString("agGroupUpdated")
end

if (CLIENT) then
	ix.util.IncludeDir(PLUGIN.folder .. "/derma")
end

-- ------------------------------------------------------------
-- ХРАНИЛИЩЕ (shared-объявления, наполнение — на сервере)
-- ------------------------------------------------------------
PLUGIN.Keys = {
	groups = "ag_groups",       -- [sid64] = groupKey
	bans   = "ag_bans",         -- [sid64] = {name, admin, adminSid, reason, until, created}
	warns  = "ag_warns/"        -- warns/<sid64> = { {reason, admin, time} }
}

if (!SERVER) then return end

PLUGIN.tickets = PLUGIN.tickets or {}
PLUGIN.ticketID = PLUGIN.ticketID or 0

-- ============================================================
-- ГРУППЫ: загрузка/назначение
-- ============================================================
function PLUGIN:LoadData()
	self.groups = ix.data.Get(self.Keys.groups, {}, true, true) or {}
	self.bans = ix.data.Get(self.Keys.bans, {}, true, true) or {}
end

function PLUGIN:SaveGroups()
	ix.data.Set(self.Keys.groups, self.groups, true, true)
end

function PLUGIN:SaveBans()
	ix.data.Set(self.Keys.bans, self.bans, true, true)
end

function PLUGIN:GetWarns(sid64)
	return ix.data.Get(self.Keys.warns .. sid64, {}, true, true) or {}
end

function PLUGIN:AddWarn(sid64, entry)
	local w = self:GetWarns(sid64)
	w[#w + 1] = entry
	ix.data.Set(self.Keys.warns .. sid64, w, true, true)
end

-- выдать группу игроку (server-side API)
function PLUGIN:SetGroup(target, groupKey, byWho)
	if (!ix.ag.GROUPS[groupKey]) then return false, "Нет такой группы: " .. tostring(groupKey) end

	local sid64 = IsValid(target) and target:SteamID64() or tostring(target)
	self.groups = self.groups or {}
	if (groupKey == "user") then self.groups[sid64] = nil
	else self.groups[sid64] = groupKey end
	self:SaveGroups()

	if (IsValid(target)) then
		target:SetNetVar("agGroup", groupKey)
	end

	local gData = ix.ag.GroupData(groupKey)
	if (IsValid(target)) then
		target:Notify("Вам выдана группа: " .. (gData.prefix or groupKey) .. " (" .. gData.name .. ")")
	end
	if (byWho and IsValid(byWho)) then
		byWho:Notify((IsValid(target) and target:Nick() or sid64) .. " → " .. groupKey)
	end
	self:LogAdmin(("%s установил группу %s игроку %s"):format(
		IsValid(byWho) and byWho:Nick() or "CONSOLE", groupKey, IsValid(target) and target:Nick() or sid64))
	return true
end

-- лог админ-действий (в чат стаффа с perm logs)
function PLUGIN:LogAdmin(msg)
	for _, p in player.Iterator() do
		if (p.AGHasPerm and p:AGHasPerm("logs")) then
			p:Notify("[AG-LOG] " .. msg)
		end
	end
	print("[AfterGlow Admin] " .. msg)
end

function PLUGIN:NotifyTicketStaff(msg)
	for _, p in player.Iterator() do
		if (p.AGHasPerm and p:AGHasPerm("ticket")) then
			p:Notify("[ТИКЕТЫ] " .. msg)
		end
	end
end

-- ============================================================
-- ЗАГРУЗКА ПРИ СПАВНЕ ИГРОКА / ПРОВЕРКА БАНА
-- ============================================================
function PLUGIN:PlayerInitialSpawn(client)
	self.groups = self.groups or ix.data.Get(self.Keys.groups, {}, true, true) or {}
	local sid64 = client:SteamID64()
	local group = self.groups[sid64] or "user"
	client:SetNetVar("agGroup", group)
	client:SetNetVar("agWarns", #self:GetWarns(sid64))
	client:SetNetVar("agFrozen", false)

	-- бан-проверка
	self.bans = self.bans or {}
	local ban = self.bans[sid64]
	if (ban) then
		if (ban.until_ ~= 0 and ban.until_ < os.time()) then
			self.bans[sid64] = nil
			self:SaveBans()
		else
			timer.Simple(1, function()
				if (IsValid(client)) then
					local left = ban.until_ == 0 and "НАВСЕГДА" or ix.ag.FormatTime and (math.floor((ban.until_ - os.time()) / 60) .. " мин.") or "временно"
					client:Kick(("ЗАБАНЕН: %s\nСрок: %s\nАдминистратор: %s"):format(ban.reason or "—", left, ban.admin or "—"))
				end
			end)
		end
	end
end

-- серверная реализация FormatTime для сообщения выше
if (!ix.ag.FormatTime) then
	function ix.ag.FormatTime(sec)
		local h = math.floor(sec / 3600)
		local m = math.floor((sec % 3600) / 60)
		return string.format("%02d:%02d", h, m)
	end
end

-- ============================================================
-- ТИКЕТЫ: сеть
-- ============================================================

function PLUGIN:SyncTickets()
	local arr = {}
	for _, t in ipairs(self.tickets) do
		arr[#arr + 1] = {
			id = t.id, player = t.player, steam = t.steam,
			text = t.text, target = t.target, state = t.state,
			admin = t.admin, resolution = t.resolution
		}
	end
	net.Start("agTicket")
		net.WriteUInt(2, 4) -- op: sync
		net.WriteTable(arr)
	for _, p in player.Iterator() do
		if (p.AGHasPerm and p:AGHasPerm("ticket")) then
			net.Send(p)
		end
	end
end

net.Receive("agTicket", function(_, client)
	local op = net.ReadUInt(4)

	if (op == 0) then -- создать
		local text = string.sub(net.ReadString() or "", 1, 400)
		local target = net.ReadEntity()
		if (text == "") then return end

		local plugin = PLUGIN
		plugin.ticketID = (plugin.ticketID or 0) + 1
		plugin.tickets[#plugin.tickets + 1] = {
			id = plugin.ticketID,
			player = client:Nick(),
			steam = client:SteamID(),
			text = text,
			target = IsValid(target) and target:Nick() or "",
			state = 0, admin = "", resolution = "",
			steamFrom = client:SteamID64()
		}
		client:Notify("Жалоба отправлена стаффу (тикет #" .. plugin.ticketID .. ")")
		plugin:NotifyTicketStaff(("%s → #%d: %s"):format(client:Nick(), plugin.ticketID, text))
		plugin:SyncTickets()

	elseif (op == 1 or op == 2) then -- claim / close
		if (!client.AGHasPerm or !client:AGHasPerm("ticket")) then return end
		local id = net.ReadUInt(16)
		local resolution = (op == 2) and string.sub(net.ReadString() or "", 1, 200) or ""
		for _, t in ipairs(PLUGIN.tickets) do
			if (t.id == id) then
				if (op == 1) then
					t.state = 1 t.admin = client:Nick()
					PLUGIN:NotifyTicketStaff(("#%d взял %s"):format(id, client:Nick()))
				else
					t.state = 2 t.admin = t.admin ~= "" and t.admin or client:Nick()
					t.resolution = resolution
					PLUGIN:NotifyTicketStaff(("#%d закрыт (%s): %s"):format(id, t.admin, resolution ~= "" and resolution or "—"))
				end
				break
			end
		end
		PLUGIN:SyncTickets()
	end
end)

-- ============================================================
-- CAMI-совместимость (SAM/xAdmin2/ULX берут группы отсюда)
-- ============================================================
-- Каждый юзергрупп регистрируется в CAMI, если библиотека доступна
hook.Add("Initialize", "AGGroupsCAMI", function()
	if (CAMI and CAMI.RegisterUsergroup) then
		for key, data in pairs(ix.ag.GROUPS) do
			if (key ~= "user") then
				CAMI.RegisterUsergroup({Name = key, Inherits = "user"}, "AfterGlow")
			end
		end
	end
end)
