-- ============================================================
-- AG ADMIN COMMANDS  (сервер). Все команды — чатовые (/ag…).
-- Проверка прав через индексы рангов + иммунитет AGCanTarget.
-- ix.type.player разрешает имя цели.
-- ============================================================
local PLUGIN = PLUGIN

local function NoPerm(client, perm)
	return ("Недостаточно прав (нужно: %s). Ваша группа: %s"):format(perm, client:AGGroup())
end

local function FindTarget(client, target)
	if (!IsValid(target)) then return nil, "Игрок не найден." end
	return target
end

local DENY = "Нельзя применить к игроку с рангом выше или равным вашему."

-- ---------------- SPECTATE ----------------
ix.command.Add("AGSpectate", {
	description = "Наблюдать за игроком. Повтор — выйти из наблюдения.",
	adminOnly = true,
	arguments = {bit.bor(ix.type.player, ix.type.optional)},
	OnRun = function(self, client, target)
		if (!client:AGHasPerm("spectate")) then return NoPerm(client, "spectate") end

		if (client:GetObserverTarget() and IsValid(client:GetObserverTarget())) then
			client:UnSpectate()
			client:Notify("Наблюдение завершено.")
			return
		end
		target = FindTarget(client, target)
		if (!target) then return "Укажите игрока." end
		if (!client:AGCanTarget(target)) then return DENY end

		client:Spectate(OBS_MODE_CHASE)
		client:SpectateEntity(target)
		client:Notify("Наблюдение: " .. target:Nick() .. " (повтор команды — выход)")
	end
})

-- ---------------- GOTO / BRING ----------------
local function Teleport(client, target, bringTo)
	if (!IsValid(target)) then return "Игрок не найден." end
	if (!client:AGCanTarget(target)) then return DENY end

	local from = bringTo and target or client
	local to = bringTo and client or target
	from:SetPos(to:GetPos() + Vector(30, 0, 4))
	PLUGIN:LogAdmin(("%s %s (%s ↔ %s)"):format(client:Nick(), bringTo and "BRING" or "GOTO", from:Nick(), to:Nick()))
	client:Notify((bringTo and "Перенесён к вам: " or "Вы перемещены к: ") .. (bringTo and target or to):Nick())
end

ix.command.Add("AGGoto", {
	description = "Телепорт к игроку.",
	adminOnly = true,
	arguments = {ix.type.player},
	OnRun = function(self, client, target)
		if (!client:AGHasPerm("goto")) then return NoPerm(client, "goto") end
		return Teleport(client, target, false)
	end
})

ix.command.Add("AGBring", {
	description = "Телепорт игрока к вам.",
	adminOnly = true,
	arguments = {ix.type.player},
	OnRun = function(self, client, target)
		if (!client:AGHasPerm("bring")) then return NoPerm(client, "bring") end
		return Teleport(client, target, true)
	end
})

-- ---------------- FREEZE ----------------
ix.command.Add("AGFreeze", {
	description = "Заморозить/разморозить игрока (переключение).",
	adminOnly = true,
	arguments = {ix.type.player},
	OnRun = function(self, client, target)
		if (!client:AGHasPerm("freeze")) then return NoPerm(client, "freeze") end
		if (!IsValid(target)) then return "Игрок не найден." end
		if (!client:AGCanTarget(target)) then return DENY end

		if (target:GetNetVar("agFrozen", false)) then
			target:SetNetVar("agFrozen", false)
			target:SetWalkSpeed(ix.config.Get("walkSpeed"))
			target:SetRunSpeed(ix.config.Get("runSpeed"))
			target:Notify("Вас разморозили.")
		else
			target:SetNetVar("agFrozen", true)
			target:SetWalkSpeed(1)
			target:SetRunSpeed(1)
			target:Notify("Вас заморозил администратор " .. client:Nick() .. ".")
		end
		PLUGIN:LogAdmin(("%s FREEZE→%s (%s)"):format(client:Nick(), tostring(target:GetNetVar("agFrozen")), target:Nick()))
	end
})

-- ---------------- WARN ----------------
ix.command.Add("AGWarn", {
	description = "Выдать предупреждение (warn).",
	adminOnly = true,
	arguments = {ix.type.player, ix.type.text},
	OnRun = function(self, client, target, reason)
		if (!client:AGHasPerm("warn")) then return NoPerm(client, "warn") end
		if (!IsValid(target)) then return "Игрок не найден." end
		if (!client:AGCanTarget(target)) then return DENY end

		PLUGIN:AddWarn(target:SteamID64(), {
			reason = reason, admin = client:Nick(), time = os.date("%H:%M %d.%m.%Y")
		})
		target:SetNetVar("agWarns", (target:GetNetVar("agWarns", 0) or 0) + 1)
		target:Notify("ПОЛУЧЕНО ПРЕДУПРЕЖДЕНИЕ: " .. reason .. " (от " .. client:Nick() .. ")")
		client:Notify("Warn выдан: " .. target:Nick())
		PLUGIN:LogAdmin(("%s WARN→%s: %s"):format(client:Nick(), target:Nick(), reason))
	end
})

ix.command.Add("AGWarns", {
	description = "Посмотреть предупреждения игрока.",
	adminOnly = true,
	arguments = {ix.type.player},
	OnRun = function(self, client, target)
		if (!client:AGHasPerm("warn")) then return NoPerm(client, "warn") end
		local warns = PLUGIN:GetWarns(target:SteamID64())
		if (#warns == 0) then return "У " .. target:Nick() .. " нет предупреждений." end
		for i, w in ipairs(warns) do
			client:ChatPrint(("  #%d [%s] %s — %s"):format(i, w.time or "?", w.reason or "?", w.admin or "?"))
		end
	end
})

-- ---------------- KICK / BAN ----------------
ix.command.Add("AGKick", {
	description = "Кикнуть с причиной.",
	adminOnly = true,
	arguments = {ix.type.player, bit.bor(ix.type.text, ix.type.optional)},
	OnRun = function(self, client, target, reason)
		if (!client:AGHasPerm("kick")) then return NoPerm(client, "kick") end
		if (!IsValid(target)) then return "Игрок не найден." end
		if (!client:AGCanTarget(target)) then return DENY end

		reason = (reason and reason ~= "") and reason or "не указана"
		PLUGIN:LogAdmin(("%s KICK→%s: %s"):format(client:Nick(), target:Nick(), reason))
		target:Kick("Кикнут администратором " .. client:Nick() .. "\nПричина: " .. reason)
	end
})

ix.command.Add("AGBan", {
	description = "Бан: /agban <игрок> <минуты|0=перма> <причина>",
	adminOnly = true,
	arguments = {ix.type.player, ix.type.number, bit.bor(ix.type.text, ix.type.optional)},
	OnRun = function(self, client, target, minutes, reason)
		if (!client:AGHasPerm("ban")) then return NoPerm(client, "ban") end
		if (!IsValid(target)) then return "Игрок не найден." end
		if (!client:AGCanTarget(target)) then return DENY end

		minutes = math.max(0, math.floor(minutes or 60))
		reason = (reason and reason ~= "") and reason or "не указана"

		-- без perm "permaban" нельзя дольше 7 дней
		if ((minutes == 0 or minutes > 10080) and !ix.ag.GroupHasPerm(client:AGGroup(), "permaban")
			and client:AGGroupIndex() < 12) then
			return "Ваш ранг не может банить дольше 7 дней / навсегда."
		end

		local sid64 = target:SteamID64()
		PLUGIN.bans = PLUGIN.bans or {}
		PLUGIN.bans[sid64] = {
			name = target:Nick(), admin = client:Nick(),
			reason = reason,
			until_ = (minutes == 0) and 0 or (os.time() + minutes * 60),
			created = os.time()
		}
		PLUGIN:SaveBans()
		PLUGIN:LogAdmin(("%s BAN→%s (%s мин): %s"):format(client:Nick(), target:Nick(), minutes, reason))
		target:Kick(("ЗАБАНЕН: %s\nСрок: %s\nАдминистратор: %s"):format(reason,
			minutes == 0 and "НАВСЕГДА" or (minutes .. " мин."), client:Nick()))
	end
})

ix.command.Add("AGUnban", {
	description = "Разбанить по SteamID (STEAM_0:… / 64).",
	adminOnly = true,
	arguments = {bit.bor(ix.type.string, ix.type.optional)},
	OnRun = function(self, client, steam)
		if (!client:AGHasPerm("unban")) then return NoPerm(client, "unban") end
		if (!steam or steam == "") then return "Укажите SteamID." end
		local sid64 = steam:find("^STEAM") and util.SteamIDTo64(steam) or steam
		PLUGIN.bans = PLUGIN.bans or ix.data.Get(PLUGIN.Keys.bans, {}, true, true) or {}
		if (!PLUGIN.bans[sid64]) then return "Такой SteamID не забанен." end
		PLUGIN.bans[sid64] = nil
		PLUGIN:SaveBans()
		PLUGIN:LogAdmin(("%s UNBAN→%s"):format(client:Nick(), steam))
		client:Notify("Разбанен: " .. steam)
	end
})

-- ---------------- SETNAME / SETFACTION / SETGROUP ----------------
ix.command.Add("AGSetName", {
	description = "Сменить имя персонажа игрока.",
	adminOnly = true,
	arguments = {ix.type.player, ix.type.text},
	OnRun = function(self, client, target, newName)
		if (!client:AGHasPerm("setname")) then return NoPerm(client, "setname") end
		if (!IsValid(target)) then return "Игрок не найден." end
		if (!client:AGCanTarget(target)) then return DENY end

		local char = target:GetCharacter()
		if (!char) then return "У игрока нет персонажа." end
		local old = char:GetName()
		char:SetName(newName)
		PLUGIN:LogAdmin(("%s RENAME %s → %s"):format(client:Nick(), old, newName))
		target:Notify("Ваше имя изменено: " .. newName)
	end
})

ix.command.Add("AGSetFaction", {
	description = "Перевести персонажа во фракцию (citizen/cp/overwatch/resistance/administration).",
	adminOnly = true,
	arguments = {ix.type.player, ix.type.string},
	OnRun = function(self, client, target, factionName)
		if (!client:AGHasPerm("setfaction")) then return NoPerm(client, "setfaction") end
		if (!IsValid(target)) then return "Игрок не найден." end
		if (!client:AGCanTarget(target)) then return DENY end

		local faction
		for _, f in ipairs(ix.faction.indices) do
			if (f.uniqueID:lower() == factionName:lower() or f.name:lower():find(factionName:lower(), 1, true)) then
				faction = f break
			end
		end
		if (!faction) then return "Фракция не найдена: " .. factionName end

		local char = target:GetCharacter()
		if (!char) then return "У игрока нет персонажа." end
		char:SetFaction(faction.index)
		target:SetTeam(faction.index)
		target:Spawn()
		PLUGIN:LogAdmin(("%s SETFACTION %s → %s"):format(client:Nick(), target:Nick(), faction.uniqueID))
		target:Notify("Вас перевели во фракцию: " .. faction.name)
	end
})

ix.command.Add("AGSetGroup", {
	description = "Выдать ранг: /agsetgroup <игрок> <ранг> (user для снятия). Ранги: " ..
		"moderator,eventer,admin,sr_eventer,sr_admin,rar_eventer,rar_admin,curator_helper,curator_events,curator_recruitment,curator_admin,inspector,manager,junior_dev,deputy_head,manager_head,developer,tech_admin,spec_admin,arkham_team,marshall",
	superAdminOnly = true,
	arguments = {ix.type.player, ix.type.string},
	OnRun = function(self, client, target, groupKey)
		if (!client:AGHasPerm("setgroup")) then return NoPerm(client, "setgroup") end
		if (!IsValid(target)) then return "Игрок не найден." end
		if (!ix.ag.GROUPS[groupKey]) then return "Нет такой группы: " .. groupKey end

		-- Нельзя выдать ранг выше собственного, а marshall — только marshall
		if (ix.ag.GroupData(groupKey).index >= client:AGGroupIndex()) then
			return "Нельзя выдавать ранг выше или равный вашему."
		end
		if (groupKey == "marshall" and client:AGGroup() ~= "marshall") then
			return "Ранг MARSHALL назначает только MARSHALL."
		end

		local ok, err = PLUGIN:SetGroup(target, groupKey, client)
		if (!ok) then return err end
	end
})

-- ---------------- ОБЩЕЕ ----------------
ix.command.Add("AGGroups", {
	description = "Список рангов AfterGlow с весами.",
	adminOnly = true,
	OnRun = function(self, client)
		for _, key in ipairs(ix.ag.GROUP_ORDER) do
			local g = ix.ag.GROUPS[key]
			client:ChatPrint(("  [%02d] %-20s %s"):format(g.index, key, g.name))
		end
	end
})
