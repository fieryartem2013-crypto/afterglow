-- мета-методы игрока: группа/права/иммунитет (shared)
local PLAYER = FindMetaTable("Player")

function PLAYER:AGGroup()
	return self:GetNetVar("agGroup", "user")
end

function PLAYER:AGGroupIndex()
	return ix.ag.GroupData(self:AGGroup()).index
end

function PLAYER:AGHasPerm(perm)
	return ix.ag.GroupHasPerm(self:AGGroup(), perm)
end

function PLAYER:IsAGStaff()
	return self:AGGroupIndex() > 0
end

-- может ли self воздействовать на target (строго по весу ранга)
function PLAYER:AGCanTarget(target)
	if (target == self) then return true end -- на себя можно (например unfreeze)
	return self:AGGroupIndex() > target:AGGroupIndex()
end
