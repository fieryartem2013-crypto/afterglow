-- ============================================================
-- AFTERGLOW MAIN MENU (ag_mainmenu)
-- Замена стандартного ixCharMenu: перехват net-протокола
-- персонажей Helix и отрисовка AGCharMenu (HL:A-стиль).
-- ============================================================
PLUGIN.name = "AfterGlow Main Menu"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Кастомный экран выбора/создания персонажа вместо ixCharMenu."

local PLUGIN = PLUGIN

if (SERVER) then return end

ix.util.IncludeDir(PLUGIN.folder .. "/derma")

-- ------------------------------------------------------------
-- КЛЮЧЕВОЕ: после загрузки персонажа меню ОБЯЗАНО закрыться
-- (штатный CharacterLoaded-хук убирает только ix.gui.characterMenu)
-- ------------------------------------------------------------
function PLUGIN:CharacterLoaded(character)
	if (IsValid(ix.gui.agCharMenu)) then
		ix.gui.agCharMenu:CloseMenu()
	end
end

-- ------------------------------------------------------------
-- ПЕРЕХВАТ ПРОТОКОЛА ПЕРСОНАЖЕЙ (регистрируемся ПОСЛЕ ядра → перекрываем)
-- ------------------------------------------------------------

-- сервер → клиент: список персонажей + открыть меню
net.Receive("ixCharacterMenu", function()
	local indices = net.ReadUInt(6)
	local charList = {}

	for _ = 1, indices do
		charList[#charList + 1] = net.ReadUInt(32)
	end

	if (charList) then
		ix.characters = charList
	end

	if (IsValid(ix.gui.agCharMenu)) then
		ix.gui.agCharMenu:RebuildDeck()
	else
		vgui.Create("AGCharMenu")
	end
end)

-- сервер → клиент: персонаж создан (ответ на ixCharacterCreate)
net.Receive("ixCharacterAuthed", function()
	local id = net.ReadUInt(32)
	local indices = net.ReadUInt(6)
	local charList = {}

	for _ = 1, indices do
		charList[#charList + 1] = net.ReadUInt(32)
	end

	ix.characters = charList

	local menu = ix.gui.agCharMenu
	if (IsValid(menu)) then
		menu.createBusy = false
		menu:RebuildDeck()
		menu:ShowNotice("Персонаж создан", ix.ag.C.green)

		if (!LocalPlayer():GetCharacter() and id) then
			-- первый персонаж — входим сразу
			menu:CloseMenu()
			timer.Simple(0.3, function()
				net.Start("ixCharacterChoose")
					net.WriteUInt(id, 32)
				net.SendToServer()
			end)
		else
			menu:CloseCreation()
		end
	else
		if (id) then
			net.Start("ixCharacterChoose")
				net.WriteUInt(id, 32)
			net.SendToServer()
		end
	end
end)

net.Receive("ixCharacterAuthFailed", function()
	local fault = net.ReadString()
	local args = net.ReadTable()

	local menu = ix.gui.agCharMenu
	if (IsValid(menu)) then
		menu.createBusy = false
		local text = fault
		if (args and #args > 0) then
			local ok, msg = pcall(L, fault, unpack(args))
			text = ok and msg or fault
		else
			local ok, msg = pcall(L, fault)
			text = ok and msg or fault
		end
		menu:ShowNotice("Ошибка: " .. text, ix.ag.C.red)
	else
		ix.util.Notify(L(fault, unpack(args)))
	end
end)

-- сервер → всем: персонаж удалён
net.Receive("ixCharacterDelete", function()
	local id = net.ReadUInt(32)

	ix.char.loaded[id] = nil
	if (ix.characters) then
		for k, v in ipairs(ix.characters) do
			if (v == id) then
				table.remove(ix.characters, k)
				break
			end
		end
	end

	if (IsValid(ix.gui.agCharMenu)) then
		ix.gui.agCharMenu:RebuildDeck()
	end
end)

-- неудача выбора персонажа: показываем в НАШЕМ меню
net.Receive("ixCharacterLoadFailure", function()
	local message = net.ReadString()

	if (isstring(message) and message:sub(1, 1) == "@") then
		message = L(message:sub(2))
	end
	message = message ~= "" and message or L("unknownError")

	local menu = ix.gui.agCharMenu
	if (IsValid(menu)) then
		menu:ShowNotice(message, ix.ag.C.red)
	else
		ix.util.Notify(message)
	end
end)
