-- ============================================================
-- AGCharMenu — экран выбора/создания персонажа (HL:A-стиль)
-- Абсолютная раскладка карточек (без DHorizontalScroller):
-- центрированный ряд, адаптивная ширина карточки.
-- ============================================================
local PANEL = {}

local CARD_H = 420
local GAP = 12

function PANEL:Init()
	self:SetSize(ScrW(), ScrH())
	self:MakePopup()
	self:SetKeyboardInputEnabled(false)
	ix.gui.agCharMenu = self

	self.created = RealTime()
	self.createPanel = nil
	self.createBusy = false
	self.cards = {}

	-- ===== верхняя плашка =====
	local header = self:Add("Panel")
	header:SetSize(ScrW(), 96)
	header.Paint = function(_, w, h)
		surface.SetDrawColor(4, 7, 10, 200)
		surface.DrawRect(0, 0, w, h)
		ix.ag.DrawNeonEdge(0, h - 1, w, ix.ag.C.neon, 130)

		draw.SimpleText("λ", "AG.HL2Icons", 30, 18, ix.ag.C.amber)
		draw.SimpleText("AFTERGLOW", "AG.BigB", 60, 22, ix.ag.C.text)
		draw.SimpleText("// РЕГИСТРАЦИЯ ГРАЖДАНИНА В СЕТИ АЛЬЯНСА", "AG.Mono", 60, 56, ix.ag.C.neon)
		draw.SimpleText(GetHostName(), "AG.Small", w - 24, 28, ix.ag.C.textDim, TEXT_ALIGN_RIGHT)
		draw.SimpleText(LocalPlayer():SteamID(), "AG.MonoSmall", w - 24, 50, ix.ag.C.textMute, TEXT_ALIGN_RIGHT)
	end

	-- ===== уведомления =====
	self.notice = self:Add("DLabel")
	self.notice:SetFont("AG.MediumB")
	self.notice:SetTextColor(ix.ag.C.green)
	self.notice:SetContentAlignment(5)
	self.notice:SetAlpha(0)
	self.notice:SetText("")

	-- ===== зона карточек (абсолютная раскладка) =====
	self.deckWrap = self:Add("Panel")
	self.deckWrap:SetPos(0, 120)
	self.deckWrap:SetSize(ScrW(), CARD_H + 60)

	-- ===== футер =====
	local footer = self:Add("Panel")
	footer:SetPos(0, ScrH() - 60)
	footer:SetSize(ScrW(), 60)
	footer.Paint = function(_, w, h)
		draw.SimpleText("AFTERGLOW v1.2.3  •  выбор гражданина", "AG.Tiny",
			w / 2, h / 2, ix.ag.C.textMute, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	local dc = self:Add("AGButton")
	dc:SetText("ОТКЛЮЧИТЬСЯ")
	dc:SetVariant("danger")
	dc:SetSize(170, 34)
	dc:SetPos(24, ScrH() - 48)
	dc.DoClick = function() RunConsoleCommand("disconnect") end

	self:RebuildDeck()
end

function PANEL:CloseMenu()
	gui.EnableScreenClicker(false)
	if (IsValid(self.createPanel)) then
		self.createPanel:Remove()
		self.createPanel = nil
	end
	self:Remove()
end

function PANEL:OnRemove()
	if (ix.gui.agCharMenu == self) then
		ix.gui.agCharMenu = nil
	end
end

-- -----------------------------------------------------------
-- КАРТОЧКИ ПЕРСОНАЖЕЙ (абсолютная раскладка, центрирование)
-- -----------------------------------------------------------
function PANEL:RebuildDeck()
	if (!IsValid(self.deckWrap)) then return end
	self.deckWrap:Clear()
	self.cards = {}

	local chars = ix.characters or {}
	local max = ix.config.Get("maxCharacters", 5)

	-- какие карточки нужны
	local needed = {}
	for _, charID in ipairs(chars) do
		local character = ix.char.loaded[charID]
		if (character) then
			needed[#needed + 1] = {kind = "char", character = character, id = charID}
		end
	end
	local canCreate = (#needed < max)
	if (canCreate) then
		needed[#needed + 1] = {kind = "create"}
	end

	local n = math.max(#needed, 1)
	-- адаптивная ширина карточки: уместить в 90% экрана
	local availW = ScrW() * 0.9
	local cardW = math.floor(math.min(300, (availW - GAP * (n - 1)) / n))
	local totalW = cardW * n + GAP * (n - 1)
	local x0 = math.floor((ScrW() - totalW) / 2)
	local y0 = math.floor((self.deckWrap:GetTall() - CARD_H) / 2) + 6

	for i, def in ipairs(needed) do
		local x = x0 + (i - 1) * (cardW + GAP)
		if (def.kind == "char") then
			self.cards[i] = self:BuildCharCard(self.deckWrap, x, y0, cardW, CARD_H, def.id, def.character, n)
		else
			self.cards[i] = self:BuildCreateCard(self.deckWrap, x, y0, cardW, CARD_H)
		end
	end

	if (#needed == 0) then
		local empty = self.deckWrap:Add("Panel")
		empty:SetSize(600, 70)
		empty:SetPos(ScrW() / 2 - 300, y0 + CARD_H / 2 - 40)
		empty.Paint = function(_, w, h)
			draw.SimpleText("ЗАГРУЗКА СПИСКА ГРАЖДАН…", "AG.MediumB",
				w / 2, h / 2, ix.ag.C.textDim, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

function PANEL:BuildCharCard(parent, x, y, w2, h2, charID, character, totalCards)
	local card = parent:Add("AGPanel")
	card:SetPos(x, y)
	card:SetSize(w2, h2)
	card:SetEdgeColor(ix.ag.C.neon)
	card.DoCustom = function(c, cw, ch)
		local f = ix.faction.indices[character:GetFaction()]
		if (f) then
			surface.SetDrawColor(f.color)
			surface.DrawRect(0, 0, cw, 3)
			draw.SimpleText(f.name:upper(), "AG.Tiny", 8, 7, f.color)
		end
		local class = ix.class.list[character:GetClass()]
		if (class) then
			draw.SimpleText(class.name, "AG.Tiny", cw - 8, 7, ix.ag.C.textDim, TEXT_ALIGN_RIGHT)
		end
	end

	-- мини-3D (компактнее при широкой колоде)
	local modelH = h2 - (totalCards > 3 and 170 or 160)
	local mv = card:Add("AGModelView")
	mv:SetPos(6, 24)
	mv:SetSize(w2 - 12, modelH)
	mv:SetFOV(28)
	mv:SetToolTip(false)
	mv:ShowModel(character:GetModel())

	local nameY = 24 + modelH + 6
	local nm = card:Add("DLabel")
	nm:SetPos(10, nameY)
	nm:SetText(character:GetName())
	nm:SetFont("AG.MediumB")
	nm:SetTextColor(ix.ag.C.text)
	nm:SizeToContents()
	if (nm:GetWide() > w2 - 20) then
		nm:SetWide(w2 - 20)
		nm:SetAutoStretchVertical(false)
	end

	local info = card:Add("DLabel")
	info:SetPos(10, nameY + 24)
	local cid = character:GetData("cid")
	info:SetText("CID: " .. tostring(cid or "не присвоен"))
	info:SetFont("AG.Small")
	info:SetTextColor(ix.ag.C.amber)
	info:SizeToContents()

	-- ВХОД
	local play = card:Add("AGButton")
	play:SetText("ВОЙТИ В ГОРОД")
	play:SetVariant("primary")
	play:SetSize(w2 - 20, 36)
	play:SetPos(10, h2 - 78)
	play.OnCursorEntered = function() ix.ag.Click(true) end
	play.DoClick = function()
		ix.ag.Click()
		-- закрываем меню ПРИ ОТПРАВКЕ (CharacterLoaded подстрахует)
		self:CloseMenu()
		net.Start("ixCharacterChoose")
			net.WriteUInt(charID, 32)
		net.SendToServer()
	end

	-- УДАЛИТЬ
	local del = card:Add("AGButton")
	del:SetText("УДАЛИТЬ ПЕРСОНАЖА")
	del:SetVariant("danger")
	del:SetSize(w2 - 20, 26)
	del:SetPos(10, h2 - 36)
	del.DoClick = function()
		ix.ag.Click()
		ix.ag.Prompt("Удалить персонажа? (" .. character:GetName() .. ")", "напишите: УДАЛИТЬ", function(text)
			if (string.upper(string.Trim(text)) == "УДАЛИТЬ") then
				net.Start("ixCharacterDelete")
					net.WriteUInt(charID, 32)
				net.SendToServer()
			end
		end)
	end

	return card
end

function PANEL:BuildCreateCard(parent, x, y, w2, h2)
	local card = parent:Add("AGPanel")
	card:SetPos(x, y)
	card:SetSize(w2, h2)
	card:SetEdgeColor(ix.ag.C.green)
	card.DoCustom = function(c, cw, ch)
		surface.SetDrawColor(ix.ag.C.green.r, ix.ag.C.green.g, ix.ag.C.green.b, 6)
		surface.DrawRect(0, 0, cw, ch)
		draw.SimpleText("+", "AG.BigB", cw / 2, ch / 2 - 70, ix.ag.C.green, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText("НОВЫЙ ГРАЖДАНИН", "AG.MediumB", cw / 2, ch / 2 - 16, ix.ag.C.text, TEXT_ALIGN_CENTER)
		draw.SimpleText("Регистрация в сети Альянса", "AG.Small", cw / 2, ch / 2 + 12, ix.ag.C.textDim, TEXT_ALIGN_CENTER)
	end

	local go = card:Add("AGButton")
	go:SetText("СОЗДАТЬ")
	go:SetVariant("green")
	go:SetSize(w2 - 40, 40)
	go:SetPos(20, h2 - 60)
	go.DoClick = function()
		ix.ag.Click()
		self:ShowCreation()
	end

	return card
end

-- -----------------------------------------------------------
-- СОЗДАНИЕ ПЕРСОНАЖА
-- -----------------------------------------------------------
function PANEL:ShowCreation()
	if (IsValid(self.createPanel)) then self.createPanel:Remove() end

	local w, h2 = 660, 600
	local pnl = self:Add("AGPanel")
	pnl:SetSize(w, h2)
	pnl:SetPos(ScrW() / 2 - w / 2, ScrH() / 2 - h2 / 2)
	pnl:SetDrawOnTop(true)
	pnl:SetEdgeColor(ix.ag.C.amber)
	pnl:MakePopup()
	self.createPanel = pnl
	self.createBusy = false

	local title = pnl:Add("DLabel")
	title:SetText("РЕГИСТРАЦИЯ // НОВЫЙ ГРАЖДАНИН")
	title:SetFont("AG.MediumB")
	title:SetTextColor(ix.ag.C.amber)
	title:SizeToContents()
	title:SetPos(16, 12)

	-- подсказка-подтверждение жизнеспособности UI
	local tip = pnl:Add("DLabel")
	tip:SetText("Шаг 1: фракция  →  шаг 2: внешность  →  шаг 3: имя и описание")
	tip:SetFont("AG.Tiny")
	tip:SetTextColor(ix.ag.C.textMute)
	tip:SizeToContents()
	tip:SetPos(16, 32)

	local y = 54
	local function Label(text, py)
		local l = pnl:Add("DLabel")
		l:SetText(text)
		l:SetFont("AG.Small")
		l:SetTextColor(ix.ag.C.textDim)
		l:SizeToContents()
		l:SetPos(16, py)
		return py + 17
	end

	-- ============ ФРАКЦИЯ ============
	y = Label("ФРАКЦИЯ:", y)
	self.createFaction = nil
	local fWrap = pnl:Add("Panel")
	fWrap:SetPos(16, y)
	fWrap:SetSize(w - 32, 62)

	local factions = {}
	for _, f in ipairs(ix.faction.indices) do
		if (ix.faction.HasWhitelist(f.index)) then
			factions[#factions + 1] = f
		end
	end

	local fx = 0
	local fw = factions[1] and (w - 32 - (#factions - 1) * 6) / #factions or 0
	for _, f in ipairs(factions) do
		local b = fWrap:Add("AGButton")
		b:SetText(f.name)
		b:SetSize(fw, 58)
		b:SetPos(fx, 0)
		b:SetVariant("ghost")
		b:SetFont("AG.SmallB")
		b.faction = f
		b.DoClick = function(btn)
			ix.ag.Click()
			self.createFaction = btn.faction
			self.createModel = 1
			for _, ob in ipairs(fWrap:GetChildren()) do ob.selectedFlag = false end
			btn.selectedFlag = true
			self.refreshModelList()
			self.createNotice("")
		end
		b.PaintOver = function(btn, bw, bh)
			if (btn.selectedFlag) then
				surface.SetDrawColor(btn.faction.color)
				surface.DrawOutlinedRect(0, 0, bw, bh, 2)
				draw.SimpleText("✓", "AG.MediumB", bw - 16, 4, btn.faction.color)
			end
		end
		fx = fx + fw + 6
	end

	if (factions[1]) then
		self.createFaction = factions[1]
		fWrap:GetChildren()[1].selectedFlag = true
	end
	y = y + 66

	-- ============ МОДЕЛЬ ============
	y = Label("ВНЕШНОСТЬ:", y)
	local modelWrap = pnl:Add("Panel")
	modelWrap:SetPos(16, y)
	modelWrap:SetSize(w - 32, 146)

	local preview = modelWrap:Add("AGModelView")
	preview:SetPos(0, 0)
	preview:SetSize(128, 146)
	preview:SetFOV(30)
	preview:SetToolTip(false)

	local modelScroll = modelWrap:Add("DIconLayout")
	modelScroll:SetPos(134, 0)
	modelScroll:SetSize(w - 32 - 134, 146)
	modelScroll:SetSpaceX(4)
	modelScroll:SetSpaceY(4)

	self.createModel = 1
	function self.refreshModelList()
		modelScroll:Clear()
		local f = self.createFaction
		if (!f) then return end
		local models = f.GetModels and f:GetModels(LocalPlayer()) or f.models or {}
		for idx, mdl in ipairs(models) do
			local path = istable(mdl) and mdl[1] or mdl
			local icon = modelScroll:Add("SpawnIcon")
			icon:SetSize(42, 42)
			icon:SetModel(path)
			icon:SetToolTip(path)
			local oldPaint = icon.Paint
			icon.Paint = function(ic, iw, ih)
				oldPaint(ic, iw, ih)
				if (self.createModel == idx) then
					surface.SetDrawColor(ix.ag.C.amber)
					surface.DrawOutlinedRect(0, 0, iw, ih, 2)
				end
			end
			icon.DoClick = function()
				ix.ag.Click()
				self.createModel = idx
				preview:ShowModel(path)
			end
		end
		local first = models[self.createModel] or models[1]
		local path = first and (istable(first) and first[1] or first)
		if (path) then preview:ShowModel(path) end
	end
	self.refreshModelList()
	y = y + 150

	-- ============ ИМЯ ============
	y = Label("ИМЯ И ФАМИЛИЯ:", y)
	local nameEntry = pnl:Add("DTextEntry")
	nameEntry:SetPos(16, y)
	nameEntry:SetSize(w - 32, 30)
	nameEntry:SetFont("AG.Medium")
	nameEntry:SetTextColor(ix.ag.C.text)
	nameEntry:SetPlaceholderText("напр. Гордон Кольцов")
	nameEntry:SetUpdateOnType(true)
	nameEntry.Paint = function(ne, nw, nh)
		surface.SetDrawColor(10, 14, 19, 235)
		surface.DrawRect(0, 0, nw, nh)
		surface.SetDrawColor(ix.ag.C.neon)
		surface.DrawOutlinedRect(0, 0, nw, nh, 1)
		ne:DrawTextEntryText(ix.ag.C.text, ix.ag.C.neon, ix.ag.C.text)
	end
	y = y + 36

	-- ============ ОПИСАНИЕ ============
	y = Label("ОПИСАНИЕ (мин. " .. ix.config.Get("descriptionMinLen", 0) .. " зн.):", y)
	local descEntry = pnl:Add("DTextEntry")
	descEntry:SetPos(16, y)
	descEntry:SetSize(w - 32, 80)
	descEntry:SetMultiline(true)
	descEntry:SetFont("AG.Small")
	descEntry:SetTextColor(ix.ag.C.text)
	descEntry:SetPlaceholderText("Возраст, рост, телосложение, приметы…")
	descEntry.Paint = nameEntry.Paint
	y = y + 88

	-- строка статуса создания
	local status = pnl:Add("DLabel")
	status:SetPos(16, y)
	status:SetText("")
	status:SetFont("AG.Small")
	status:SetTextColor(ix.ag.C.amber)
	function self.createNotice(text, col)
		status:SetText(text or "")
		status:SetTextColor(col or ix.ag.C.amber)
		status:SizeToContents()
	end
	y = y + 20

	-- ============ КНОПКИ ============
	local cancel = pnl:Add("AGButton")
	cancel:SetText("ОТМЕНА")
	cancel:SetVariant("ghost")
	cancel:SetSize(140, 36)
	cancel:SetPos(16, h2 - 48)
	cancel.DoClick = function()
		ix.ag.Click()
		self:CloseCreation()
	end

	local create = pnl:Add("AGButton")
	create:SetText("ЗАРЕГИСТРИРОВАТЬ")
	create:SetVariant("green")
	create:SetSize(w - 180, 36)
	create:SetPos(164, h2 - 48)

	local function TryCreate()
		if (self.createBusy) then return end
		if (!self.createFaction) then
			return self.createNotice("Сначала выберите фракцию", ix.ag.C.red)
		end
		local name = string.Trim(nameEntry:GetValue())
		local desc = string.Trim(descEntry:GetValue())
		if (name == "") then
			return self.createNotice("Укажите имя персонажа", ix.ag.C.red)
		end

		self.createBusy = true
		create:SetEnabled(false)
		create:SetText("ОТПРАВКА…")
		self.createNotice("Отправляем в сеть Альянса…")

		net.Start("ixCharacterCreate")
			local count = 0
			local payload = {
				faction = self.createFaction.index,
				model = self.createModel or 1,
				name = name,
				description = desc
			}
			for k, v in pairs(payload) do count = count + 1 end
			net.WriteUInt(count, 8)
			for k, v in pairs(payload) do
				net.WriteString(k)
				net.WriteType(v)
			end
		net.SendToServer()

		-- страховка от вечного «ОТПРАВКА…» при потере пакета
		timer.Create("agCreateTimeout", 8, 1, function()
			if (IsValid(self) and self.createBusy) then
				self.createBusy = false
				if (IsValid(create)) then
					create:SetEnabled(true)
					create:SetText("ЗАРЕГИСТРИРОВАТЬ")
				end
				self.createNotice("Тайм-аут. Проверьте ошибки в консоли и повторите.", ix.ag.C.red)
			end
		end)
	end
	create.DoClick = function() ix.ag.Click() TryCreate() end
	nameEntry.OnEnter = function() TryCreate() end
	descEntry.OnEnter = function() TryCreate() end
end

function PANEL:CloseCreation()
	if (IsValid(self.createPanel)) then
		self.createPanel:Remove()
		self.createPanel = nil
	end
end

-- -----------------------------------------------------------
-- УВЕДОМЛЕНИЕ / ФОН
-- -----------------------------------------------------------
function PANEL:ShowNotice(text, col)
	self.notice:SetText(text)
	self.notice:SetTextColor(col or ix.ag.C.green)
	self.notice:SizeToContents()
	self.notice:SetPos(ScrW() / 2 - self.notice:GetWide() / 2, 100)
	self.notice:SetAlpha(255)
	self.notice:AlphaTo(0, 0.6, 3)
end

function PANEL:Paint(w, h)
	ix.ag.DrawBlur(self, 2.5)
	surface.SetDrawColor(4, 6, 10, 240)
	surface.DrawRect(0, 0, w, h)

	-- анимированная голографическая «городская сетка»
	local t = RealTime() - self.created
	local gridCol = ix.ag.C.neon
	for gx = 0, 14 do
		local x = (gx * 140 + t * 18) % (w + 280) - 140
		surface.SetDrawColor(gridCol.r, gridCol.g, gridCol.b, 5)
		surface.DrawRect(x, h * 0.25, 2, h * 0.75)
	end
	for gy = 0, 8 do
		local gy2 = h * 0.25 + gy * 70 + math.sin(t * 0.6 + gy) * 6
		surface.SetDrawColor(gridCol.r, gridCol.g, gridCol.b, 4)
		surface.DrawRect(0, gy2, w, 1)
	end

	ix.ag.DrawScanlines(0, 0, w, h, 3)
end

vgui.Register("AGCharMenu", PANEL, "EditablePanel")
