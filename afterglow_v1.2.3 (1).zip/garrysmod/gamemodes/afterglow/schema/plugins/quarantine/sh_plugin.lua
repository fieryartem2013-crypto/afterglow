-- ============================================================
-- МОДУЛЬ 1: Карантинная Зона (фильтры, токсины, фауна Зена)
-- Файлы модуля:
--   sh_plugin.lua      — ядро: зоны, тики расхода фильтра, урон,
--                        директор спавна NPC, лут, админ-команды
--   meta/sh_player.lua — PLAYER:GetGasMask()/IsInQuarantineZone()
--   derma/cl_hud.lua   — HUD-оверлей зоны и шкала фильтра
-- ============================================================
PLUGIN.name = "Quarantine Zone"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Карантинная Зона: заражённые области, расход фильтров противогаза, токсичный урон и экосистема Зена."

local PLUGIN = PLUGIN  -- захват глобала: в колбэках hook.Add/net.Receive глобал PLUGIN после загрузки указывает на другой плагин/nil

ix.util.Include("meta/sh_player.lua")
if (CLIENT) then
	ix.util.Include("derma/cl_hud.lua")
end

-- ------------------------------------------------------------
-- Конфигурация (меняется в игре: /config)
-- ------------------------------------------------------------
ix.config.Add("qzFilterDrainPerSecond", 0.17, "Расход фильтра противогаза в %/сек в зоне 1 уровня (x2.5 на 2 уровне).")
ix.config.Add("qzToxinDamage", 5, "Урон токсином за тик без защиты (умножается на уровень зоны).")
ix.config.Add("qzToxinInterval", 3, "Интервал тиков токсичного урона (сек).")
ix.config.Add("qzInfectionChance", 0.15, "Шанс заражения спорами за тик в зоне 2 уровня без защиты.")
ix.config.Add("qzNpcCap", 30, "Глобальный лимит NPC Зена.")
ix.config.Add("qzNpcPerTick", 2, "Максимум спавнов NPC за один цикл директора.")
ix.config.Add("qzSpawnInterval", 12, "Цикл директора спавна (сек).")
ix.config.Add("qzDespawnDist", 2600, "Дистанция от всех игроков, на которой NPC Зена снимается.")
ix.config.Add("qzMinSpawnDist", 650, "Минимальная дистанция до игрока для спавна (во избежание поп-ина).")

-- ------------------------------------------------------------
-- Реестр зон (shared: клиенту нужны зоны для HUD/эффектов)
-- Зона: {name, min(Vector), max(Vector}, level(1-2)}
-- ------------------------------------------------------------
ix.qz = ix.qz or {}
ix.qz.zones = ix.qz.zones or {}

function ix.qz.NormalizeBox(a, b)
	return Vector(math.min(a.x, b.x), math.min(a.y, b.y), math.min(a.z, b.z)),
	       Vector(math.max(a.x, b.x), math.max(a.y, b.y), math.max(a.z, b.z))
end

-- Типы зон: gas (стандарт), spore (повышенное заражение), radiation (урон x1.5, без спор)
ix.qz.ZONE_TYPES = {"gas", "spore", "radiation"}

function ix.qz.AddZone(name, a, b, level, zoneType)
	local min, max = ix.qz.NormalizeBox(a, b)
	zoneType = zoneType or "gas"
	for _, z in ipairs(ix.qz.zones) do
		if (z.name == name) then
			z.min, z.max, z.level, z.type = min, max, level or 1, zoneType
			return z
		end
	end
	local zone = {name = name, min = min, max = max, level = level or 1, type = zoneType}
	table.insert(ix.qz.zones, zone)
	return zone
end

-- алиас ix.zone (ТЗ мегапромпта №3)
ix.zone = ix.qz

function ix.qz.RemoveZone(name)
	for i, z in ipairs(ix.qz.zones) do
		if (z.name == name) then table.remove(ix.qz.zones, i) return true end
	end
end

function ix.qz.GetZoneAt(pos)
	for _, z in ipairs(ix.qz.zones) do
		if (z.shape == "sphere" and z.spherePos and z.sphereRadius) then
			if (pos:DistToSqr(z.spherePos) <= z.sphereRadius * z.sphereRadius) then return z end
		elseif (pos:WithinAABox(z.min, z.max)) then
			return z
		end
	end
end

-- Сферические зоны (совместимость с ix.qz.zones; min/max используются как AABB-кэш)
function ix.qz.AddSphereZone(name, center, radius, level, zoneType)
	local zone = {
		name = name,
		shape = "sphere",
		spherePos = center,
		sphereRadius = radius,
		min = center - Vector(radius, radius, radius),
		max = center + Vector(radius, radius, radius),
		level = level or 1,
		type = zoneType or "gas"
	}
	for _, z in ipairs(ix.qz.zones) do
		if (z.name == name) then z = zone return z end
	end
	table.insert(ix.qz.zones, zone)
	return zone
end

-- Сохранение/загрузка (ix.data, по-карточно)
function PLUGIN:SaveZones()
	local out = {}
	for _, z in ipairs(ix.qz.zones) do
		table.insert(out, {name = z.name, min = {z.min.x, z.min.y, z.min.z}, max = {z.max.x, z.max.y, z.max.z}, level = z.level, type = z.type or "gas"})
	end
	ix.data.Set("qzZones", out, false, false)
end

function PLUGIN:LoadZones()
	ix.qz.zones = {}
	for _, z in ipairs(ix.data.Get("qzZones", {}, false, false)) do
		ix.qz.AddZone(z.name, Vector(z.min[1], z.min[2], z.min[3]), Vector(z.max[1], z.max[2], z.max[3]), z.level, z.type)
	end
end

function PLUGIN:InitPostEntity()
	self:LoadZones()
	self:LoadSpawnPoints()
end

-- ============================================================
-- СЕРВЕР: расход фильтров + фатальный урон отсутствия защиты
-- ============================================================
if (SERVER) then
	util.AddNetworkString("ixQZToxin")

	-- Главный секундный цикл модуля
	function PLUGIN:Tick()
		local time = CurTime()
		if ((self.nextThink or 0) > time) then return end
		self.nextThink = time + 1

		for _, client in player.Iterator() do
			local character = client:GetCharacter()
			if (character and client:Alive() and client:GetMoveType() != MOVETYPE_NOCLIP) then
				self:ProcessPlayer(client, character, time)
			end
		end
	end

	function PLUGIN:ProcessPlayer(client, character, time)
		local zone = ix.qz.GetZoneAt(client:GetPos())
		local bInZone = zone != nil

		-- Синхронизация состояния для HUD (меняется редко)
		local oldZone = client:GetNetVar("qzZone")
		if (bInZone and (oldZone == nil or oldZone.name != zone.name)) then
			client:SetNetVar("qzZone", {name = zone.name, level = zone.level})
		elseif (!bInZone and oldZone != nil) then
			client:SetNetVar("qzZone", nil)
		end

		if (!bInZone) then
			client.nextQZToxin = nil
			return
		end

		local mask = client:GetGasMask()
		if (mask) then
			-- Расход фильтра
			local drain = ix.config.Get("qzFilterDrainPerSecond", 0.17) * (zone.level >= 2 and 2.5 or 1)
			local left = math.max(0, mask:GetData("filter", 0) - drain)
			mask:SetData("filter", left)

			if (left <= 0) then
				if (!client:GetNetVar("qzEmptyWarned", false)) then
					client:Notify("КЛАПАН ФИЛЬТРА ХЛОПНУЛ В ПУСТОТУ. ВЫ ДЫШИТЕ ЗЕНОМ.")
					client:SetNetVar("qzEmptyWarned", true)
				end
				self:ApplyToxin(client, zone, time)
			elseif (left > 1) then
				client:SetNetVar("qzEmptyWarned", false)
			end
		else
			-- Нет противогаза — полная доза
			self:ApplyToxin(client, zone, time)
		end
	end

	-- ФАТАЛЬНАЯ ФУНКЦИЯ: урон от отсутствия фильтра/противогаза
	function PLUGIN:ApplyToxin(client, zone, time)
		if ((client.nextQZToxin or 0) > time) then return end
		-- иммунитет на уровне модуля (напр. исправные очистители ГСР)
		if (hook.Run("AGZoneToxinImmune", client, zone)) then return end
		client.nextQZToxin = time + ix.config.Get("qzToxinInterval", 3)

		local typeMul = (zone.type == "radiation") and 1.5 or 1
		local damage = ix.config.Get("qzToxinDamage", 5) * zone.level * typeMul

		local dmg = DamageInfo()
		dmg:SetDamage(damage)
		dmg:SetDamageType(DMG_NERVEGAS)
		dmg:SetDamagePosition(client:GetPos() + Vector(0, 0, 48))
		client:TakeDamageInfo(dmg)

		-- Кашель + экранные эффекты клиенту
		client:EmitSound("ambient/voices/cough" .. math.random(1, 4) .. ".wav", 60, math.random(90, 110))
		net.Start("ixQZToxin")
			net.WriteUInt(zone.level, 4)
		net.Send(client)

		-- Заражение спорами (связка с модулем медицины)
		if (ix.medical and ix.medical.Infect) then
			local chance = (zone.level >= 2) and ix.config.Get("qzInfectionChance", 0.15) or 0.03
			if (math.random() < chance) then
				ix.medical.Infect(client, 1)
			end
		end
	end
end

-- ============================================================
-- ДИРЕКТОР СПАВНА ФАУНЫ ЗЕНА + ЛУТ
-- ============================================================
PLUGIN.SpawnPoints = PLUGIN.SpawnPoints or {} -- {pos=Vector, level=1..2, kind="ground"|"ceiling"}
PLUGIN.SpawnedNPCs = PLUGIN.SpawnedNPCs or {}

PLUGIN.NPCByLevel = {
	[1] = {
		{class = "npc_headcrab", weight = 5},
		{class = "npc_headcrab_fast", weight = 3}, -- «бронированный» раннер до установки HL:A моделей
		{class = "npc_zombie", weight = 4}
	},
	[2] = {
		{class = "npc_headcrab_fast", weight = 4},
		{class = "npc_headcrab_black", weight = 3}, -- ядовитый
		{class = "npc_fastzombie", weight = 4},
		{class = "npc_poisonzombie", weight = 2},
		{class = "npc_zombie", weight = 3}
	}
}

-- Лут с NPC: {itemUniqueID, шанс}
PLUGIN.LootTable = {
	npc_headcrab       = {{"xen_tissue", 0.45}},
	npc_headcrab_fast  = {{"xen_tissue", 0.40}},
	npc_headcrab_black = {{"headcrab_gland", 0.60}, {"xen_tissue", 0.40}},
	npc_zombie         = {{"xen_tissue", 0.35}},
	npc_fastzombie     = {{"xen_tissue", 0.45}},
	npc_poisonzombie   = {{"headcrab_gland", 0.50}, {"xen_tissue", 0.60}, {"vortessence", 0.03}}
}

if (SERVER) then
	function PLUGIN:PickNPCClass(level)
		local pool = self.NPCByLevel[level] or self.NPCByLevel[1]
		local total = 0
		for _, v in ipairs(pool) do total = total + v.weight end
		local roll = math.random() * total
		for _, v in ipairs(pool) do
			roll = roll - v.weight
			if (roll <= 0) then return v.class end
		end
		return pool[1].class
	end

	function PLUGIN:DirectorThink()
		local time = CurTime()
		if ((self.nextDirector or 0) > time) then return end
		self.nextDirector = time + ix.config.Get("qzSpawnInterval", 12)

		local cap = ix.config.Get("qzNpcCap", 30)

		-- чистим/учитываем существующих
		local alive = {}
		for _, npc in ipairs(self.SpawnedNPCs) do
			if (IsValid(npc)) then table.insert(alive, npc) end
		end
		self.SpawnedNPCs = alive
		if (#alive >= cap) then return end

		local players = player.GetAll()
		if (#players == 0) then return end

		local spawned = 0
		for _, point in ipairs(self.SpawnPoints) do
			if (spawned >= ix.config.Get("qzNpcPerTick", 2)) then break end
			if ((point.nextSpawn or 0) > time) then continue end

			-- спаун только если поблизости есть игроки, но не прямо под носом
			local nearest = math.huge
			for _, ply in ipairs(players) do
				if (ply:Alive()) then
					nearest = math.min(nearest, ply:GetPos():DistToSqr(point.pos))
				end
			end
			local minD = ix.config.Get("qzMinSpawnDist", 650) ^ 2
			if (nearest < minD or nearest > (2400 ^ 2)) then continue end

			local npc = ents.Create(point.kind == "ceiling" and "npc_barnacle" or self:PickNPCClass(point.level))
			if (IsValid(npc)) then
				npc:SetPos(point.pos)
				npc:Spawn()
				npc.qzSpawned = true
				table.insert(self.SpawnedNPCs, npc)
				point.nextSpawn = time + math.random(25, 60)
				spawned = spawned + 1
			end
		end

		-- деспаун дальних
		local despawn = ix.config.Get("qzDespawnDist", 2600) ^ 2
		for _, npc in ipairs(self.SpawnedNPCs) do
			if (IsValid(npc)) then
				local nearest = math.huge
				for _, ply in ipairs(players) do
					if (ply:Alive()) then
						nearest = math.min(nearest, ply:GetPos():DistToSqr(npc:GetPos()))
					end
				end
				if (nearest > despawn) then npc:Remove() end
			end
		end
	end

	function PLUGIN:Tick2() end -- зарезервировано

	-- Лут с убитой фауны
	function PLUGIN:OnNPCKilled(npc, attacker, inflictor)
		if (!npc.qzSpawned and !self.LootTable[npc:GetClass()]) then return end
		local table_ = self.LootTable[npc:GetClass()]
		if (!table_) then return end

		for _, entry in ipairs(table_) do
			if (math.random() < entry[2]) then
				ix.item.Spawn(entry[1], npc:GetPos() + Vector(0, 0, 8) + VectorRand() * 16)
			end
		end
	end

	-- Персистентные точки спавна
	function PLUGIN:SaveSpawnPoints()
		local out = {}
		for _, p in ipairs(self.SpawnPoints) do
			table.insert(out, {pos = {p.pos.x, p.pos.y, p.pos.z}, level = p.level, kind = p.kind})
		end
		ix.data.Set("qzSpawns", out, false, false)
	end

	function PLUGIN:LoadSpawnPoints()
		self.SpawnPoints = {}
		for _, p in ipairs(ix.data.Get("qzSpawns", {}, false, false)) do
			table.insert(self.SpawnPoints, {pos = Vector(p.pos[1], p.pos[2], p.pos[3]), level = p.level or 1, kind = p.kind or "ground"})
		end
	end

	hook.Add("Think", "ixQZDirector", function() PLUGIN:DirectorThink() end)
end

-- ============================================================
-- КЛИЕНТ: токсичный толчок (кашель/тряска)
-- ============================================================
if (CLIENT) then
	net.Receive("ixQZToxin", function()
		local level = net.ReadUInt(4)
		util.ScreenShake(LocalPlayer():GetPos(), 3 * level, 4, 1.2, 0)
		surface.PlaySound("ambient/voices/citizen_pain" .. math.random(1, 2) .. ".wav")
	end)
end

-- ============================================================
-- АДМИН-КОМАНДЫ НАСТРОЙКИ МИРА
-- ============================================================
do
	ix.command.Add("QZPos1", {
		description = "Задать первый угол создаваемой КЗ (по прицелу).",
		adminOnly = true,
		OnRun = function(self, client)
			client:GetCharacter():SetData("qzPos1", client:GetEyeTraceNoCursor().HitPos)
			client:Notify("КЗ: угол 1 задан.")
		end
	})

	ix.command.Add("QZPos2", {
		description = "Задать второй угол создаваемой КЗ.",
		adminOnly = true,
		OnRun = function(self, client)
			client:GetCharacter():SetData("qzPos2", client:GetEyeTraceNoCursor().HitPos)
			client:Notify("КЗ: угол 2 задан.")
		end
	})

	ix.command.Add("QZCreate", {
		description = "Создать зону карантина: /QZCreate <имя> <уровень 1-2>",
		adminOnly = true,
		arguments = {
			ix.type.string,
			bit.bor(ix.type.number, ix.type.optional)
		},
		OnRun = function(self, client, name, level)
			local ch = client:GetCharacter()
			local p1, p2 = ch:GetData("qzPos1"), ch:GetData("qzPos2")
			if (!p1 or !p2) then
				client:Notify("Сначала задайте углы: /QZPos1 и /QZPos2")
				return
			end
			ix.qz.AddZone(name, p1, p2, math.Clamp(level or 1, 1, 2))
			PLUGIN:SaveZones()
			client:Notify("Зона '" .. name .. "' (уровень " .. (level or 1) .. ") создана.")
		end
	})

	ix.command.Add("QZRemove", {
		description = "Удалить зону карантина по имени.",
		adminOnly = true,
		arguments = {ix.type.string},
		OnRun = function(self, client, name)
			if (ix.qz.RemoveZone(name)) then
				PLUGIN:SaveZones()
				client:Notify("Зона '" .. name .. "' удалена.")
			else
				client:Notify("Зона не найдена.")
			end
		end
	})

	ix.command.Add("QZList", {
		description = "Список зон карантина.",
		adminOnly = true,
		OnRun = function(self, client)
			if (#ix.qz.zones == 0) then client:Notify("Зон нет.") return end
			for _, z in ipairs(ix.qz.zones) do
				client:ChatPrint(("[КЗ] %s | ур. %d"):format(z.name, z.level))
			end
		end
	})

	ix.command.Add("QZSpawnAdd", {
		description = "Точка фауны Зена: /QZSpawnAdd <уровень 1-2> [ground|ceiling]",
		adminOnly = true,
		arguments = {
			bit.bor(ix.type.number, ix.type.optional),
			bit.bor(ix.type.string, ix.type.optional)
		},
		OnRun = function(self, client, level, kind)
			table.insert(PLUGIN.SpawnPoints, {
				pos = client:GetPos(),
				level = math.Clamp(level or 1, 1, 2),
				kind = (kind == "ceiling") and "ceiling" or "ground"
			})
			PLUGIN:SaveSpawnPoints()
			client:Notify("Точка спавна Зена добавлена (" .. #PLUGIN.SpawnPoints .. ").")
		end
	})

	ix.command.Add("QZSpawnClear", {
		description = "Удалить ближайшую точку спавна Зена (в радиусе 64).",
		adminOnly = true,
		OnRun = function(self, client)
			for i, p in ipairs(PLUGIN.SpawnPoints) do
				if (p.pos:DistToSqr(client:GetPos()) < 64 * 64) then
					table.remove(PLUGIN.SpawnPoints, i)
					PLUGIN:SaveSpawnPoints()
					client:Notify("Точка удалена.")
					return
				end
			end
			client:Notify("Рядом точек нет.")
		end
	})
end
