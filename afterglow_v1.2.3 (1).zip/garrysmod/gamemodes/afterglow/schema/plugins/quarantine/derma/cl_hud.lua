-- derma/cl_hud.lua — оверлей Карантинной Зоны + шкала фильтра
local PLUGIN = PLUGIN

local sporeMat = Material("particle/particle_smokegrenade") -- мягкое облако; замените на кастом

function PLUGIN:HUDPaint()
	local client = LocalPlayer()
	if (!client:GetCharacter()) then return end

	local zone = client:GetNetVar("qzZone")
	if (!zone) then return end

	local w, h = ScrW(), ScrH()
	local pulse = (math.sin(CurTime() * 3) + 1) * 0.5

	-- Зелёная «плёнка» спор по краям экрана
	surface.SetDrawColor(40, 90, 40, 26 + 18 * pulse)
	surface.DrawRect(0, 0, w, h)

	-- Строка зоны
	ix.util.DrawText("☣ КАРАНТИННАЯ ЗОНА: " .. zone.name .. "  [УРОВЕНЬ " .. zone.level .. "]",
		w * 0.5, h * 0.08, ColorAlpha(Color(190, 230, 120), 200 + 55 * pulse), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, "ixMediumLightFont")

	-- Шкала фильтра
	local mask = client.GetGasMask and client:GetGasMask()
	local bw, bh = w * 0.22, 14
	local x, y = w * 0.5 - bw * 0.5, h * 0.88

	draw.RoundedBox(4, x - 2, y - 2, bw + 4, bh + 4, Color(0, 0, 0, 140))

	if (mask) then
		local frac = math.Clamp(mask:GetData("filter", 0) / 100, 0, 1)
		local col = frac > 0.4 and Color(120, 200, 90)
			or (frac > 0.15 and Color(220, 180, 60) or Color(220, 60 + 60 * pulse, 40))

		draw.RoundedBox(3, x, y, bw * frac, bh, col)

		if (frac <= 0) then
			ix.util.DrawText("ФИЛЬТР ИСЧЕРПАН — ВЫ ДЫШИТЕ СПОРАМИ", w * 0.5, y - 18,
				Color(255, 70 + 60 * pulse, 50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, "ixMediumLightFont")
		else
			ix.util.DrawText("ФИЛЬТР " .. math.floor(frac * 100) .. "%", w * 0.5, y + bh * 0.5,
				color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, "ixSmallFont")
		end
	else
		ix.util.DrawText("НЕТ ПРОТИВОГАЗА — КРИТИЧЕСКАЯ ОПАСНОСТЬ", w * 0.5, y,
			Color(255, 60 + 60 * pulse, 50), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, "ixMediumLightFont")
	end
end
