-- meta/sh_player.lua — расширение PLAYER для модуля КЗ
local PLAYER = FindMetaTable("Player")

-- Надетый противогаз (item-инстанс) или nil
function PLAYER:GetGasMask()
	local character = self:GetCharacter()
	if (!character) then return end

	local inventory = character:GetInventory()
	if (!inventory) then return end

	for _, item in pairs(inventory:GetItems()) do
		if (item.uniqueID == "gasmask" and item:GetData("equipped", false)) then
			return item
		end
	end
end

-- Доля заряда фильтра 0..1 (nil — нет противогаза)
function PLAYER:GetFilterFraction()
	local mask = self:GetGasMask()
	if (!mask) then return end
	return (mask:GetData("filter", 0) or 0) / 100
end

-- Находится ли в зоне карантина (shared-расчёт; на сервере — истина)
function PLAYER:IsInQuarantineZone()
	if (SERVER) then
		return ix.qz.GetZoneAt(self:GetPos()) != nil
	else
		return self:GetNetVar("qzZone") != nil
	end
end
