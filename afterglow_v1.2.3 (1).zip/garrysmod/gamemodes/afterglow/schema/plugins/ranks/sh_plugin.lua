-- ============================================================
-- Ранги ГО/ОВА: /Promote — повышение, автопересборка позывного.
-- Форматы:  CP-C17.<ДИВИЗИОН>-<РАНГ>.<цифры>
--           OW-K.<РАНГ>.<цифры>
-- ============================================================
PLUGIN.name = "Ranks"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Иерархия званий ГО (RCT..CmD) и ОВА, команда повышения."

ix.ranks = ix.ranks or {}

-- Таблица строится по требованию: константы фракций определены
-- не на всех этапах загрузки плагинов.
function ix.ranks.GetList(faction)
	if (faction == FACTION_CP) then
		return {"RCT", "i5", "i4", "i3", "i2", "i1", "OfC", "CmD"}
	elseif (faction == FACTION_OVERWATCH) then
		return {"GRN", "CHRG", "SPRS", "CPT"}
	end
end

function ix.ranks.RebuildName(character)
	local faction = character:GetFaction()
	local digits = character:GetData("digits", "00000")
	local rank = character:GetData("rank", "RCT")

	if (faction == FACTION_CP) then
		local class = ix.class.list[character:GetClass()]
		local div = (class and class.divisionCode) or "UNION"
		character:SetName(("CP-C17.%s-%s.%s"):format(div, rank, digits))
	elseif (faction == FACTION_OVERWATCH) then
		character:SetName(("OW-K.%s.%s"):format(rank, digits))
	end
end

ix.command.Add("Promote", {
	description = "Повысить/понизить юнита в звании: /Promote <имя> <ранг>",
	superAdminOnly = true,
	arguments = {
		ix.type.character,
		ix.type.string
	},
	OnRun = function(self, client, target, rank)
		if (!client:IsSuperAdmin()) then
			client:Notify("Только superadmin.")
			return
		end
		local faction = target:GetFaction()
		local ranks = ix.ranks.GetList(faction)
		if (!ranks) then
			client:Notify("Ранги поддерживаются только для ГО и ОВА.")
			return
		end

		local found
		for _, r in ipairs(ranks) do
			if (string.lower(r) == string.lower(rank)) then found = r break end
		end
		if (!found) then
			client:Notify("Допустимые ранги: " .. table.concat(ranks, ", "))
			return
		end

		target:SetData("rank", found)
		ix.ranks.RebuildName(target)

		local notice = target:GetName() .. " — новое звание: " .. found
		client:Notify(notice)
		target:GetPlayer():Notify("ПРИКАЗ ЯДРА: присвоено звание " .. found .. ". Позывной обновлён: " .. target:GetName())
	end
})

-- Перестроить позывной после смены дивизиона (/charsetclass от персонала)
function PLUGIN:CharacterClassChanged(client, character)
	if (character:GetFaction() == FACTION_CP or character:GetFaction() == FACTION_OVERWATCH) then
		timer.Simple(1, function()
			if (character) then ix.ranks.RebuildName(character) end
		end)
	end
end
