-- ============================================================
-- МОДУЛЬ 4: Взлом терминалов Альянса + ЭМП-заряды
-- Терминал — SENT ix_terminal (addons/hlarp). Мини-игра — sh_pipes.lua.
-- ============================================================
PLUGIN.name = "Hacking"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Взлом терминалов и силовых полей Альянса через головоломку энергосети."

local PLUGIN = PLUGIN  -- захват глобала: в колбэках hook.Add/net.Receive глобал PLUGIN после загрузки указывает на другой плагин/nil

ix.hacking = ix.hacking or {}

if (CLIENT) then
	ix.util.Include("derma/cl_hack.lua")
end

ix.util.Include("sh_pipes.lua")

ix.config.Add("hackFieldDownTime", 20, "Сек отключения силового поля после успешного взлома.")
ix.config.Add("hackCooldown", 300, "Кулдаун терминала после взлома/срабатывания (сек).")
ix.config.Add("hackTime", 75, "Лимит времени головоломки (сек).")
ix.config.Add("empFieldDownTime", 25, "Сек отключения поля ЭМП-зарядом.")
ix.config.Add("empCooldown", 300, "Кулдаун ЭМП на одно поле (сек).")

if (SERVER) then
	util.AddNetworkString("ixHackOpen")    -- сервер → клиент (раскладка)
	util.AddNetworkString("ixHackResult")  -- клиент → сервер (решение/провал)
	util.AddNetworkString("ixHackToast")   -- сервер → клиент (уведомления)

	PLUGIN.Terminals = PLUGIN.Terminals or {}
	PLUGIN.Sessions = PLUGIN.Sessions or {}

	-- -------------------- Персистентность терминалов --------------------
	function PLUGIN:SaveTerminals()
		local out = {}
		for _, t in ipairs(self.Terminals) do
			out[#out + 1] = {
				pos = {t.pos.x, t.pos.y, t.pos.z},
				ang = {t.ang.p, t.ang.y, t.ang.r},
				tier = t.tier,
				link = t.link
			}
		end
		ix.data.Set("hackTerminals", out, false, false)
	end

	function PLUGIN:LoadTerminals()
		self.Terminals = {}
		for _, t in ipairs(ix.data.Get("hackTerminals", {}, false, false)) do
			table.insert(self.Terminals, {
				pos = Vector(t.pos[1], t.pos[2], t.pos[3]),
				ang = Angle(t.ang[1], t.ang[2], t.ang[3]),
				tier = t.tier or 1,
				link = t.link
			})
		end

		for _, t in ipairs(self.Terminals) do
			local ent = ents.Create("ix_terminal")
			if (IsValid(ent)) then
				ent:SetPos(t.pos)
				ent:SetAngles(t.ang)
				ent:SetNWInt("tier", t.tier)
				ent:Spawn()
				ent:GetPhysicsObject():EnableMotion(false)
				t.entity = ent
				ent.terminalData = t
			end
		end
	end

	function PLUGIN:InitPostEntity()
		self:LoadTerminals()
	end

	-- -------------------- Сессии взлома --------------------
	function PLUGIN:BeginHack(client, terminal)
		if (!client:GetCharacter()) then return end
		local now = CurTime()

		if ((terminal.hackCooldownUntil or 0) > now) then
			client:Notify("Терминал перезагружается после инцидента. Осталось " .. math.ceil(terminal.hackCooldownUntil - now) .. " сек.")
			return
		end

		-- CP GRID может «обслуживать» терминал без игры — быстрый сброс
		-- Для остальных — генерация головоломки
		local tier = terminal:GetNWInt("tier", 1)
		local time = ix.config.Get("hackTime", 75) - tier * 10
		local data = ix.hacking.pipes.Generate(math.random(1, 2000000000), tier)

		self.Sessions[client] = {
			terminal = terminal,
			data = data.base,
			initial = data.initial,
			w = data.w, h = data.h,
			src = data.src, dst = data.dst,
			moveLimit = data.moveLimit,
			deadline = now + math.max(30, time)
		}

		net.Start("ixHackOpen")
			net.WriteEntity(terminal)
			net.WriteUInt(data.w, 4)
			net.WriteUInt(data.h, 4)
			net.WriteUInt(data.src, 8)
			net.WriteUInt(data.dst, 8)
			net.WriteUInt(data.moveLimit, 8)
			net.WriteFloat(self.Sessions[client].deadline)
			for i = 1, data.w * data.h do
				net.WriteUInt(data.initial[i], 4)
			end
		net.Send(client)

		terminal:EmitSound("buttons/button17.wav", 55)
	end

	-- Глобальный вход для SENT-терминала (локальная ссылка на PLUGIN,
	-- т.к. глобальная PLUGIN переиспользуется загрузчиком других файлов)
	local PLUGIN_TABLE = PLUGIN
	function ix.hacking.BeginHack(client, terminal)
		PLUGIN_TABLE:BeginHack(client, terminal)
	end

	net.Receive("ixHackResult", function(_, client)
		local success = net.ReadBool()
		local session = PLUGIN.Sessions[client]
		if (!session) then return end

		if (!IsValid(session.terminal) or client:GetPos():DistToSqr(session.terminal:GetPos()) > 200 * 200) then
			PLUGIN.Sessions[client] = nil
			return
		end

		if (CurTime() > session.deadline) then
			success = false -- время вышло
		end

		if (success) then
			-- сбор финальных масок + проверка лимита ходов
			local moves = net.ReadUInt(16)
			if (moves > session.moveLimit) then success = false end

			local finalMasks = {}
			for i = 1, session.w * session.h do
				finalMasks[i] = net.ReadUInt(4)
			end

			if (success and !ix.hacking.pipes.IsSolved(finalMasks, session.w, session.h, session.src, session.dst)) then
				success = false
			end
		end

		PLUGIN.Sessions[client] = nil

		if (success) then
			PLUGIN:OnHackSuccess(client, session.terminal)
		else
			PLUGIN:OnHackFailed(client, session.terminal)
		end
	end)

	-- -------------------- Результаты --------------------
	function PLUGIN:OnHackSuccess(client, terminal)
		terminal.hackCooldownUntil = CurTime() + ix.config.Get("hackCooldown", 300)
		terminal:SetNWString("ixState", "hacked")
		terminal:EmitSound("buttons/button9.wav", 60)

		timer.Simple(ix.config.Get("hackFieldDownTime", 20), function()
			if (IsValid(terminal)) then terminal:SetNWString("ixState", "secure") end
		end)

		-- гасим связанное силовое поле
		local link = terminal.terminalData and terminal.terminalData.link
		if (link) then
			local brush = ents.GetMapCreatedEntity(link)
			if (IsValid(brush)) then
				brush:Fire("Disable")
				timer.Simple(ix.config.Get("hackFieldDownTime", 20), function()
					if (IsValid(brush)) then brush:Fire("Enable") end
				end)
			end
		end

		client:Notify("ВЗЛОМ УСПЕШЕН: контур перенаправлен. Поле отключено на "
			.. ix.config.Get("hackFieldDownTime", 20) .. " сек.")
		ix.chat.Send(client, "me", "усмехается, не отрывая глаз от пульсирующих узлов терминала.")
	end

	function PLUGIN:OnHackFailed(client, terminal)
		terminal.hackCooldownUntil = CurTime() + ix.config.Get("hackCooldown", 300) * 0.5
		terminal:SetNWString("ixState", "alarm")
		terminal:EmitSound("ambient/alarms/warningbell1.wav", 70)

		timer.Simple(15, function()
			if (IsValid(terminal)) then terminal:SetNWString("ixState", "secure") end
		end)

		client:Notify("СИГНАЛИЗАЦИЯ! Узел сброшен. Ваш след засёкся в сети.")

		-- оповещение ГО/ОВА
		for _, ply in player.Iterator() do
			if (ply:GetCharacter()) then
				local faction = ply:GetCharacter():GetFaction()
				if (faction == FACTION_CP or faction == FACTION_OVERWATCH) then
					ply:Notify("ПЕРЕХВАТ: попытка взлома терминала! Сектор: " .. tostring(terminal:GetPos()))
				end
			end
		end
	end

	-- GRID: ускоренный сброс кулдауна (обслуживание)
	ix.command.Add("TerminalReset", {
		description = "GRID: обслужить терминал — сбросить кулдаун и состояние тревоги.",
		OnRun = function(self, client)
			local ch = client:GetCharacter()
			if (!ch or ch:GetClass() != CLASS_CP_GRID) then
				client:Notify("Только дивизион GRID обслуживает терминалы.")
				return
			end
			local tr = client:GetEyeTraceNoCursor()
			local ent = tr.Entity
			if (!IsValid(ent) or ent:GetClass() != "ix_terminal" or tr.HitPos:DistToSqr(client:GetPos()) > 200 * 200) then
				client:Notify("Цельтесь в терминал в радиусе 200 юнитов.")
				return
			end
			ent.hackCooldownUntil = 0
			ent:SetNWString("ixState", "secure")
			ent:EmitSound("buttons/button5.wav", 55)
			client:Notify("Терминал обслужен. Контур восстановлен.")
		end
	})

	-- -------------------- ЭМП-заряд (item sh_emp_charge) --------------------
	function ix.hacking.PlantEMP(client)
		local tr = util.TraceLine({
			start = client:GetShootPos(),
			endpos = client:GetShootPos() + client:GetAimVector() * 96,
			filter = client
		})

		local brush = tr.Entity
		if (!IsValid(brush) or brush:GetClass() != "func_brush") then
			client:Notify("Нужно целиться в силовое поле (func_brush) на дистанции до 96 юнитов.")
			return false
		end

		local id = brush:MapCreationID()
		if ((brush.ixEMPUntil or 0) > CurTime()) then
			client:Notify("Поле уже под воздействием ЭМП.")
			return false
		end

		brush.ixEMPUntil = CurTime() + ix.config.Get("empCooldown", 300)
		brush:Fire("Disable")

		-- визуал + звуки отсчёта
		for i = 1, 3 do
			timer.Simple(i * 1.5, function()
				if (IsValid(brush)) then
					sound.Play("buttons/button17.wav", tr.HitPos, 65, 180)
					util.Effect("StunstickImpact", EffectData():SetOrigin(tr.HitPos))
				end
			end)
		end

		timer.Simple(ix.config.Get("empFieldDownTime", 25), function()
			if (IsValid(brush)) then brush:Fire("Enable") end
		end)

		-- тревога для Альянса (с задержкой — как и положено диверсии)
		timer.Simple(6, function()
			for _, ply in player.Iterator() do
				if (ply:GetCharacter()) then
					local faction = ply:GetCharacter():GetFaction()
					if (faction == FACTION_CP or faction == FACTION_OVERWATCH) then
						ply:Notify("СБОЙ СИЛОВОГО ПОЛЯ! Сектор: " .. tostring(tr.HitPos))
					end
				end
			end
		end)

		ix.chat.Send(client, "me", "прижимает к полю тяжёлый диск заряда — тот прилипает с мокрым щелчком.")
		return true
	end
end

-- -------------------- Админ-команды мира --------------------
ix.command.Add("TerminalAdd", {
	description = "Разместить терминал Альянса: /TerminalAdd <tier 1-3>",
	adminOnly = true,
	arguments = {bit.bor(ix.type.number, ix.type.optional)},
	OnRun = function(self, client, tier)
		tier = math.Clamp(tier or 1, 1, 3)
		local pos = client:GetEyeTraceNoCursor().HitPos
		local ent = ents.Create("ix_terminal")
		ent:SetPos(pos)
		ent:SetAngles(Angle(0, client:GetAngles().y + 180, 0))
		ent:SetNWInt("tier", tier)
		ent:Spawn()
		ent:GetPhysicsObject():EnableMotion(false)

		local data = {pos = pos, ang = ent:GetAngles(), tier = tier, link = nil, entity = ent}
		ent.terminalData = data
		table.insert(PLUGIN.Terminals, data)
		PLUGIN:SaveTerminals()
		client:Notify("Терминал tier " .. tier .. " размещён. Свяжите полем: /TerminalLink")
	end
})

ix.command.Add("TerminalLink", {
	description = "Связать ближайший терминал с силовым полем: цельтесь в func_brush.",
	adminOnly = true,
	OnRun = function(self, client)
		local tr = client:GetEyeTraceNoCursor()
		if (!IsValid(tr.Entity) or tr.Entity:GetClass() != "func_brush") then
			client:Notify("Цельтесь в брашь силового поля.")
			return
		end
		local link = tr.Entity:MapCreationID()

		local nearest, dist
		for _, t in ipairs(PLUGIN.Terminals) do
			local d = t.pos:DistToSqr(client:GetPos())
			if (!dist or d < dist) then nearest, dist = t, d end
		end
		if (!nearest or dist > 600 * 600) then
			client:Notify("Рядом (600 юнитов) нет терминалов.")
			return
		end
		nearest.link = link
		PLUGIN:SaveTerminals()
		client:Notify("Терминал #" .. tostring(nearest) .. " связан с полем (ID " .. link .. ").")
	end
})

ix.command.Add("TerminalRemove", {
	description = "Удалить терминал, на который вы смотрите.",
	adminOnly = true,
	OnRun = function(self, client)
		local tr = client:GetEyeTraceNoCursor()
		if (!IsValid(tr.Entity) or tr.Entity:GetClass() != "ix_terminal") then
			client:Notify("Цельтесь в терминал.")
			return
		end
		for i, t in ipairs(PLUGIN.Terminals) do
			if (t.entity == tr.Entity) then
				table.remove(PLUGIN.Terminals, i)
				break
			end
		end
		tr.Entity:Remove()
		PLUGIN:SaveTerminals()
		client:Notify("Терминал удалён.")
	end
})
