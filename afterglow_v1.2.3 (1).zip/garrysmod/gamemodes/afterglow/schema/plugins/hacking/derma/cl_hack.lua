-- Клиентская панель мини-игры «энергосеть»
local PLUGIN = PLUGIN
local P

net.Receive("ixHackOpen", function()
	P = ix.hacking.pipes

	local terminal = net.ReadEntity()
	local w = net.ReadUInt(4)
	local h = net.ReadUInt(4)
	local src = net.ReadUInt(8)
	local dst = net.ReadUInt(8)
	local moveLimit = net.ReadUInt(8)
	local deadline = net.ReadFloat()

	local masks = {}
	for i = 1, w * h do masks[i] = net.ReadUInt(4) end

	vgui.Create("ixHackPanel"):Setup(terminal, w, h, src, dst, moveLimit, deadline, masks)
end)

local PANEL = {}

function PANEL:Init()
	self:SetSize(520, 480)
	self:Center()
	self:MakePopup()
	self:SetTitle("")
	self:ShowCloseButton(false)
	gui.EnableScreenClicker(true)
end

function PANEL:Setup(terminal, w, h, src, dst, moveLimit, deadline, masks)
	P = ix.hacking.pipes
	self.terminal = terminal
	self.gridW, self.gridH = w, h
	self.src, self.dst = src, dst
	self.movesLeft = moveLimit
	self.deadline = deadline
	self.masks = masks
	self.rotations = {}
	for i = 1, w * h do self.rotations[i] = 0 end

	local top = self:Add("DPanel")
	top:Dock(TOP)
	top:SetTall(40)
	top.Paint = function(_, pw, ph)
		local left = math.max(0, math.ceil(self.deadline - CurTime()))
		draw.SimpleText("ЭНЕРГОСЕТЬ C17 :: узел " .. (IsValid(terminal) and terminal:GetNWInt("tier", 1) or "?"),
			"ixMediumLightFont", pw / 2, 8, Color(120, 220, 255), TEXT_ALIGN_CENTER)
		draw.SimpleText("ходов: " .. self.movesLeft .. "   время: " .. left .. "с",
			"ixSmallFont", pw / 2, 28, left < 15 and Color(255, 90, 90) or color_white, TEXT_ALIGN_CENTER)
	end

	self.grid = self:Add("DPanel")
	self.grid:Dock(FILL)
	self.grid:DockMargin(10, 6, 10, 10)

	local cellSize = math.min(
		math.floor((self:GetWide() - 20) / w),
		math.floor((self:GetTall() - 60) / h)
	)
	self.cellSize = cellSize
	self:BuildCells()

	local abort = self:Add("DButton")
	abort:Dock(BOTTOM)
	abort:SetTall(26)
	abort:SetText("ОТМЕНА (сигнализация НЕ сработает)")
	abort.DoClick = function()
		self.aborted = true
		self:Remove()
		gui.EnableScreenClicker(false)
	end
end

function PANEL:BuildCells()
	local P = ix.hacking.pipes
	self.buttons = {}

	for y = 1, self.gridH do
		for x = 1, self.gridW do
			local idx = P.Index(x, y, self.gridW)
			local btn = self.grid:Add("DButton")
			btn:SetText("")
			btn:SetSize(self.cellSize, self.cellSize)
			btn:SetPos((x - 1) * self.cellSize, (y - 1) * self.cellSize)
			btn.idx = idx

			btn.Paint = function(b, bw, bh)
				local active = self:ConnectedFromSource(idx)
				local isSrc = idx == self.src
				local isDst = idx == self.dst

				surface.SetDrawColor(14, 14, 20, 240)
				surface.DrawRect(0, 0, bw - 1, bh - 1)

				if (isSrc) then
					surface.SetDrawColor(30, 70, 30, 240)
					surface.DrawRect(0, 0, bw - 1, bh - 1)
				elseif (isDst) then
					surface.SetDrawColor(70, 30, 30, 240)
					surface.DrawRect(0, 0, bw - 1, bh - 1)
				end

				-- линии соединений
				local cx, cy = bw / 2, bh / 2
				local mask = self.masks[idx]
				surface.SetDrawColor(active and Color(120, 255, 140) or Color(90, 90, 110))
				if (bit.band(mask, 1) != 0) then surface.DrawRect(cx - 2, 0, 4, cy) end      -- N
				if (bit.band(mask, 4) != 0) then surface.DrawRect(cx - 2, cy, 4, cy) end     -- S
				if (bit.band(mask, 2) != 0) then surface.DrawRect(cx, cy - 2, bw - cx, 4) end -- E
				if (bit.band(mask, 8) != 0) then surface.DrawRect(0, cy - 2, cx, 4) end      -- W
				surface.DrawRect(cx - 3, cy - 3, 6, 6)
			end

			btn.DoClick = function()
				if (self.movesLeft <= 0) then
					self:Finish(false)
					return
				end
				self.rotations[idx] = (self.rotations[idx] + 1) % 4
				self.masks[idx] = P.Rotate(self.masks[idx], 1)
				self.movesLeft = self.movesLeft - 1
				self.totalClicks = (self.totalClicks or 0) + 1
				surface.PlaySound("buttons/button16.wav")

				if (P.IsSolved(self.masks, self.gridW, self.gridH, self.src, self.dst)) then
					self:Finish(true)
				end
			end

			self.buttons[idx] = btn
		end
	end
end

function PANEL:ConnectedFromSource(start)
	local P = ix.hacking.pipes
	local seen = {[start] = false}
	local queue = {self.src}
	local visited = {[self.src] = true}
	while (#queue > 0) do
		local idx = table.remove(queue, 1)
		visited[idx] = true
		local x = ((idx - 1) % self.gridW) + 1
		local y = math.floor((idx - 1) / self.gridW) + 1
		for _, d in ipairs(P.DIRS) do
			local nx, ny = x + d.dx, y + d.dy
			if (nx >= 1 and nx <= self.gridW and ny >= 1 and ny <= self.gridH) then
				local nIdx = P.Index(nx, ny, self.gridW)
				if (!visited[nIdx]
					and bit.band(self.masks[idx], d.bit) != 0
					and bit.band(self.masks[nIdx], d.opp) != 0) then
					visited[nIdx] = true
					table.insert(queue, nIdx)
				end
			end
		end
	end
	return visited[start] == true
end

function PANEL:Finish(success)
	if (self.finished) then return end
	self.finished = true

	net.Start("ixHackResult")
		net.WriteBool(success)
		if (success) then
			-- сервер сверяет число кликов с лимитом терминала
			net.WriteUInt(self.totalClicks or 0, 16)
			for i = 1, self.gridW * self.gridH do
				net.WriteUInt(self.masks[i], 4)
			end
		end
	net.SendToServer()

	surface.PlaySound(success and "buttons/button9.wav" or "ambient/alarms/klaxon1.wav")
	self:Remove()
	gui.EnableScreenClicker(false)
end

function PANEL:Paint(w, h)
	ix.util.DrawBlur(self, 6)
	surface.SetDrawColor(10, 12, 16, 245)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(60, 160, 200, 80)
	surface.DrawOutlinedRect(0, 0, w, h)
end

function PANEL:Think()
	if (CurTime() > self.deadline) then
		self:Finish(false)
	end
end

vgui.Register("ixHackPanel", PANEL, "DFrame")
