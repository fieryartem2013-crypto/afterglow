-- sh_pipes.lua — генератор/валидатор мини-игры "перенаправление энергии"
-- Чистые функции (shared). Биты соединений: N=1, E=2, S=4, W=8.
ix.hacking = ix.hacking or {}
ix.hacking.pipes = ix.hacking.pipes or {}

local P = ix.hacking.pipes

-- Детерминированный ЛГЧ (чтобы сервер и никто больше не знал решение заранее)
local function NewRng(seed)
	local state = seed % 2147483647
	if (state <= 0) then state = state + 2147483646 end
	return function()
		state = (state * 16807) % 2147483647
		return state
	end
end

P.BITS = {N = 1, E = 2, S = 4, W = 8}
P.DIRS = {
	{dx = 0, dy = -1, bit = 1, opp = 4},
	{dx = 1, dy = 0, bit = 2, opp = 8},
	{dx = 0, dy = 1, bit = 4, opp = 1},
	{dx = -1, dy = 0, bit = 8, opp = 2}
}

function P.Index(x, y, w) return (y - 1) * w + x end

-- Поворот битовой маски по часовой стрелке rot раз
function P.Rotate(mask, rot)
	for _ = 1, rot do
		local carry = (bit.band(mask, 8) != 0) and 1 or 0
		mask = bit.band(mask * 2, 15) + carry
	end
	return mask
end

-- Генерация: базовые шаблоны + стартовые (заранее перевёрнутые) маски
-- Вернёт: {w, h, src=idx, dst=idx, base[], initial[], moveLimit}
function P.Generate(seed, tier)
	tier = math.Clamp(tier or 1, 1, 3)
	local sizes = {{w = 5, h = 4}, {w = 6, h = 5}, {w = 7, h = 6}}
	local w, h = sizes[tier].w, sizes[tier].h
	local rng = NewRng(seed)

	local srcY = rng() % h + 1
	local dstY = rng() % h + 1
	local src = P.Index(1, srcY, w)
	local dst = P.Index(w, dstY, w)

	local base = {}
	for i = 1, w * h do base[i] = 0 end

	-- случайный путь слева направо
	local function CarvePath()
		local visited = {}
		local x, y = 1, srcY
		local guard = 0
		while !(x == w and y == dstY) do
			guard = guard + 1
			if (guard > 2000) then return false end
			visited[P.Index(x, y, w)] = true

			-- выбор направления: смещение вправо
			local options = {}
			for _, d in ipairs(P.DIRS) do
				local nx, ny = x + d.dx, y + d.dy
				if (nx >= 1 and nx <= w and ny >= 1 and ny <= h and !visited[P.Index(nx, ny, w)]) then
					local bias = (d.dx == 1) and 3 or 1 -- тянемся к выходу
					table.insert(options, {d = d, wgt = bias})
				end
			end
			if (#options == 0) then return false end

			local total = 0
			for _, o in ipairs(options) do total = total + o.wgt end
			local roll = rng() % total
			local chosen = options[1]
			for _, o in ipairs(options) do
				roll = roll - o.wgt
				if (roll < 0) then chosen = o break end
			end

			local d = chosen.d
			local i1 = P.Index(x, y, w)
			local i2 = P.Index(x + d.dx, y + d.dy, w)
			base[i1] = bit.bor(base[i1], d.bit)
			base[i2] = bit.bor(base[i2], d.opp)
			x, y = x + d.dx, y + d.dy
		end
		return true
	end

	while (!CarvePath()) do
		for i = 1, w * h do base[i] = 0 end
	end

	-- случайные лишние соединения (туман войны)
	for y = 1, h do
		for x = 1, w do
			for _, d in ipairs(P.DIRS) do
				local nx, ny = x + d.dx, y + d.dy
				if (nx >= 1 and nx <= w and ny >= 1 and ny <= h) then
					if (rng() % 100 < 30) then
						local i1 = P.Index(x, y, w)
						local i2 = P.Index(nx, ny, w)
						base[i1] = bit.bor(base[i1], d.bit)
						base[i2] = bit.bor(base[i2], d.opp)
					end
				end
			end
		end
	end

	-- начальное случайное вращение
	local initial = {}
	for i = 1, w * h do
		initial[i] = P.Rotate(base[i], rng() % 4)
	end

	local limitMul = ({2.0, 1.7, 1.4})[tier]
	return {
		w = w, h = h, src = src, dst = dst,
		base = base, initial = initial,
		moveLimit = math.floor(w * h * limitMul)
	}
end

-- BFS: достижима ли цель от источника по маскам связей
function P.IsSolved(masks, w, h, src, dst)
	local function Connected(i1, i2, dir)
		return bit.band(masks[i1], dir.bit) != 0 and bit.band(masks[i2], dir.opp) != 0
	end

	local seen = {[src] = true}
	local queue = {src}
	while #queue > 0 do
		local idx = table.remove(queue, 1)
		if (idx == dst) then return true end
		local x = ((idx - 1) % w) + 1
		local y = math.floor((idx - 1) / w) + 1
		for _, d in ipairs(P.DIRS) do
			local nx, ny = x + d.dx, y + d.dy
			if (nx >= 1 and nx <= w and ny >= 1 and ny <= h) then
				local nIdx = P.Index(nx, ny, w)
				if (!seen[nIdx] and Connected(idx, nIdx, d)) then
					seen[nIdx] = true
					table.insert(queue, nIdx)
				end
			end
		end
	end
	return false
end
