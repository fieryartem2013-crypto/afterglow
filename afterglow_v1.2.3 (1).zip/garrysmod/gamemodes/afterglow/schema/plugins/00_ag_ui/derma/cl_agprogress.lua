-- AGProgressBar — стилизованная шкала с лейблом (HP/Armor/QZ/Filter/Stamina)
local PANEL = {}

function PANEL:Init()
	self:SetTall(20)
	self.frac = 1
	self.displayFrac = 1
	self.label = ""
	self.color = ix.ag.C.neon
	self.pulseLow = true
end

function PANEL:SetLabel(text) self.label = text end
function PANEL:SetColor(col) self.color = col end
function PANEL:SetFraction(f) self.frac = math.Clamp(f or 0, 0, 1) end

function PANEL:Paint(w, h)
	self.displayFrac = ix.ag.Dampen(6, self.displayFrac, self.frac)
	ix.ag.DrawNeonBar(0, 0, w, h, self.displayFrac, self.color, self.label,
		math.floor(self.frac * 100 + 0.5) .. "%")
end

function PANEL:Think()
	if (self.live) then
		self:SetFraction(self.live())
	end
end

vgui.Register("AGProgressBar", PANEL, "EditablePanel")
