-- AGTooltip — всплывающая инфо-карточка: заголовок + строки (label: value)
local PANEL = {}

function PANEL:Init()
	self:SetDrawOnTop(true)
	self:SetMouseInputEnabled(false)
	self.rows = {}
	self.created = RealTime()
end

function PANEL:SetTitle(text, color)
	self.titleText = text
	self.titleColor = color or ix.ag.C.neon
end

function PANEL:AddRow(label, value, valueColor)
	self.rows[#self.rows + 1] = {label = label, value = tostring(value), color = valueColor}
end

function PANEL:AddText(text, color)
	self.rows[#self.rows + 1] = {text = text, color = color or ix.ag.C.textDim}
end

function PANEL:SizeToContent()
	surface.SetFont("AG.SmallB")
	local w = surface.GetTextSize(self.titleText or "") + 24
	local h = 30
	for _, row in ipairs(self.rows) do
		if (row.text) then
			local lines = ix.ag.WrapText(row.text, "AG.Small", 240)
			row._lines = lines
			h = h + #lines * 15 + 2
			w = math.max(w, 250)
		else
			h = h + 17
			surface.SetFont("AG.Small")
			w = math.max(w, surface.GetTextSize((row.label or "") .. "  " .. (row.value or "")) + 24)
		end
	end
	self:SetSize(w + 8, h + 10)
end

function PANEL:Paint(w, h)
	local appear = ix.option.Get("agAnimations", true)
		and math.Clamp((RealTime() - self.created) * 4, 0, 1) or 1

	ix.ag.DrawBlur(self, 2)
	surface.SetDrawColor(ix.ag.C.bgPanel.r, ix.ag.C.bgPanel.g, ix.ag.C.bgPanel.b, 245 * appear)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(ix.ag.C.stroke)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
	ix.ag.DrawTechCorners(0, 0, w, h, 7, 2, ColorAlpha(ix.ag.C.neon, 160 * appear))
	ix.ag.DrawNeonEdge(4, 0, w - 8, ix.ag.C.neon, 120 * appear)

	draw.SimpleText(self.titleText or "", "AG.SmallB", 10, 6, ColorAlpha(self.titleColor or ix.ag.C.text, 255 * appear))

	local y = 26
	for _, row in ipairs(self.rows) do
		if (row.text) then
			for _, line in ipairs(row._lines or {row.text}) do
				draw.SimpleText(line, "AG.Small", 10, y, ColorAlpha(row.color or ix.ag.C.textDim, 255 * appear))
				y = y + 15
			end
			y = y + 2
		else
			draw.SimpleText(row.label, "AG.Small", 10, y, ColorAlpha(ix.ag.C.textDim, 255 * appear))
			draw.SimpleText(row.value, "AG.SmallB", w - 10, y, ColorAlpha(row.color or ix.ag.C.text, 255 * appear), TEXT_ALIGN_RIGHT)
			y = y + 17
		end
	end
end

vgui.Register("AGTooltip", PANEL, "EditablePanel")

-- Глобальный помощник: показать карточку у курсора
function ix.ag.ShowTooltip(title, titleColor)
	if (IsValid(ix.ag.tooltipPanel)) then ix.ag.tooltipPanel:Remove() end
	local tip = vgui.Create("AGTooltip")
	tip:SetTitle(title, titleColor)
	ix.ag.tooltipPanel = tip
	return tip
end

function ix.ag.PlaceTooltip(tip)
	tip:SizeToContent()
	local x, y = input.GetCursorPos()
	x, y = x + 18, y + 14
	if (x + tip:GetWide() > ScrW()) then x = x - tip:GetWide() - 36 end
	if (y + tip:GetTall() > ScrH()) then y = ScrH() - tip:GetTall() - 10 end
	tip:SetPos(x, y)
end

function ix.ag.HideTooltip()
	if (IsValid(ix.ag.tooltipPanel)) then ix.ag.tooltipPanel:Remove() end
end
