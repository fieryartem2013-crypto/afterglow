-- AGPanel — базовая панель: блюр, тень, tech-corners, неоновая кромка
local PANEL = {}

AccessorFunc(PANEL, "bBlur", "Blur", FORCE_BOOL)
AccessorFunc(PANEL, "bNeonEdge", "NeonEdge", FORCE_BOOL)
AccessorFunc(PANEL, "bCorners", "Corners", FORCE_BOOL)
AccessorFunc(PANEL, "edgeColor", "EdgeColor")
AccessorFunc(PANEL, "bgColor", "BackgroundColor")

function PANEL:Init()
	self:SetBlur(true)
	self:SetNeonEdge(true)
	self:SetCorners(true)
	self:SetEdgeColor(ix.ag.C.neon)
	self:SetBackgroundColor(ix.ag.C.bgPanel)
end

function PANEL:Paint(w, h)
	local bg = self:GetBackgroundColor()
	ix.ag.DrawShadow(0, 0, w, h)
	if (self:GetBlur()) then ix.ag.DrawBlur(self, 2) end
	draw.RoundedBox(0, 0, 0, w, h, bg)

	if (self:GetNeonEdge()) then
		ix.ag.DrawNeonEdge(6, 0, w - 12, self:GetEdgeColor(), 130)
	end
	surface.SetDrawColor(ix.ag.C.stroke)
	surface.DrawOutlinedRect(0, 0, w, h, 1)

	if (self:GetCorners()) then
		ix.ag.DrawTechCorners(0, 0, w, h, 9, 2, ColorAlpha(self:GetEdgeColor(), 190))
	end
	ix.ag.DrawScanlines(0, 0, w, h, 4)

	if (self.DoCustom) then self:DoCustom(w, h) end
	if (self.PaintOver) then self:PaintOver(w, h) end
end

vgui.Register("AGPanel", PANEL, "EditablePanel")

-- AGFrame — плавающее окно с заголовком и кнопкой закрытия
local FRAME = {}
AccessorFunc(FRAME, "title", "Title", FORCE_STRING)

function FRAME:Init()
	-- обязательно: вызов базового Init AGPanel (базовые иниты не вызываются автоматически)
	self.BaseClass.Init(self)

	self.title = "AFTERGLOW"

	self.closeBtn = self:Add("AGButton")
	self.closeBtn:SetText("×")
	self.closeBtn:SetFont("AG.BigB")
	self.closeBtn:SetVariant("ghost")
	self.closeBtn:SetSize(30, 30)
	self.closeBtn.DoClick = function()
		ix.ag.Click()
		self:Remove()
	end

	self:SetMouseInputEnabled(true)
end

function FRAME:PerformLayout(w, h)
	self.closeBtn:SetPos(w - 36, 6)
end

function FRAME:Paint(w, h)
	local bg = self:GetBackgroundColor()
	ix.ag.DrawShadow(0, 0, w, h)
	if (self:GetBlur()) then ix.ag.DrawBlur(self, 2) end
	draw.RoundedBox(0, 0, 0, w, h, bg)

	ix.ag.DrawNeonEdge(6, 36, w - 12, self:GetEdgeColor(), 150)
	surface.SetDrawColor(ix.ag.C.stroke)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
	ix.ag.DrawTechCorners(0, 0, w, h, 10, 2, ColorAlpha(self:GetEdgeColor(), 190))

	draw.SimpleText("AFTERGLOW //", "AG.Small", 12, 10, ix.ag.C.textDim)
	draw.SimpleText(self.title or "", "AG.MediumB", 12, 22, ix.ag.C.text)
	ix.ag.DrawScanlines(0, 0, w, h, 4)
end

-- перетаскивание
function FRAME:OnMousePressed()
	self.dragging = true
	self.dragX, self.dragY = gui.MouseX() - self.x, gui.MouseY() - self.y
	self:MouseCapture(true)
end

function FRAME:OnMouseReleased()
	self.dragging = false
	self:MouseCapture(false)
end

function FRAME:Think()
	if (self.dragging) then
		self:SetPos(gui.MouseX() - self.dragX, gui.MouseY() - self.dragY)
	end
end

vgui.Register("AGFrame", FRAME, "AGPanel")
