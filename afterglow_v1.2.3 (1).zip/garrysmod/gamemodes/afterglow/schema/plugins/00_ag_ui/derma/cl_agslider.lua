-- AGNumSlider — слайдер числа с ползунком
local PANEL = {}

function PANEL:Init()
	self:SetText("")
	self:SetTall(34)
	self.min, self.max, self.value = 0, 100, 50
	self.decimals = 0
	self.label = ""
	self.dragging = false
	self:SetMouseInputEnabled(true)
end

function PANEL:SetRange(mn, mx, val, dec)
	self.min, self.max, self.decimals = mn, mx, dec or 0
	self:SetValue(val or mn)
end

function PANEL:SetLabel(text) self.label = text end
function PANEL:GetValue() return self.value end
function PANEL:SetValue(v)
	self.value = math.Clamp(v, self.min, self.max)
	if (self.OnValueChanged) then self:OnValueChanged(self.value) end
end

function PANEL:ValueToT()
	if (self.max == self.min) then return 0 end
	return (self.value - self.min) / (self.max - self.min)
end

function PANEL:OnMousePressed(code)
	if (code == MOUSE_LEFT) then
		self.dragging = true
		self:MouseCapture(true)
		self:UpdateFromMouse()
	end
end

function PANEL:OnMouseReleased()
	self.dragging = false
	self:MouseCapture(false)
end

function PANEL:OnCursorMoved()
	if (self.dragging) then self:UpdateFromMouse() end
end

function PANEL:UpdateFromMouse()
	local x = gui.MouseX() - self:LocalToScreen(0, 0)
	local t = math.Clamp(x / self:GetWide(), 0, 1)
	local dec = self.decimals > 0 and (10 ^ self.decimals) or 1
	self:SetValue(math.Round(self.min + (self.max - self.min) * t, self.decimals))
end

function PANEL:Paint(w, h)
	local trackY = h - 10
	draw.SimpleText(self.label, "AG.Small", 0, 2, ix.ag.C.text, TEXT_ALIGN_LEFT)
	draw.SimpleText(
		string.format("%." .. self.decimals .. "f", self.value),
		"AG.Mono", w, 2, ix.ag.C.neon, TEXT_ALIGN_RIGHT)

	surface.SetDrawColor(ix.ag.C.stroke)
	surface.DrawRect(0, trackY, w, 4)

	local t = self:ValueToT()
	surface.SetDrawColor(ix.ag.C.neon.r, ix.ag.C.neon.g, ix.ag.C.neon.b, 90)
	surface.DrawRect(0, trackY, w * t, 4)
	surface.SetDrawColor(self.dragging and ix.ag.C.neonSoft or ix.ag.C.neon)
	surface.DrawRect(w * t - 3, trackY - 4, 6, 12)
	return true
end

vgui.Register("AGNumSlider", PANEL, "DButton")
