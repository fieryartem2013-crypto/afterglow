-- AGModelView — интерактивная 3D-модель: орбита мышью, зум колёсом,
-- медленное авто-вращение в покое
local BASE = baseclass.Get("DModelPanel")
local PANEL = {}

function PANEL:Init()
	self.yaw = 0
	self.dist = 1.0
	self.dragging = false
	self.lastX = 0
	self.spinSpeed = 14
	self:SetFOV(34)
	self:SetMouseInputEnabled(true)
	self.bFadeIn = false
	self.fadeT = 0
end

-- показать модель с плавным появлением
function PANEL:ShowModel(mdl)
	BASE.SetModel(self, mdl)
	if (ix.option.Get("agAnimations", true)) then
		self.bFadeIn = true
		self.fadeT = RealTime()
		self:SetAlpha(0)
	end
end

function PANEL:Think()
	BASE.Think(self)
	if (self.bFadeIn) then
		local a = math.Clamp((RealTime() - self.fadeT) * 510, 0, 255)
		self:SetAlpha(a)
		if (a >= 255) then self.bFadeIn = false end
	end
end

function PANEL:LayoutEntity(entity)
	if (!IsValid(entity)) then return end

	if (!self.dragging and ix.option.Get("agAnimations", true)) then
		self.yaw = self.yaw + self.spinSpeed * FrameTime()
	end

	local mins, maxs = entity:GetRenderBounds()
	local center = entity:GetPos() + entity:OBBCenter()
	local size = (maxs - mins):Length()
	local radius = math.max(size * self.dist, 24)
	local yawRad = math.rad(self.yaw)
	local camPos = center + Vector(math.cos(yawRad), math.sin(yawRad), 0.18) * radius * 0.9

	self:SetCamPos(camPos)
	self:SetLookAt(center)
	if (entity.SetEyeTarget) then entity:SetEyeTarget(camPos) end
end

function PANEL:OnMousePressed()
	self.dragging = true
	self.lastX = input.GetCursorPos()
	self:MouseCapture(true)
end

function PANEL:OnMouseReleased()
	self.dragging = false
	self:MouseCapture(false)
end

function PANEL:OnCursorMoved()
	if (self.dragging) then
		local x = input.GetCursorPos()
		self.yaw = self.yaw - (x - self.lastX) * 0.5
		self.lastX = x
	end
end

function PANEL:OnMouseWheeled(delta)
	self.dist = math.Clamp(self.dist - delta * 0.12, 0.65, 2.0)
end

vgui.Register("AGModelView", PANEL, "DModelPanel")
