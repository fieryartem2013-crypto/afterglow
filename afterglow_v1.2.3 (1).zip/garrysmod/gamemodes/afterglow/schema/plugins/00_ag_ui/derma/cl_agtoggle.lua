-- AGToggle — тумблер со слайдером-ларпом
local PANEL = {}

AccessorFunc(PANEL, "bChecked", "Checked", FORCE_BOOL)
AccessorFunc(PANEL, "label", "Label", FORCE_STRING)

function PANEL:Init()
	self:SetText("")
	self:SetSize(220, 24)
	self.knob = 0
	self.label = ""
end

function PANEL:DoClick()
	ix.ag.Click()
	self:SetChecked(!self:GetChecked())
	if (self.OnChange) then self:OnChange(self:GetChecked()) end
end

function PANEL:Paint(w, h)
	self.knob = ix.ag.Dampen(14, self.knob, self:GetChecked() and 1 or 0)

	local bw, bh = 38, 18
	local x, y = 0, h / 2 - bh / 2
	local col = self:GetChecked() and ix.ag.C.neon or ix.ag.C.stroke

	surface.SetDrawColor(col.r, col.g, col.b, 60)
	surface.DrawRect(x, y, bw, bh)
	surface.SetDrawColor(col)
	surface.DrawOutlinedRect(x, y, bw, bh, 1)

	local kx = x + 2 + (bw - 16) * self.knob
	surface.SetDrawColor(self:GetChecked() and ix.ag.C.neon or ix.ag.C.textDim)
	surface.DrawRect(kx, y + 2, 12, bh - 4)
	if (self:GetChecked()) then
		ix.ag.DrawNeonEdge(x, y + bh - 2, bw, ix.ag.C.neon, 120)
	end

	if (self.label ~= "") then
		draw.SimpleText(self.label, "AG.Small", bw + 10, h / 2, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	return true
end

vgui.Register("AGToggle", PANEL, "DButton")
