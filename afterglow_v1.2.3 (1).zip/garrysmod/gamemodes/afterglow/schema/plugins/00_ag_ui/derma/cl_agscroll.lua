-- AGScrollPanel — скролл-панель с неоновым скроллбаром
local PANEL = {}

function PANEL:Init()
	local bar = self:GetVBar()
	bar:SetWide(6)
	bar.Paint = function(_, w, h)
		surface.SetDrawColor(255, 255, 255, 8)
		surface.DrawRect(0, 0, w, h)
	end
	bar.btnUp.Paint = function() end
	bar.btnDown.Paint = function() end
	bar.btnGrip.Paint = function(grip, w, h)
		local col = grip:IsHovered() and ix.ag.C.neon or ix.ag.C.stroke
		surface.SetDrawColor(col)
		surface.DrawRect(0, 0, w, h)
	end
end

function PANEL:AddItem(pnl)
	pnl:SetParent(self:GetCanvas())
	return pnl
end

vgui.Register("AGScrollPanel", PANEL, "DScrollPanel")
