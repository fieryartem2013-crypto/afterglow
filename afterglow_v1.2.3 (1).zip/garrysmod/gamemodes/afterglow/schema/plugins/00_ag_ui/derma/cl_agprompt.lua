-- AGPrompt — модальное окно ввода строки (баны/причины/ник)
local PANEL = {}

function PANEL:Init()
	self:SetSize(ScrW() * 0.32, 150)
	self:Center()
	self:MakePopup()
	self:MoveToFront()
	self:SetTitle("ВВОД")

	self.entry = self:Add("DTextEntry")
	self.entry:Dock(TOP)
	self.entry:DockMargin(10, 36, 10, 8)
	self.entry:SetTall(26)
	self.entry:SetFont("AG.Medium")
	self.entry.Paint = function(e, w, h)
		surface.SetDrawColor(10, 12, 16, 230)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(e:IsEditing() and ix.ag.C.neon or ix.ag.C.stroke)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
		e:DrawTextEntryText(e:GetTextColor(), ix.ag.C.neon, e:GetTextColor())
	end
	self.entry.OnEnter = function() self:Confirm() end
	self.entry:RequestFocus()

	local row = self:Add("Panel")
	row:Dock(BOTTOM)
	row:DockMargin(10, 0, 10, 10)
	row:SetTall(28)

	local cancel = row:Add("AGButton")
	cancel:Dock(LEFT)
	cancel:SetWide(120)
	cancel:SetText("ОТМЕНА")
	cancel:SetVariant("ghost")
	cancel.DoClick = function() ix.ag.Click() self:Remove() end

	local ok = row:Add("AGButton")
	ok:Dock(RIGHT)
	ok:SetWide(160)
	ok:SetText("ПОДТВЕРДИТЬ")
	ok.DoClick = function() self:Confirm() end
end

function PANEL:Confirm()
	ix.ag.Click()
	if (self.OnConfirm) then self:OnConfirm(self.entry:GetValue()) end
	self:Remove()
end

function PANEL:Paint(w, h)
	ix.ag.DrawBlur(self, 2)
	surface.SetDrawColor(ix.ag.C.bgPanel)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(ix.ag.C.stroke)
	surface.DrawOutlinedRect(0, 0, w, h, 1)
	ix.ag.DrawTechCorners(0, 0, w, h, 9, 2, ColorAlpha(ix.ag.C.neon, 190))
	ix.ag.DrawNeonEdge(6, 0, w - 12, ix.ag.C.neon, 140)
	draw.SimpleText("AFTERGLOW // " .. (self:GetTitle() or ""), "AG.SmallB", 10, 8, ix.ag.C.textDim)
end

vgui.Register("AGPrompt", PANEL, "EditablePanel")

function ix.ag.Prompt(title, default, onConfirm)
	local p = vgui.Create("AGPrompt")
	p:SetTitle(title)
	p.entry:SetText(default or "")
	p.OnConfirm = onConfirm
	return p
end
