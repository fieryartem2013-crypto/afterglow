-- AGButton — неоновая кнопка с lerp-ховером и вариантами
local PANEL = {}

AccessorFunc(PANEL, "variant", "Variant", FORCE_STRING)
AccessorFunc(PANEL, "font", "Font", FORCE_STRING)
AccessorFunc(PANEL, "icon", "Icon")

function PANEL:Init()
	self:SetText("")
	self.variant = "primary"
	self.font = "AG.SmallB"
	self.hover = 0
	self.clickT = 0
	self.baseColor = ix.ag.C.neon
end

function PANEL:VariantColor()
	if (self.variant == "danger") then return ix.ag.C.red end
	if (self.variant == "ghost") then return ix.ag.C.textDim end
	if (self.variant == "amber") then return ix.ag.C.amber end
	if (self.variant == "green") then return ix.ag.C.green end
	return ix.ag.C.neon
end

function PANEL:Paint(w, h)
	local t = RealTime()
	local col = self:VariantColor()
	local target = (self:IsHovered() and self:IsEnabled()) and 1 or 0
	self.hover = ix.ag.Dampen(12, self.hover, target)

	local disabled = !self:IsEnabled()
	local alpha = disabled and 40 or (30 + self.hover * 200)

	-- фон и рамка
	surface.SetDrawColor(col.r, col.g, col.b, alpha * 0.12)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(col.r, col.g, col.b, alpha * 0.7)
	surface.DrawOutlinedRect(0, 0, w, h, 1)

	-- неоновая нижняя кромка при ховере
	if (self.hover > 0.01) then
		ix.ag.DrawNeonEdge(0, h - 2, w, col, 220 * self.hover)
	end

	-- клик-флэш
	local flash = math.max(0, 1 - (t - self.clickT) * 3)
	if (flash > 0) then
		surface.SetDrawColor(255, 255, 255, 40 * flash)
		surface.DrawRect(0, 0, w, h)
	end

	local tx = w / 2
	if (self.icon) then
		surface.SetDrawColor(ColorAlpha(col, disabled and 90 or 255))
		surface.SetMaterial(self.icon)
		surface.DrawTexturedRect(8, h / 2 - 8, 16, 16)
		tx = tx + 8
	end

	draw.SimpleText(self:GetText(), self.font, tx, h / 2,
		disabled and ix.ag.C.textMute or (self:IsHovered() and col or ix.ag.C.text),
		TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	if (self.PaintOver) then self:PaintOver(w, h) end
	return true
end

function PANEL:DoClick()
	if (!self:IsEnabled()) then return end
	self.clickT = RealTime()
	ix.ag.Click()
	if (self.OnDoClick) then self:OnDoClick() end
end

vgui.Register("AGButton", PANEL, "DButton")
