-- ============================================================
-- AFTERGLOW UI CORE (ag_ui)
-- Собственная библиотека рендера: блюр, неоновые градиенты,
-- «tech-corner» рамки в стиле интерфейсов Альянса из HL:A,
-- lerp-анимации, шрифты. BSHADOWS-совместима (мягкая интеграция).
-- Все компоненты: derma/cl_ag*.lua
-- ============================================================
PLUGIN.name = "AfterGlow UI Core"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Базовый слой отрисовки и компонентов интерфейса AfterGlow."

ix.ag = ix.ag or {}

if (!CLIENT) then return end

-- ------------------------------------------------------------
-- ПАЛИТРА
-- ------------------------------------------------------------
local C = {}
C.bgDeep      = Color(7, 10, 14, 235)      -- глубокий фон
C.bgPanel     = Color(15, 19, 26, 238)     -- панели
C.bgPanelLite = Color(22, 28, 38, 235)
C.stroke      = Color(50, 62, 78, 255)     -- тонкие рамки
C.neon        = Color(0, 212, 255)         -- главный неон (голограммы Рассела)
C.neonSoft    = Color(90, 226, 255)
C.amber       = Color(255, 176, 48)        -- янтарь Альянса
C.amberSoft   = Color(255, 203, 105)
C.green       = Color(84, 255, 150)
C.red         = Color(255, 72, 72)
C.violet      = Color(168, 130, 255)
C.combine     = Color(72, 132, 255)        -- синий Альянса
C.text        = Color(217, 226, 235)
C.textDim     = Color(130, 142, 155)
C.textMute    = Color(88, 96, 108)
C.black       = Color(0, 0, 0)
ix.ag.C = C

function ix.ag.Hex(hex) -- "RRGGBB" или "RRGGBBAA"
	hex = hex:gsub("#", "")
	local r = tonumber("0x" .. hex:sub(1, 2)) or 255
	local g = tonumber("0x" .. hex:sub(3, 4)) or 255
	local b = tonumber("0x" .. hex:sub(5, 6)) or 255
	local a = tonumber("0x" .. (hex:sub(7, 8) ~= "" and hex:sub(7, 8) or "FF")) or 255
	return Color(r, g, b, a)
end

-- ------------------------------------------------------------
-- ОПЦИИ UI (клиентские, через ix.option)
-- ------------------------------------------------------------
ix.option.Add("agBlur", ix.type.number, 2, {category = "AfterGlow UI", min = 0, max = 3, decimals = 0})
ix.option.Add("agScanlines", ix.type.bool, true, {category = "AfterGlow UI"})
ix.option.Add("agAnimations", ix.type.bool, true, {category = "AfterGlow UI"})
ix.option.Add("agMenuSounds", ix.type.bool, true, {category = "AfterGlow UI"})
ix.option.Add("agEspNoclipOnly", ix.type.bool, true, {category = "AfterGlow UI"})

-- ------------------------------------------------------------
-- ШРИФТЫ (рисуются через hook LoadFonts)
-- ------------------------------------------------------------
function PLUGIN:LoadFonts(font, genericFont)
	font = genericFont or font
	local function S(size) return size end

	surface.CreateFont("AG.Tiny",   {font = font, size = S(13), weight = 500, extended = true, antialias = true})
	surface.CreateFont("AG.Small",  {font = font, size = S(15), weight = 500, extended = true, antialias = true})
	surface.CreateFont("AG.SmallB", {font = font, size = S(15), weight = 700, extended = true, antialias = true})
	surface.CreateFont("AG.Medium", {font = font, size = S(18), weight = 500, extended = true, antialias = true})
	surface.CreateFont("AG.MediumB",{font = font, size = S(18), weight = 700, extended = true, antialias = true})
	surface.CreateFont("AG.Big",    {font = font, size = S(24), weight = 600, extended = true, antialias = true})
	surface.CreateFont("AG.BigB",   {font = font, size = S(24), weight = 800, extended = true, antialias = true})
	surface.CreateFont("AG.Title",  {font = font, size = S(32), weight = 700, extended = true, antialias = true})
	surface.CreateFont("AG.Huge",   {font = font, size = S(46), weight = 700, extended = true, antialias = true})
	surface.CreateFont("AG.Mono",     {font = "Consolas", size = S(15), extended = true, antialias = true})
	surface.CreateFont("AG.MonoSmall", {font = "Consolas", size = S(13), extended = true, antialias = true})
	surface.CreateFont("AG.Lambda", {font = "HalfLife2", size = S(42), extended = true, antialias = true})
	surface.CreateFont("AG.LambdaBig", {font = "HalfLife2", size = S(110), extended = true, antialias = true})
	-- генерация «иконочного» шрифта из HalfLife2 (значки HL2)
	surface.CreateFont("AG.HL2Icons", {font = "HalfLife2", size = S(20), extended = true, antialias = true})
end

-- ------------------------------------------------------------
-- ЗВУКИ UI
-- ------------------------------------------------------------
function ix.ag.Click()
	if (ix.option.Get("agMenuSounds", true)) then
		surface.PlaySound("buttons/button16.wav")
	end
end

function ix.ag.HoverSound() end -- тихо по дизайну

-- ------------------------------------------------------------
-- LERP-ХЕЛПЕРЫ (frame-time independent)
-- ------------------------------------------------------------
function ix.ag.Dampen(speed, current, target)
	return Lerp(math.min(RealFrameTime() * speed, 1), current, target)
end

function ix.ag.DampenColor(speed, current, target)
	return Color(
		ix.ag.Dampen(speed, current.r, target.r),
		ix.ag.Dampen(speed, current.g, target.g),
		ix.ag.Dampen(speed, current.b, target.b),
		ix.ag.Dampen(speed, current.a or 255, target.a or 255)
	)
end

-- ------------------------------------------------------------
-- ПРИМИТИВЫ ОТРИСОВКИ
-- ------------------------------------------------------------
local blurMat = Material("pp/blurscreen")

-- Блюр за панелью (pp/blurscreen). strength: 0-3.
function ix.ag.DrawBlur(panel, strength)
	strength = strength or ix.option.Get("agBlur", 2)
	if (strength <= 0) then return end

	local x, y = panel:LocalToScreen(0, 0)
	local w, h = panel:GetWide(), panel:GetTall()
	if (w <= 0 or h <= 0) then return end

	render.SetScissorRect(x, y, x + w, y + h, true)
	surface.SetDrawColor(255, 255, 255)
	surface.SetMaterial(blurMat)
	for i = 1, 3 do
		blurMat:SetFloat("$blur", (i / 3) * (strength * 2.2))
		blurMat:Recompute()
		render.UpdateScreenEffectTexture()
		surface.DrawTexturedRect(-x, -y, ScrW(), ScrH())
	end
	render.SetScissorRect(0, 0, 0, 0, false)
end

-- Мягкая тень за прямоугольником (стиль BSHADOWS; если глобальный
-- BSHADOWS установлен — используется он)
function ix.ag.DrawShadow(x, y, w, h, layers)
	if (BSHADOWS) then return end -- аддон BShadows перехватит сам при желании
	draw.RoundedBox(6, x - 4, y - 2 + 3, w + 8, h + 6, Color(0, 0, 0, 42))
	draw.RoundedBox(6, x - 2, y - 1 + 2, w + 4, h + 3, Color(0, 0, 0, 46))
end

-- «Tech-corners»: L-уголки вместо сплошной рамки — визитка HL:A UI
function ix.ag.DrawTechCorners(x, y, w, h, len, gap, col)
	len = len or 10
	gap = gap or 2
	col = col or ix.ag.C.neon
	surface.SetDrawColor(col)
	-- LT
	surface.DrawRect(x, y, len, gap)
	surface.DrawRect(x, y, gap, len)
	-- RT
	surface.DrawRect(x + w - len, y, len, gap)
	surface.DrawRect(x + w - gap, y, gap, len)
	-- LB
	surface.DrawRect(x, y + h - gap, len, gap)
	surface.DrawRect(x, y + h - len, gap, len)
	-- RB
	surface.DrawRect(x + w - len, y + h - gap, len, gap)
	surface.DrawRect(x + w - gap, y + h - len, gap, len)
end

-- Неоновая двусторонняя градиент-линия (верхняя кромка панелей)
function ix.ag.DrawNeonEdge(x, y, w, col, alphaFade)
	local seg = math.max(4, math.floor(w / 24))
	for i = 0, seg - 1 do
		local t = i / (seg - 1)
		local falloff = 1 - math.abs(t - 0.5) * 2 -- пик в центре
		local a = (alphaFade or 160) * falloff
		surface.SetDrawColor(col.r, col.g, col.b, a)
		surface.DrawRect(x + (w / seg) * i, y, w / seg + 1, 2)
	end
end

-- Сканлайны поверх области (голографический эффект)
function ix.ag.DrawScanlines(x, y, w, h, alpha)
	if (!ix.option.Get("agScanlines", true)) then return end
	render.SetScissorRect(x, y, x + w, y + h, true)
	surface.SetDrawColor(255, 255, 255, alpha or 6)
	for ly = y, y + h, 3 do
		surface.DrawRect(x, ly, w, 1)
	end
	render.SetScissorRect(0, 0, 0, 0, false)
end

-- Неоновая шкала прогресса
function ix.ag.DrawNeonBar(x, y, w, h, frac, col, label, labelRight)
	frac = math.Clamp(frac, 0, 1)
	col = col or ix.ag.C.neon

	draw.RoundedBox(2, x, y, w, h, Color(10, 12, 16, 220))
	surface.SetDrawColor(col.r, col.g, col.b, 40)
	surface.DrawRect(x, y, w, h)
	if (frac > 0) then
		local pulse = 200 + 55 * math.sin(RealTime() * (frac < 0.2 and 8 or 2))
		surface.SetDrawColor(ColorAlpha(col, math.Clamp(pulse, 120, 255)))
		surface.DrawRect(x + 1, y + 1, (w - 2) * frac, h - 2)
		-- головка шкалы
		surface.SetDrawColor(255, 255, 255, 200)
		surface.DrawRect(x + 1 + (w - 2) * frac - 2, y + 1, 2, h - 2)
	end
	if (label) then
		draw.SimpleText(label, "AG.Tiny", x + 6, y + h / 2, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end
	if (labelRight) then
		draw.SimpleText(labelRight, "AG.Tiny", x + w - 6, y + h / 2, ix.ag.C.textDim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
end

-- Деление текста, подстраивающийся под ширину
function ix.ag.WrapText(text, font, width)
	surface.SetFont(font)
	local lines, line = {}, ""
	for word in string.gmatch(text, "%S+") do
		local test = line == "" and word or (line .. " " .. word)
		if (surface.GetTextSize(test) > width and line ~= "") then
			table.insert(lines, line)
			line = word
		else
			line = test
		end
	end
	if (line ~= "") then table.insert(lines, line) end
	return lines
end

-- Формат секунд в 03:12:45
function ix.ag.FormatTime(s)
	s = math.floor(s)
	return string.format("%02d:%02d:%02d", math.floor(s / 3600), math.floor(s / 60) % 60, s % 60)
end

-- посылает подписки на derma-компоненты
if (CLIENT) then
	ix.util.IncludeDir(PLUGIN.folder .. "/derma")
end
