-- ============================================================
-- Загрузка контента клиентам.
-- ВАРИАНТ A (рекомендуется): соберите весь аддон hlarp + модели в
-- ОДИН workshop-аддон и подключите коллекцию в стартовой строке.
-- ВАРИАНТ B (ниже): раздача lua-файлов с сервера напрямую.
-- ============================================================
PLUGIN.name = "Downloads"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Resource.AddWorkshop/AddFile для контента HL:A RP."

if (SERVER) then
	-- Дополнительные workshop-аддоны вне коллекции (ID по желанию):
	local WORKSHOP_IDS = {
		-- Примеры (замените на свои актуальные; смотрите docs/server_setup.md):
		-- "1924936838", -- коллекция HL:A Addons подключите как коллекцию, не сюда
	}

	for _, id in ipairs(WORKSHOP_IDS) do
		resource.AddWorkshop(id)
	end

	-- Принудительная раздача lua нашего аддона (если аддон НЕ в workshop):
	local FILES = {
		"lua/weapons/weapon_gravgloves/shared.lua",
		"lua/weapons/weapon_gravgloves/init.lua",
		"lua/weapons/weapon_gravgloves/cl_init.lua",
		"lua/entities/ix_workbench/shared.lua",
		"lua/entities/ix_workbench/init.lua",
		"lua/entities/ix_workbench/cl_init.lua",
		"lua/entities/ix_terminal/shared.lua",
		"lua/entities/ix_terminal/init.lua",
		"lua/entities/ix_terminal/cl_init.lua"
	}

	for _, f in ipairs(FILES) do
		resource.AddFile(f)
	end

	-- Если добавите свои модели/звуки/материалы в addons/afterglow —
	-- сгенерируйте список: (Linux) find addons/afterglow -type f | sed 's#addons/afterglow/##' и внесите сюда.
end
