-- ============================================================
-- Радиоэфир: канал Сопротивления (нужен предмет radio),
-- тактический канал Альянса (имплант: ГО/ОВА/администрация).
-- ============================================================
PLUGIN.name = "Radio"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Каналы рации повстанцев и тактический эфир ГО/ОВА."

local function HasRadio(client)
	local ch = client:GetCharacter()
	if (!ch) then return false end
	for _, item in pairs(ch:GetInventory():GetItems()) do
		if (item.uniqueID == "radio") then return true end
	end
	return false
end

local function IsCombineRadio(client)
	local ch = client:GetCharacter()
	if (!ch) then return false end
	local f = ch:GetFaction()
	return f == FACTION_CP or f == FACTION_OVERWATCH or f == FACTION_ADMINISTRATION
end

ix.chat.Register("radio_res", {
	format = "(РАДИО) %s: «%s»",
	color = Color(255, 160, 80),
	deadCanHear = false,
	CanHear = function(speaker, listener)
		return HasRadio(listener) and HasRadio(speaker)
	end
})

ix.chat.Register("radio_tac", {
	format = "(ТАК-ЭФИР) %s: «%s»",
	color = Color(90, 140, 255),
	deadCanHear = false,
	CanHear = function(speaker, listener)
		return IsCombineRadio(listener)
	end
})

ix.command.Add("Radio", {
	description = "Сообщение в канал Сопротивления (нужна рация).",
	arguments = {ix.type.text},
	OnRun = function(self, client, text)
		if (!HasRadio(client)) then
			client:Notify("У вас нет рации.")
			return
		end
		ix.chat.Send(client, "radio_res", text)
	end
})

ix.command.Add("Tac", {
	description = "Сообщение в тактический эфир Альянса.",
	arguments = {ix.type.text},
	OnRun = function(self, client, text)
		if (!IsCombineRadio(client)) then
			client:Notify("Нет доступа к тактическому эфиру.")
			return
		end
		ix.chat.Send(client, "radio_tac", text)
	end
})
