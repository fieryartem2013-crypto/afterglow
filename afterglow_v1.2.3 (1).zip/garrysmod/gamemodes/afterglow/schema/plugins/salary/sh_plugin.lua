-- ============================================================
-- Зарплата токенами: периодическая выдача по классу.
-- ============================================================
PLUGIN.name = "Salary"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Периодическая зарплата токенами зарегистрированным гражданам и служащим."

ix.config.Add("salaryInterval", 600, "Интервал выдачи зарплаты (сек).")
ix.config.Add("salaryEnabled", true, "Включить зарплату.")

-- Суммы по классу. Строятся лениво на первой выдаче —
-- тогда константы классов гарантированно существуют.
PLUGIN.amounts = nil

function PLUGIN:BuildAmounts()
	self.amounts = {
		[CLASS_REGISTERED] = 12,
		[CLASS_WORKER] = 18,
		[CLASS_CP_UNION] = 20,
		[CLASS_CP_HELIX] = 20,
		[CLASS_CP_JURY] = 20,
		[CLASS_CP_GRID] = 20,
		[CLASS_OFFICIAL] = 30
	}
end

function PLUGIN:LoadData()
	self:StartTimer()
end

function PLUGIN:InitializedConfig()
	self:StartTimer()
end

function PLUGIN:StartTimer()
	timer.Remove("ixSalary")
	if (!ix.config.Get("salaryEnabled", true)) then return end

	timer.Create("ixSalary", ix.config.Get("salaryInterval", 600), 0, function()
		if (!PLUGIN.amounts) then PLUGIN:BuildAmounts() end
		for _, client in player.Iterator() do
			local ch = client:GetCharacter()
			if (ch) then
				local amount = PLUGIN.amounts[ch:GetClass()] or 0
				if (amount > 0) then
					ch:GiveMoney(amount)
					client:Notify("ВЫДАЧА ГВ: зачислено " .. amount .. " токенов.")
				end
			end
		end
	end)
end
