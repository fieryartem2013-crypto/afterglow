local PLAYER = FindMetaTable("Player")

function PLAYER:GetWoundsSummary()
	if (!ix.medical) then return "" end
	local w = ix.medical.GetWounds(self)
	local out = {}
	if ((w.bleed or 0) > 0) then table.insert(out, "кровотечение " .. w.bleed) end
	if ((w.infection or 0) > 0) then table.insert(out, "заражение " .. w.infection) end
	if (w.fracture) then table.insert(out, w.splinted and "перелом (шина)" or "перелом") end
	if (w.burn) then table.insert(out, "плазменный ожог") end
	return table.concat(out, ", ")
end
