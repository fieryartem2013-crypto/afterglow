-- ============================================================
-- МОДУЛЬ 5: Расширенная медицина
-- Статусы: bleed (0-2), infection (0-2 стадии), fracture, burn.
-- Хранение: character:GetData("wounds") — таблица (переживает смерть? нет:
-- раны сбрасываются при смерти, см. PlayerDeath ниже; правило PK/не-PK —
-- на усмотрение правил сервера).
-- ============================================================
PLUGIN.name = "Advanced Medical"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Кровотечения, заражение спорами, переломы, плазменные ожоги; лечебные предметы и ворт-эссенция."

ix.medical = ix.medical or {}

ix.util.Include("meta/sh_player.lua")
if (CLIENT) then
	ix.util.Include("derma/cl_status.lua")
end

ix.config.Add("medBleedInterval", 4, "Сек между тиками кровопотери на 1 уровень кровотечения.")
ix.config.Add("medBleedDamage", 1, "Урон за тик кровопотери.")
ix.config.Add("medInfectionInterval", 6, "Сек между тиками спорового заражения.")
ix.config.Add("medInfectionDamage", 1, "Урон за тик заражения (стадия 2 — x3).")
ix.config.Add("medInfectionStageTime", 360, "Сек до перехода заражения на 2 стадию.")
ix.config.Add("medFractureSpeedRatio", 0.55, "Множитель скорости при переломе.")
ix.config.Add("medSplintHealTime", 300, "Сек заживления перелома после наложения шины.")
ix.config.Add("medStimPackWindow", 300, "Окно учёта передозировки стимуляторов (сек).")
ix.config.Add("medStimOverdoseMax", 2, "Макс. инъекций стимулятора в окне без последствий.")

-- ------------------------------------------------------------
-- API (shared): работа со статусами
-- ------------------------------------------------------------
function ix.medical.GetWounds(client)
	local character = client:GetCharacter()
	if (!character) then return {} end
	return character:GetData("wounds", {})
end

function ix.medical.SetWounds(client, wounds)
	local character = client:GetCharacter()
	if (!character) then return end
	character:SetData("wounds", wounds)
	if (SERVER) then PLUGIN:ApplySpeed(client) end
end

function ix.medical.AddBleed(client, sev)
	local w = ix.medical.GetWounds(client)
	w.bleed = math.min(2, (w.bleed or 0) + sev)
	ix.medical.SetWounds(client, w)
	client:Notify("У вас кровотечение (уровень " .. w.bleed .. ").")
end

function ix.medical.TreatBleed(client, amount)
	local w = ix.medical.GetWounds(client)
	if ((w.bleed or 0) <= 0) then return end
	w.bleed = math.max(0, w.bleed - (amount or 1))
	ix.medical.SetWounds(client, w)
	client:Notify(w.bleed > 0 and "Кровотечение ослаблено (уровень " .. w.bleed .. ")." or "Кровотечение остановлено.")
end

function ix.medical.Infect(client, stage)
	local w = ix.medical.GetWounds(client)
	if ((w.infection or 0) >= stage) then return end
	w.infection = stage
	w.infectionTime = CurTime()
	ix.medical.SetWounds(client, w)
	client:Notify("В горле першит. Зрачки расплываются. Вы заражены спорами Зена.")
end

function ix.medical.CureInfection(client)
	local w = ix.medical.GetWounds(client)
	w.infection = 0
	w.infectionTime = nil
	ix.medical.SetWounds(client, w)
	client:Notify("Жжение отступает. Заражение подавлено.")
end

function ix.medical.AddFracture(client)
	local w = ix.medical.GetWounds(client)
	if (w.fracture) then return end
	w.fracture = true
	ix.medical.SetWounds(client, w)
	client:Notify("Хруст в ноге — перелом. Скорость передвижения резко снижена.")
end

function ix.medical.ApplySplint(client)
	local w = ix.medical.GetWounds(client)
	if (!w.fracture or w.splinted) then return end
	w.splinted = true
	w.splintTime = CurTime()
	ix.medical.SetWounds(client, w)
	client:Notify("Шина наложена. Перелом заживёт примерно за " .. ix.config.Get("medSplintHealTime", 300) .. " секунд покоя.")
end

function ix.medical.AddBurn(client)
	local w = ix.medical.GetWounds(client)
	w.burn = true
	ix.medical.SetWounds(client, w)
	client:Notify("Плазменный ожог. Обычные аптечки не действуют — нужен гелевый пластырь.")
end

function ix.medical.TreatBurn(client)
	local w = ix.medical.GetWounds(client)
	w.burn = false
	ix.medical.SetWounds(client, w)
	client:Notify("Гель защищает ожог. Лечение снова эффективно.")
end

function ix.medical.HealBasic(client, amount)
	local w = ix.medical.GetWounds(client)
	if (w.burn) then
		client:Notify("Плазменный ожог не даёт лекарству подействовать. Сначала — гель.")
		return
	end
	client:SetHealth(math.min(client:GetMaxHealth(), client:Health() + amount))
	client:EmitSound("items/medshot4.wav")
end

function ix.medical.UseStim(client)
	-- передозировка
	local character = client:GetCharacter()
	local stims = character:GetData("stimLog", {})
	local now = CurTime()
	local window = ix.config.Get("medStimPackWindow", 300)

	local fresh = {}
	for _, t in ipairs(stims) do
		if (now - t < window) then table.insert(fresh, t) end
	end
	table.insert(fresh, now)
	character:SetData("stimLog", fresh)

	client:SetHealth(math.min(client:GetMaxHealth(), client:Health() + 25))
	client:EmitSound("items/medshot4.wav")

	local max = ix.config.Get("medStimOverdoseMax", 2)
	if (#fresh > max) then
		client:Notify("Сердце колотится. Передозировка стимулятором!")
		client.nextStimSickness = now + 60
		util.ScreenShake(client:GetPos(), 6, 8, 2, 0)
	else
		-- короткий прилив: временное ускорение
		client.medStimBoost = now + 25
		PLUGIN:ApplySpeed(client)
		client:Notify("Тепло растекается по венам. +25 HP, краткий прилив сил.")
	end
end

function ix.medical.UseEssence(client)
	ix.medical.CureInfection(client)
	client.medEssenceUntil = CurTime() + 60
	client:Notify("Сущность вортигонта шепчет на частотах плоти. Раны тянутся, закрываются.")
	client:EmitSound("npc/vort/health_charge.wav", 60)
end

function ix.medical.IsMedic(client)
	local class = ix.class.list[client:GetCharacter():GetClass()]
	return class and (class.index == CLASS_RES_MEDIC or class.index == CLASS_CP_HELIX or class.index == CLASS_VORTIGAUNT)
end

-- ------------------------------------------------------------
-- СЕРВЕР: назначение ран по типам урона + тики статусов
-- ------------------------------------------------------------
if (SERVER) then
	function PLUGIN:EntityTakeDamage(target, dmg)
		if (!target:IsPlayer() or !target:GetCharacter()) then return end
		local attacker = dmg:GetAttacker()
		local bits = dmg:GetDamageType()
		local amount = dmg:GetDamage()
		if (amount < 4) then return end

		-- Огнестрел/резаные/тупые → кровотечение
		if (bit.band(bits, bit.bor(DMG_BULLET, DMG_SLASH, DMG_CLUB, DMG_BUCKSHOT, DMG_SNIPER)) != 0) then
			if (math.random() < 0.30 + math.min(0.3, amount * 0.005)) then
				ix.medical.AddBleed(target, math.random() < 0.15 and 2 or 1)
			end
		end

		-- Плазма/ожоги/растворение → плазменный ожог
		if (bit.band(bits, bit.bor(DMG_BURN, DMG_DISSOLVE, DMG_PLASMA, DMG_SHOCK)) != 0
			or (IsValid(attacker) and attacker:GetClass() == "prop_combine_ball")) then
			ix.medical.AddBurn(target)
		end

		-- Фауна Зена → заражение
		if (IsValid(attacker)) then
			local class = attacker:GetClass()
			if (class == "npc_headcrab_black" or class == "npc_poisonzombie") then
				if (math.random() < 0.50) then ix.medical.Infect(target, 1) end
			elseif (class == "npc_headcrab" or class == "npc_headcrab_fast" or class == "npc_zombie" or class == "npc_fastzombie") then
				if (math.random() < 0.18) then ix.medical.Infect(target, 1) end
			end
		end
	end

	-- Перелом от падения
	function PLUGIN:GetFallDamage(client, speed)
		local damage = math.max(0, math.ceil(0.18 * (speed - 530)))
		if (damage >= 14 and math.random() < 0.6) then
			timer.Simple(0, function()
				if (IsValid(client) and client:Alive()) then ix.medical.AddFracture(client) end
			end)
		end
		return damage
	end

	-- Тики: кровопотеря, заражение, передоз, эссенция, шины
	function PLUGIN:Tick()
		local now = CurTime()
		if ((self.nextMed or 0) > now) then return end
		self.nextMed = now + 1

		for _, client in player.Iterator() do
			if (!client:Alive() or !client:GetCharacter()) then continue end
			local w = ix.medical.GetWounds(client)

			-- кровотечение
			if ((w.bleed or 0) > 0) then
				if ((client.nextBleedTick or 0) <= now) then
					client.nextBleedTick = now + ix.config.Get("medBleedInterval", 4)
					client:TakeDamage(ix.config.Get("medBleedDamage", 1) * w.bleed, game.GetWorld(), game.GetWorld())
					util.Effect("BloodImpact", EffectData():SetOrigin(client:GetPos() + Vector(0, 0, 40)))
				end
			end

			-- заражение: прогрессия стадии + урон
			if ((w.infection or 0) > 0) then
				if (w.infection == 1 and w.infectionTime and now - w.infectionTime > ix.config.Get("medInfectionStageTime", 360)) then
					w.infection = 2
					ix.medical.SetWounds(client, w)
					client:Notify("Споры достигли крови. СТАДИЯ 2. Найдите антидот или вортигонта.")
				end
				if ((client.nextInfectionTick or 0) <= now) then
					client.nextInfectionTick = now + ix.config.Get("medInfectionInterval", 6)
					local dmg = ix.config.Get("medInfectionDamage", 1) * (w.infection == 2 and 3 or 1)
					client:TakeDamage(dmg, game.GetWorld(), game.GetWorld())
				end
			end

			-- перелом с шиной → выздоровление
			if (w.fracture and w.splinted and w.splintTime
				and now - w.splintTime > ix.config.Get("medSplintHealTime", 300)) then
				w.fracture = false
				w.splinted = false
				ix.medical.SetWounds(client, w)
				client:Notify("Кость срослась. Вы снова можете бегать.")
			end

			-- передозировка
			if (client.nextStimSickness and client.nextStimSickness > now) then
				if ((client.nextSickTick or 0) <= now) then
					client.nextSickTick = now + 5
					client:TakeDamage(2, game.GetWorld(), game.GetWorld())
				end
			end

			-- стимуляторный прилив истёк?
			if (client.medStimBoost and client.medStimBoost <= now) then
				client.medStimBoost = nil
				self:ApplySpeed(client)
			end

			-- ворт-регенерация
			if (client.medEssenceUntil and client.medEssenceUntil > now) then
				if ((client.nextEssenceTick or 0) <= now) then
					client.nextEssenceTick = now + 2
					client:SetHealth(math.min(client:GetMaxHealth(), client:Health() + 1))
				end
			end
		end
	end

	-- Скорости: перелом/стимулятор
	function PLUGIN:ApplySpeed(client)
		if (!client:GetCharacter()) then return end
		local walk = ix.config.Get("walkSpeed", 90)
		local run = ix.config.Get("runSpeed", 200)
		local w = ix.medical.GetWounds(client)

		if (w.fracture) then
			local ratio = ix.config.Get("medFractureSpeedRatio", 0.55)
			walk, run = walk * ratio, run * ratio
		end
		if (client.medStimBoost and client.medStimBoost > CurTime()) then
			run = run * 1.15
		end

		client:SetWalkSpeed(walk)
		client:SetRunSpeed(run)
		client:SetCrouchedWalkSpeed(w.fracture and 0.25 or 0.6)
	end

	function PLUGIN:PlayerLoadedCharacter(client, character)
		timer.Simple(1, function()
			if (IsValid(client)) then self:ApplySpeed(client) end
		end)
	end

	-- Смерть сбрасывает раны (правило «чистой смерти»; PK-события — по правилам сервера)
	function PLUGIN:PlayerDeath(client)
		local character = client:GetCharacter()
		if (character) then
			character:SetData("wounds", {})
			character:SetData("stimLog", {})
		end
	end
end

-- ------------------------------------------------------------
-- Вортигонт: извлечение эссенции (команда класса)
-- ------------------------------------------------------------
ix.command.Add("EssenceExtract", {
	description = "Вортигонт: извлечь склянку эссенции (-15 HP, раз в 10 минут).",
	OnRun = function(self, client)
		local character = client:GetCharacter()
		if (!character or character:GetClass() != CLASS_VORTIGAUNT) then
			client:Notify("Только вортигонт способен на такое.")
			return
		end
		local now = CurTime()
		if ((character:GetData("nextEssence", 0) or 0) > now) then
			client:Notify("Сущность ещё не восстановилась. Подождите " .. math.ceil((character:GetData("nextEssence", 0) - now) / 60) .. " мин.")
			return
		end
		if (client:Health() <= 20) then
			client:Notify("Вы слишком слабы, чтобы отдать часть себя.")
			return
		end

		character:SetData("nextEssence", now + 600)
		client:TakeDamage(15, client, client)
		character:GetInventory():Add("vortessence", 1)
		client:EmitSound("npc/vort/health_charge.wav", 55)
		ix.chat.Send(client, "me", "сжимает когтистую ладонь — в сгибе проступает мерцающая капля зелёного света.")
	end
})
