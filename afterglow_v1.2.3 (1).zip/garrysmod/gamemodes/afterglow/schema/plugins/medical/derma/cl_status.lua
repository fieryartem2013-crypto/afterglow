-- Иконки медицинских статусов (левый нижний угол)
local PLUGIN = PLUGIN

local STATUS_COLORS = {
	bleed = Color(200, 40, 40),
	infection = Color(120, 200, 60),
	fracture = Color(230, 230, 230),
	burn = Color(80, 160, 255)
}

function PLUGIN:HUDPaint()
	local client = LocalPlayer()
	if (!client:GetCharacter() or !ix.medical) then return end

	local w = ix.medical.GetWounds(client)
	local y = ScrH() * 0.62
	local x = ScrW() * 0.03
	local shown = 0

	local function Status(label, color, pulse)
		pulse = pulse or 0
		local alpha = 200 + 55 * math.sin(CurTime() * (2 + pulse))
		ix.util.DrawText(label, x, y, ColorAlpha(color, math.Clamp(alpha, 60, 255)), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, "ixSmallFont")
		y = y + 16
		shown = shown + 1
	end

	if ((w.bleed or 0) > 0) then Status("✚ КРОВОТЕЧЕНИЕ " .. w.bleed, STATUS_COLORS.bleed, 1) end
	if ((w.infection or 0) > 0) then Status("☣ ЗАРАЖЕНИЕ СПОРАМИ " .. ((w.infection == 2) and "— СТАДИЯ 2" or ""), STATUS_COLORS.infection, w.infection) end
	if (w.fracture) then Status(w.splinted and "⚠ ПЕРЕЛОМ (шина)" or "⚠ ПЕРЕЛОМ", STATUS_COLORS.fracture) end
	if (w.burn) then Status("♨ ПЛАЗМЕННЫЙ ОЖОГ", STATUS_COLORS.burn) end
	if (client.medEssenceUntil and client.medEssenceUntil > CurTime()) then
		Status("✧ ВОРТ-РЕГЕНЕРАЦИЯ", Color(120, 255, 150))
	end
end
