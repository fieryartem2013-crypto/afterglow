-- ============================================================
-- CID: регистрация граждан, карточки, проверки.
-- Незарегистрированный → зарегистрированный: стойка регистрации
-- (JURY / администрация / персонал).
-- ============================================================
PLUGIN.name = "CID Registration"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Присвоение CID, класс зарегистрированного, предъявление и проверка документов."

local function NewCID(character)
	-- 5-значный CID, свободный формат (можно заменить генератор на сквозную нумерацию)
	return string.format("%05d", math.random(0, 99999))
end

-- Регистрация: цель — ближний игрок, которого обрабатывает сотрудник
ix.command.Add("RegisterCitizen", {
	description = "Зарегистрировать стоящего рядом гражданина (JURY/администрация/персонал).",
	arguments = {ix.type.player},
	OnRun = function(self, client, target)
		if (!IsValid(target) or target:GetPos():DistToSqr(client:GetPos()) > 220 * 220) then
			client:Notify("Цель должна стоять рядом (до 220 юнитов).")
			return
		end

		local ch = client:GetCharacter()
		local allowed = client:IsAdmin()
		if (ch) then
			local class = ix.class.list[ch:GetClass()]
			allowed = allowed
				or ch:GetFaction() == FACTION_ADMINISTRATION
				or (class and class.index == CLASS_CP_JURY)
		end
		if (!allowed) then
			client:Notify("Регистрацию проводят JURY, администрация или персонал сервера.")
			return
		end

		local tch = target:GetCharacter()
		if (!tch or tch:GetFaction() != FACTION_CITIZEN) then
			client:Notify("Можно регистрировать только гражданских.")
			return
		end
		if (tch:GetClass() != CLASS_UNREGISTERED) then
			client:Notify("Гражданин уже зарегистрирован.")
			return
		end

		local cid = NewCID(tch)
		tch:SetData("cid", cid)
		tch:SetClass(CLASS_REGISTERED)

		local ok = tch:GetInventory():Add("cidcard", 1, {
			name = tch:GetName(),
			cid = cid
		})

		target:Notify("ВЫ ЗАРЕГИСТРИРОВАНЫ. CID: " .. cid .. ". Сохраните карту — это ваш статус.")
		client:Notify("Зарегистрирован: " .. tch:GetName() .. " (CID " .. cid .. ")" .. (ok and "" or " — КАРТА НЕ ВМЕСТИЛАСЬ!"))
		ix.chat.Send(target, "me", "получает штампованную карту с чипом — новый статус, новые обязанности.")
	end
})

-- Предъявить документ (по карте в инвентаре или по данным)
ix.command.Add("ShowID", {
	description = "Предъявить CID-карту окружающим.",
	OnRun = function(self, client)
		local ch = client:GetCharacter()
		if (!ch) then return end

		-- ищем карту в инвентаре — она достовернее данных
		for _, item in pairs(ch:GetInventory():GetItems()) do
			if (item.uniqueID == "cidcard") then
				ix.chat.Send(client, "me", "предъявляет CID-карту: "
					.. item:GetData("name", "НЕТ ДАННЫХ") .. ", CID " .. tostring(item:GetData("cid", "-----")))
				return
			end
		end

		local cid = ch:GetData("cid")
		if (cid) then
			ix.chat.Send(client, "me", "называет свои регистрационные данные: CID " .. tostring(cid) .. " (без карты)")
		else
			ix.chat.Send(client, "me", "нервно разводит руками: документов нет.")
		end
	end
})

-- Проверка: сотрудник ГО сверяет карту цели с базой
ix.command.Add("CheckID", {
	description = "ГО: сверить CID цели с базой Альянса (нужен взгляд на цель).",
	OnRun = function(self, client)
		local ch = client:GetCharacter()
		if (!ch or (ch:GetFaction() != FACTION_CP and ch:GetFaction() != FACTION_OVERWATCH and !client:IsAdmin())) then
			client:Notify("Только ГО/ОВА имеют доступ к базе регистрации.")
			return
		end

		local tr = client:GetEyeTraceNoCursor()
		local target = tr.Entity
		if (!IsValid(target) or !target:IsPlayer() or tr.HitPos:DistToSqr(client:GetPos()) > 200 * 200) then
			client:Notify("Цельтесь в гражданина рядом.")
			return
		end

		local tch = target:GetCharacter()
		if (!tch) then return end

		client:Notify("== БАЗА ГВ == Имя: " .. tch:GetName())
		local cid = tch:GetData("cid")
		if (tch:GetFaction() == FACTION_CITIZEN) then
			if (cid) then
				client:Notify("Статус: ЗАРЕГИСТРИРОВАН. CID: " .. tostring(cid))
				-- сверка карты с данными: расхождение = подделка
				for _, item in pairs(tch:GetInventory():GetItems()) do
					if (item.uniqueID == "cidcard") then
						if (tostring(item:GetData("cid")) ~= tostring(cid) or item:GetData("name") ~= tch:GetName()) then
							client:Notify("⚠ РАСХОЖДЕНИЕ ДАННЫХ КАРТЫ С БАЗОЙ — вероятна подделка!")
						else
							client:Notify("Карта совпадает с базой.")
						end
						return
					end
				end
				client:Notify("Карта при себе отсутствует.")
			else
				client:Notify("Статус: НЕ ЗАРЕГИСТРИРОВАН.")
			end
		else
			client:Notify("Не является гражданским объектом регистрации.")
		end
	end
})
