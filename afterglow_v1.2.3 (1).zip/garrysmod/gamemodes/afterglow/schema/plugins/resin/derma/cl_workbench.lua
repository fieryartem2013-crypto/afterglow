-- UI верстака: вкладки «Улучшения» и «Био-крафт»
local PLUGIN = PLUGIN

local PANEL = {}

function PANEL:Init()
	self:SetSize(ScrW() * 0.55, ScrH() * 0.6)
	self:Center()
	self:MakePopup()
	self:SetTitle("")
	self:ShowCloseButton(false)

	local close = self:Add("DButton")
	close:Dock(TOP)
	close:SetTall(28)
	close:SetText("× Закрыть (E)")
	close.DoClick = function() self:Remove() end

	self.sheet = self:Add("DPropertySheet")
	self.sheet:Dock(FILL)

	self:BuildUpgrades()
	self:BuildBio()
end

function PANEL:BuildUpgrades()
	local panel = self.sheet:Add("DPanel")
	panel:DockPadding(6, 6, 6, 6)
	self.sheet:AddSheet("Улучшения оружия", panel, "icon16/wrench.png")

	local client = LocalPlayer()
	local inventory = client:GetCharacter():GetInventory()

	local resinLabel = panel:Add("DLabel")
	resinLabel:Dock(TOP)
	resinLabel:SetTall(22)
	resinLabel:SetText("Смола в инвентаре: " .. ix.resinCount(inventory))
	resinLabel:SetFont("ixSmallFont")

	local list = panel:Add("DScrollPanel")
	list:Dock(FILL)

	-- оружие игрока
	for _, item in pairs(inventory:GetItems()) do
		if (item.base == "weapons") then
			local header = list:Add("DPanel")
			header:Dock(TOP)
			header:DockMargin(0, 4, 0, 0)
			header:SetTall(26)
			header.Paint = function(_, w, h)
				surface.SetDrawColor(45, 45, 55, 220)
				surface.DrawRect(0, 0, w, h)
				draw.SimpleText(item:GetName() .. (item:GetData("equip", false) and "  [в руках]" or ""),
					"ixSmallFont", 6, h / 2, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end

			for upgradeID, upgrade in pairs(ix.upgrade.list) do
				if (upgrade.appliesTo(item.class)) then
					local installed = item:GetData("upgrades", {})[upgradeID]

					local row = list:Add("DPanel")
					row:Dock(TOP)
					row:SetTall(42)
					row:DockMargin(12, 2, 0, 0)
					row.Paint = function(_, w, h)
						surface.SetDrawColor(30, 30, 36, 180)
						surface.DrawRect(0, 0, w, h)
						draw.SimpleText(upgrade.name .. "  —  смола: " .. upgrade.cost,
							"ixSmallFont", 6, 8, Color(255, 200, 120))
						draw.SimpleText(upgrade.desc, "ixSmallFont", 6, 24, Color(180, 180, 180))
					end

					local btn = row:Add("DButton")
					btn:Dock(RIGHT)
					btn:SetWide(110)
					btn:SetText(installed and "УСТАНОВЛЕНО" or "Установить")
					btn:SetEnabled(!installed)
					btn.DoClick = function()
						net.Start("ixBenchUpgrade")
							net.WriteEntity(self.bench)
							net.WriteUInt(item:GetID(), 32)
							net.WriteString(upgradeID)
						net.SendToServer()
						timer.Simple(0.5, function() if (IsValid(self)) then self:Remove() end end)
					end
				end
			end
		end
	end
end

function PANEL:BuildBio()
	local panel = self.sheet:Add("DPanel")
	panel:DockPadding(6, 6, 6, 6)
	self.sheet:AddSheet("Био-крафт", panel, "icon16/pill_add.png")

	local list = panel:Add("DScrollPanel")
	list:Dock(FILL)

	for _, recipe in ipairs(PLUGIN.BioRecipes) do
		local row = list:Add("DPanel")
		row:Dock(TOP)
		row:SetTall(46)
		row:DockMargin(0, 4, 0, 0)
		row.Paint = function(_, w, h)
			surface.SetDrawColor(36, 46, 34, 200)
			surface.DrawRect(0, 0, w, h)
			draw.SimpleText(recipe.name, "ixSmallFont", 6, 8, Color(160, 240, 140))

			local needs = {}
			for uid, amt in pairs(recipe.needs) do
				needs[#needs + 1] = uid .. " x" .. amt
			end
			draw.SimpleText(table.concat(needs, "  +  "), "ixSmallFont", 6, 26, Color(200, 200, 200))
		end

		local btn = row:Add("DButton")
		btn:Dock(RIGHT)
		btn:SetWide(110)
		btn:SetText("Создать")
		btn.DoClick = function()
			net.Start("ixBenchCraft")
				net.WriteEntity(self.bench)
				net.WriteString(recipe.id)
			net.SendToServer()
			timer.Simple(0.5, function() if (IsValid(self)) then self:Remove() end end)
		end
	end
end

function PANEL:Paint(w, h)
	ix.util.DrawBlur(self, 8)
	surface.SetDrawColor(20, 20, 24, 240)
	surface.DrawRect(0, 0, w, h)
end

vgui.Register("ixWorkbenchMenu", PANEL, "DFrame")

net.Receive("ixWorkbenchOpen", function()
	local bench = net.ReadEntity()
	if (IsValid(ix.gui.benchMenu)) then ix.gui.benchMenu:Remove() end
	ix.gui.benchMenu = vgui.Create("ixWorkbenchMenu")
	ix.gui.benchMenu.bench = bench
end)
