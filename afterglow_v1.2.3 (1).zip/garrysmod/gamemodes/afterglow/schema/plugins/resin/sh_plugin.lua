-- ============================================================
-- МОДУЛЬ 3: Смола и крафт. Улучшения оружия + био-крафт на верстаке.
-- Верстак — SENT ix_workbench (addons/hlarp), UI — derma/cl_workbench.lua.
-- ============================================================
PLUGIN.name = "Resin & Crafting"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Сбор смолы в КЗ, улучшение оружия и био-крафт на верстаках сопротивления."

local PLUGIN = PLUGIN  -- захват глобала: в колбэках hook.Add/net.Receive глобал PLUGIN после загрузки указывает на другой плагин/nil

if (CLIENT) then
	ix.util.Include("derma/cl_workbench.lua")
end

ix.config.Add("resinRespawnMin", 300, "Мин. время возрождения тайника смолы (сек).")
ix.config.Add("resinRespawnMax", 480, "Макс. время возрождения тайника смолы (сек).")
ix.config.Add("workbenchUseDist", 130, "Дистанция использования верстака.")

-- ------------------------------------------------------------
-- РЕЕСТР УЛУЧШЕНИЙ ОРУЖИЯ (shared)
-- appliesTo(weaponClass) → bool | cost = смола | apply(weapon) — сервер
-- ------------------------------------------------------------
ix.upgrade = ix.upgrade or {}
ix.upgrade.list = ix.upgrade.list or {}

function ix.upgrade.Register(id, data)
	data.id = id
	ix.upgrade.list[id] = data
end

ix.upgrade.Register("mag_plus", {
	name = "Расширенный магазин (+50%)",
	desc = "Самодельный усиленный корпус магазина.",
	cost = 4,
	appliesTo = function(w) return w == "weapon_smg1" or w == "weapon_pistol" or w == "weapon_ar2" end,
	apply = function(weapon)
		weapon.Primary.ClipSize = math.floor(weapon.ixBaseClipSize * 1.5 + 0.5)
	end
})

ix.upgrade.Register("laser", {
	name = "Лазерный целеуказатель",
	desc = "Спаенный указатель с АКБ. Тонкий луч, гордость штурмовика.",
	cost = 3,
	appliesTo = function() return true end,
	apply = function(weapon)
		weapon:SetNWBool("ixLaser", true)
	end
})

ix.upgrade.Register("stabilizer", {
	name = "Стабилизатор импульса",
	desc = "Снижает отдачу импульсных платформ (~25%).",
	cost = 5,
	appliesTo = function(w) return w == "weapon_ar2" or w == "weapon_smg1" end,
	apply = function(weapon)
		weapon.Primary.Recoil = (weapon.ixBaseRecoil or weapon.Primary.Recoil or 1) * 0.75
	end
})

-- Костыль-фикса: под свой оружейный пак (ARC9/TFA/M9K) добавляйте
-- свои улучшения здесь, через weapon:SetNW*/таблицы пака.

-- Применение всех установленных улучшений к реальному оружию
function ix.upgrade.ApplyToWeapon(client, weapon)
	if (!IsValid(client) or !IsValid(weapon) or !client:GetCharacter()) then return end

	-- зафиксировать базовые параметры один раз
	if (weapon.ixBaseClipSize == nil and weapon.Primary) then
		weapon.ixBaseClipSize = weapon.Primary.ClipSize
		weapon.ixBaseRecoil = weapon.Primary.Recoil
	end

	local inventory = client:GetCharacter():GetInventory()
	if (!inventory) then return end

	for _, item in pairs(inventory:GetItems()) do
		if (item.base == "weapons" and item.class == weapon:GetClass() and item:GetData("equip", false)) then
			for upgradeID, _ in pairs(item:GetData("upgrades", {})) do
				local upgrade = ix.upgrade.list[upgradeID]
				if (upgrade and upgrade.apply) then
					pcall(upgrade.apply, weapon)
				end
			end
		end
	end
end

-- Применяем улучшения при каждом взятии оружия в руки
function PLUGIN:PlayerSwitchWeapon(client, oldWeapon, weapon)
	if (SERVER) then
		timer.Simple(0, function()
			if (IsValid(client) and IsValid(weapon)) then
				ix.upgrade.ApplyToWeapon(client, weapon)
			end
		end)
	end
end

-- ------------------------------------------------------------
-- БИО-РЕЦЕПТЫ верстака
-- ------------------------------------------------------------
PLUGIN.BioRecipes = {
	{id = "antidote", name = "Антидот «Зен-А»", out = "antidote",
		needs = {headcrab_gland = 1, resin = 1},
		desc = "Железа ядовитого + смола → сыворотка от спор."},
	{id = "medgel", name = "Гелевый пластырь (x2)", out = "medgel", outAmount = 2,
		needs = {xen_tissue = 2, resin = 1},
		desc = "Биоткань Зена + смола → реактивный гель от плазменных ожогов."},
	{id = "filter", name = "Фильтр противогаза", out = "filter", data = {amount = 100},
		needs = {xen_tissue = 1, resin = 2},
		desc = "Мембрана из зен-ткани на угольной основе."}
}

-- ------------------------------------------------------------
-- ИНВЕНТАРНЫЕ УТИЛИТЫ (shared)
-- ------------------------------------------------------------
function ix.resinCount(inventory)
	local n = 0
	for _, item in pairs(inventory:GetItems()) do
		if (item.uniqueID == "resin") then n = n + item:GetData("amount", 1) end
	end
	return n
end

if (SERVER) then
	-- Снять N единиц смолы с инвентаря
	function ix.consumeResin(inventory, amount)
		if (ix.resinCount(inventory) < amount) then return false end
		local toRemove = amount
		for _, item in pairs(inventory:GetItems()) do
			if (toRemove <= 0) then break end
			if (item.uniqueID == "resin") then
				local have = item:GetData("amount", 1)
				if (have <= toRemove) then
					toRemove = toRemove - have
					item:Remove()
				else
					item:SetData("amount", have - toRemove)
					toRemove = 0
				end
			end
		end
		return true
	end

	function ix.consumeItems(inventory, uniqueID, amount)
		local left = amount
		for _, item in pairs(inventory:GetItems()) do
			if (left <= 0) then break end
			if (item.uniqueID == uniqueID) then
				local have = item:GetData("amount", 1)
				if (uniqueID == "resin" or have > 1) then
					if (have <= left) then left = left - have item:Remove()
					else item:SetData("amount", have - left) left = 0 end
				else
					item:Remove()
					left = left - 1
				end
			end
		end
		return left == 0
	end

	util.AddNetworkString("ixBenchUpgrade")
	util.AddNetworkString("ixBenchCraft")

	function PLUGIN:CanUseBench(client, bench)
		if (!IsValid(bench) or bench:GetClass() != "ix_workbench") then return false end
		if (client:GetPos():DistToSqr(bench:GetPos()) > ix.config.Get("workbenchUseDist", 130) ^ 2) then return false end
		local faction = client:GetCharacter() and client:GetCharacter():GetFaction()
		if (faction == FACTION_CP or faction == FACTION_OVERWATCH) then
			client:Notify("Едино: кустарная техника не для сотрудников Альянса. (FailRP)")
			return false
		end
		return true
	end

	net.Receive("ixBenchUpgrade", function(_, client)
		local bench = net.ReadEntity()
		local itemID = net.ReadUInt(32)
		local upgradeID = net.ReadString()

		if (!PLUGIN:CanUseBench(client, bench)) then return end

		local item = ix.item.instances[itemID]
		local character = client:GetCharacter()
		if (!item or !character or item.base != "weapons") then return end
		if (item:GetOwner() != client) then return end

		local upgrade = ix.upgrade.list[upgradeID]
		if (!upgrade or !upgrade.appliesTo(item.class)) then return end

		local upgrades = item:GetData("upgrades", {})
		if (upgrades[upgradeID]) then
			client:Notify("Улучшение уже установлено.")
			return
		end

		local inventory = character:GetInventory()
		if (!ix.consumeResin(inventory, upgrade.cost)) then
			client:Notify("Не хватает смолы (нужно " .. upgrade.cost .. ").")
			return
		end

		upgrades[upgradeID] = true
		item:SetData("upgrades", upgrades)
		client:Notify("Установлено: " .. upgrade.name .. ". Перевозьмите оружие в руки.")
		bench:EmitSound("items/ammo_pickup.wav")

		-- немедленное применение, если оружие уже в руках
		local weapon = client:GetActiveWeapon()
		if (IsValid(weapon) and weapon:GetClass() == item.class) then
			ix.upgrade.ApplyToWeapon(client, weapon)
		end
	end)

	net.Receive("ixBenchCraft", function(_, client)
		local bench = net.ReadEntity()
		local recipeID = net.ReadString()
		if (!PLUGIN:CanUseBench(client, bench)) then return end

		local recipe
		for _, r in ipairs(PLUGIN.BioRecipes) do
			if (r.id == recipeID) then recipe = r break end
		end
		if (!recipe) then return end

		local inventory = client:GetCharacter():GetInventory()
		-- проверка компонентов
		for uid, amt in pairs(recipe.needs) do
			if (uid == "resin") then
				if (ix.resinCount(inventory) < amt) then client:Notify("Не хватает смолы.") return end
			else
				local have = 0
				for _, it in pairs(inventory:GetItems()) do
					if (it.uniqueID == uid) then have = have + 1 end
				end
				if (have < amt) then client:Notify("Не хватает компонентов (" .. uid .. ").") return end
			end
		end

		for uid, amt in pairs(recipe.needs) do
			if (uid == "resin") then ix.consumeResin(inventory, amt)
			else ix.consumeItems(inventory, uid, amt) end
		end

		local ok = inventory:Add(recipe.out, recipe.outAmount or 1, recipe.data or {})
		if (ok) then
			client:Notify("Создано: " .. recipe.name .. ".")
			bench:EmitSound("ambient/machines/machine6.wav", 55)
		else
			client:Notify("Инвентарь переполнен.")
		end
	end)

	-- --------------------------------------------------------
	-- ТАЙНИКИ СМОЛЫ (точки + респавн)
	-- --------------------------------------------------------
	PLUGIN.ResinPoints = PLUGIN.ResinPoints or {}

	function PLUGIN:SaveResinPoints()
		local out = {}
		for _, p in ipairs(self.ResinPoints) do out[#out + 1] = {p.x, p.y, p.z} end
		ix.data.Set("resinPoints", out, false, false)
	end

	function PLUGIN:LoadResinPoints()
		self.ResinPoints = {}
		for _, v in ipairs(ix.data.Get("resinPoints", {}, false, false)) do
			table.insert(self.ResinPoints, {pos = Vector(v[1], v[2], v[3]), nextSpawn = 0})
		end
	end

	function PLUGIN:InitPostEntity()
		self:LoadResinPoints()
		self:LoadWorkbenches()
	end

	function PLUGIN:Tick()
		local now = CurTime()
		if ((self.nextResin or 0) > now) then return end
		self.nextResin = now + 5

		for _, p in ipairs(self.ResinPoints) do
			if (IsValid(p.entity)) then continue end
			if ((p.nextSpawn or 0) > now) then continue end

			ix.item.Spawn("resin", p.pos, function(item, entity)
				item:SetData("amount", math.random(1, 3))
				p.entity = entity
				hook.Add("EntityRemoved", entity, function()
					p.entity = nil
					p.nextSpawn = CurTime() + math.random(
						ix.config.Get("resinRespawnMin", 300),
						ix.config.Get("resinRespawnMax", 480)
					)
				end)
			end)
		end
	end
end

-- ------------------------------------------------------------
-- КЛИЕНТ: лазерный целеуказатель (улучшение)
-- ------------------------------------------------------------
if (CLIENT) then
	function PLUGIN:PostDrawOpaqueRenderables()
		for _, ply in player.Iterator() do
			local weapon = ply:GetActiveWeapon()
			if (IsValid(weapon) and weapon:GetNWBool("ixLaser", false)) then
				local att = weapon:LookupAttachment("muzzle")
				local from = (att > 0) and weapon:GetAttachment(att).Pos or ply:GetShootPos()

				local tr = util.TraceLine({
					start = from,
					endpos = from + ply:GetAimVector() * 4096,
					filter = {ply, weapon}
				})

				render.SetMaterial(Material("cable/redlaser"))
				render.DrawBeam(from, tr.HitPos, 1.5, 0, 1, Color(255, 0, 0))
				render.SetMaterial(Material("sprites/light_glow02_add"))
				render.DrawSprite(tr.HitPos, 8, 8, Color(255, 40, 40))
			end
		end
	end
end

-- ------------------------------------------------------------
-- АДМИН-КОМАНДЫ
-- ------------------------------------------------------------
ix.command.Add("ResinAdd", {
	description = "Добавить тайник смолы в текущей позиции.",
	adminOnly = true,
	OnRun = function(self, client)
		table.insert(PLUGIN.ResinPoints, {pos = client:GetPos(), nextSpawn = 0})
		PLUGIN:SaveResinPoints()
		client:Notify("Тайник смолы добавлен (" .. #PLUGIN.ResinPoints .. ").")
	end
})

ix.command.Add("ResinClear", {
	description = "Удалить ближайший тайник смолы (в радиусе 96).",
	adminOnly = true,
	OnRun = function(self, client)
		for i, p in ipairs(PLUGIN.ResinPoints) do
			if (p.pos:DistToSqr(client:GetPos()) < 96 * 96) then
				if (IsValid(p.entity)) then p.entity:Remove() end
				table.remove(PLUGIN.ResinPoints, i)
				PLUGIN:SaveResinPoints()
				client:Notify("Тайник удалён.")
				return
			end
		end
		client:Notify("Рядом тайников нет.")
	end
})

-- ------------------------------------------------------------
-- ВЕРСТАКИ: персистентные размещения
-- ------------------------------------------------------------
if (SERVER) then
	PLUGIN.Workbenches = PLUGIN.Workbenches or {}

	function PLUGIN:SaveWorkbenches()
		local out = {}
		for _, b in ipairs(self.Workbenches) do
			out[#out + 1] = {
				pos = {b.pos.x, b.pos.y, b.pos.z},
				ang = {b.ang.p, b.ang.y, b.ang.r}
			}
		end
		ix.data.Set("workbenches", out, false, false)
	end

	function PLUGIN:LoadWorkbenches()
		self.Workbenches = {}
		for _, b in ipairs(ix.data.Get("workbenches", {}, false, false)) do
			local data = {
				pos = Vector(b.pos[1], b.pos[2], b.pos[3]),
				ang = Angle(b.ang[1], b.ang[2], b.ang[3])
			}
			local ent = ents.Create("ix_workbench")
			if (IsValid(ent)) then
				ent:SetPos(data.pos)
				ent:SetAngles(data.ang)
				ent:Spawn()
				ent:GetPhysicsObject():EnableMotion(false)
				data.entity = ent
			end
			table.insert(self.Workbenches, data)
		end
	end
end

ix.command.Add("WorkbenchAdd", {
	description = "Разместить верстак сопротивления в точке прицела.",
	adminOnly = true,
	OnRun = function(self, client)
		local pos = client:GetEyeTraceNoCursor().HitPos
		local ent = ents.Create("ix_workbench")
		ent:SetPos(pos)
		ent:SetAngles(Angle(0, client:GetAngles().y + 180, 0))
		ent:Spawn()
		ent:GetPhysicsObject():EnableMotion(false)

		table.insert(PLUGIN.Workbenches, {pos = pos, ang = ent:GetAngles(), entity = ent})
		PLUGIN:SaveWorkbenches()
		client:Notify("Верстак размещён (" .. #PLUGIN.Workbenches .. ").")
	end
})

ix.command.Add("WorkbenchRemove", {
	description = "Удалить верстак, на который вы смотрите.",
	adminOnly = true,
	OnRun = function(self, client)
		local tr = client:GetEyeTraceNoCursor()
		if (!IsValid(tr.Entity) or tr.Entity:GetClass() != "ix_workbench") then
			client:Notify("Цельтесь в верстак.")
			return
		end
		for i, b in ipairs(PLUGIN.Workbenches) do
			if (b.entity == tr.Entity) then table.remove(PLUGIN.Workbenches, i) break end
		end
		tr.Entity:Remove()
		PLUGIN:SaveWorkbenches()
		client:Notify("Верстак удалён.")
	end
})
