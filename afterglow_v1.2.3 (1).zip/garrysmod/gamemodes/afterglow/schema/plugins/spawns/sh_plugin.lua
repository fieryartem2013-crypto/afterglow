-- ============================================================
-- Спавн-точки фракций (по команде, сохраняются на карту).
-- ============================================================
PLUGIN.name = "Faction Spawns"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Точки спавна фракций: /SpawnAdd, /SpawnRemove, /SpawnList."

PLUGIN.Spawns = PLUGIN.Spawns or {} -- [factionIndex] = { {pos, ang}, ... }

function PLUGIN:SaveSpawns()
	local out = {}
	for f, points in pairs(self.Spawns) do
		out[f] = {}
		for _, p in ipairs(points) do
			out[f][#out[f] + 1] = {
				pos = {p.pos.x, p.pos.y, p.pos.z},
				ang = {p.ang.p, p.ang.y, p.ang.r}
			}
		end
	end
	ix.data.Set("factionSpawns", out, false, false)
end

function PLUGIN:LoadSpawns()
	self.Spawns = {}
	local data = ix.data.Get("factionSpawns", {}, false, false)
	for f, points in pairs(data) do
		f = tonumber(f)
		self.Spawns[f] = {}
		for _, p in ipairs(points) do
			table.insert(self.Spawns[f], {
				pos = Vector(p.pos[1], p.pos[2], p.pos[3]),
				ang = Angle(p.ang[1], p.ang[2], p.ang[3])
			})
		end
	end
end

function PLUGIN:InitPostEntity()
	self:LoadSpawns()
end

function PLUGIN:PlayerSpawn(client)
	local ch = client:GetCharacter()
	if (!ch) then return end

	local points = self.Spawns[ch:GetFaction()]
	if (points and #points > 0) then
		local p = points[math.random(1, #points)]
		timer.Simple(0.15, function()
			if (IsValid(client)) then
				client:SetPos(p.pos)
				client:SetEyeAngles(p.ang)
			end
		end)
	end
end

local function FindFaction(name)
	name = string.lower(name)
	for _, faction in ipairs(ix.faction.teams) do
		if (string.find(string.lower(faction.name), name, 1, true)) then
			return faction
		end
	end
end

ix.command.Add("SpawnAdd", {
	description = "Добавить спавн-точку фракции: /SpawnAdd <фракция>",
	adminOnly = true,
	arguments = {ix.type.string},
	OnRun = function(self, client, factionName)
		local faction = FindFaction(factionName)
		if (!faction) then
			client:Notify("Фракция не найдена. Доступны: citizen, оборона, ова, сопротивление, администрация")
			return
		end
		PLUGIN.Spawns[faction.index] = PLUGIN.Spawns[faction.index] or {}
		table.insert(PLUGIN.Spawns[faction.index], {pos = client:GetPos(), ang = client:GetAngles()})
		PLUGIN:SaveSpawns()
		client:Notify("Спавн фракции '" .. faction.name .. "' добавлен (" .. #PLUGIN.Spawns[faction.index] .. ").")
	end
})

ix.command.Add("SpawnRemove", {
	description = "Удалить ближайшую спавн-точку фракции (радиус 96).",
	adminOnly = true,
	arguments = {ix.type.string},
	OnRun = function(self, client, factionName)
		local faction = FindFaction(factionName)
		if (!faction or !PLUGIN.Spawns[faction.index]) then
			client:Notify("Не найдено.")
			return
		end
		for i, p in ipairs(PLUGIN.Spawns[faction.index]) do
			if (p.pos:DistToSqr(client:GetPos()) < 96 * 96) then
				table.remove(PLUGIN.Spawns[faction.index], i)
				PLUGIN:SaveSpawns()
				client:Notify("Точка удалена.")
				return
			end
		end
		client:Notify("Рядом точек нет.")
	end
})

ix.command.Add("SpawnList", {
	description = "Список количества спавн-точек по фракциям.",
	adminOnly = true,
	OnRun = function(self, client)
		for f, points in pairs(PLUGIN.Spawns) do
			local faction = ix.faction.indices[f]
			client:ChatPrint(("[СПАВН] %s: %d"):format(faction and faction.name or "?", #points))
		end
	end
})
