-- ============================================================
-- AFTERGLOW UNIFIED MENU (ag_menu)
-- Реворк единого TAB/F1 меню Helix: перехват ixMenu-флоу,
-- собственный каркас AGMenu + система вкладок ix.ag.RegisterMenuTab.
-- Также содержит модуль выносливости (stamina), т.к. она
-- отображается во вкладке «Персонаж».
-- ============================================================
PLUGIN.name = "AfterGlow Menu"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Единое TAB/F1 меню AfterGlow: персонаж, инвентарь, игроки, настройки."

if (CLIENT) then
	ix.util.IncludeDir(PLUGIN.folder .. "/derma")
end

ix.config.Add("agStaminaDrain", 18, "Единиц стамины в секунду тратится на бег.")
ix.config.Add("agStaminaRegen", 14, "Единиц стамины в секунду восстанавливается.")
ix.config.Add("agStaminaRegenDelay", 1.6, "Пауза перед восстановлением после бега (сек).")

-- ------------------------------------------------------------
-- РЕЕСТР ВКЛАДОК (client): другие плагины регистрируют свои
-- ------------------------------------------------------------
if (CLIENT) then
	ix.ag.menuTabs = ix.ag.menuTabs or {}

	-- id уникален; build(menu, parent) → panel; visible() → bool
	function ix.ag.RegisterMenuTab(def)
		for i, tab in ipairs(ix.ag.menuTabs) do
			if (tab.id == def.id) then ix.ag.menuTabs[i] = def return end
		end
		ix.ag.menuTabs[#ix.ag.menuTabs + 1] = def
	end
end

-- ------------------------------------------------------------
-- STAMINA (server → netvar → bar во вкладке «Персонаж»)
-- ------------------------------------------------------------
if (SERVER) then
	function PLUGIN:PlayerLoadedCharacter(client, character)
		client:SetNetVar("stamina", 100)
	end

	function PLUGIN:Tick()
		local now = CurTime()
		if ((self.nextStamina or 0) > now) then return end
		self.nextStamina = now + 0.25

		local dt = 0.25
		for _, client in player.Iterator() do
			if (!client:Alive() or !client:GetCharacter()) then continue end
			if (client:GetMoveType() == MOVETYPE_NOCLIP) then continue end

			local st = client:GetNetVar("stamina", 100)
			local vel = client:GetVelocity():Length2DSqr()
			local running = client:KeyDown(IN_SPEED) and vel > (ix.config.Get("walkSpeed", 90) * 1.1) ^ 2

			if (running) then
				st = math.max(0, st - ix.config.Get("agStaminaDrain", 18) * dt)
				client.nextStaminaRegen = now + ix.config.Get("agStaminaRegenDelay", 1.6)
			elseif ((client.nextStaminaRegen or 0) <= now) then
				st = math.min(100, st + ix.config.Get("agStaminaRegen", 14) * dt)
			end

			if (st ~= client:GetNetVar("stamina", 100)) then
				client:SetNetVar("stamina", st)
			end
		end
	end
end

-- ------------------------------------------------------------
-- ПЕРЕХВАТ СТАНДАРТНОГО МЕНЮ (TAB = ScoreboardShow, F1 = ShowHelp)
-- Наивысший приоритет: возвращаем true → стандартный ixMenu не создаётся.
-- ------------------------------------------------------------
if (CLIENT) then
	function ix.ag.OpenMenu(tabID)
		if (IsValid(ix.gui.agMenu)) then return end
		ix.gui.agMenu = vgui.Create("AGMenu")
		if (tabID) then ix.gui.agMenu:SelectTab(tabID) end
		gui.EnableScreenClicker(true)
	end

	function ix.ag.CloseMenu()
		if (IsValid(ix.gui.agMenu)) then
			ix.gui.agMenu:Remove()
			ix.gui.agMenu = nil
		end
		ix.ag.HideTooltip()
		gui.EnableScreenClicker(false)
	end

	local function ToggleMenu()
		if (!LocalPlayer():GetCharacter()) then return false end -- без персонажа — штатно
		if (IsValid(ix.gui.agMenu)) then ix.ag.CloseMenu()
		else ix.ag.OpenMenu() end
		return true
	end

	function PLUGIN:ScoreboardShow()
		return ToggleMenu()
	end

	function PLUGIN:ShowHelp()
		return ToggleMenu()
	end

	-- клик не должен застрять, когда игрок погиб/сменил персонажа
	function PLUGIN:Think()
		if (IsValid(ix.gui.agMenu)) then
			local ply = LocalPlayer()
			if (!ply:Alive() or !ply:GetCharacter()) then
				ix.ag.CloseMenu()
			end
		end
	end
end
