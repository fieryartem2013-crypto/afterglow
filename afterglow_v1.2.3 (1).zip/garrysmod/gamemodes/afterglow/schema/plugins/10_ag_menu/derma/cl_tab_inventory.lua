-- Вкладка «Инвентарь & Экипировка»:
-- нативная Helix-сетка (drag&drop) + слоты быстрого доступа + инфо-карта предмета
local PANEL = {}

-- слоты экипировки: name + matcher(item)
local EQUIP_SLOTS = {
	{name = "ОРУЖИЕ", match = function(item) return item.base == "weapons" and item:GetData("equip", false) end},
	{name = "ПРОТИВОГАЗ", match = function(item) return item.uniqueID == "gasmask" and item:GetData("equipped", false) end},
	{name = "ПЕРЧАТКИ", match = function(item) return item.uniqueID == "gravgloves_item" end},
	{name = "РАЦИЯ", match = function(item) return item.uniqueID == "radio" end}
}

local function InventoryAction(action, itemID, invID, data)
	net.Start("ixInventoryAction")
		net.WriteString(action)
		net.WriteUInt(itemID, 32)
		net.WriteUInt(invID, 32)
		net.WriteTable(data or {})
	net.SendToServer()
end

local UNEQUIP_KEYS = {"EquipUn", "unwear", "unload", "use", "inject", "apply", "heal", "drink", "open"}

local function FirstFunctionKey(item, keys)
	for _, k in ipairs(keys) do
		if (item.functions and item.functions[k]) then return k end
	end
end

function PANEL:Init()
	-- построение откладываем до первого PerformLayout (реальные размеры)
end

function PANEL:PerformLayout(w, h)
	if (self.built or w < 50 or h < 50) then return end
	self.built = true
	self:Build(w, h)
end

function PANEL:Build(w, h)
	local ply = LocalPlayer()
	local char = ply:GetCharacter()
	if (!char) then return end
	local inventory = char:GetInventory()
	if (!inventory) then return end

	-- ============== СЛОТЫ ЭКИПИРОВКИ ==============
	local eqWrap = self:Add("AGPanel")
	eqWrap:Dock(TOP)
	eqWrap:DockMargin(0, 0, 0, 8)
	eqWrap:SetTall(96)
	eqWrap:SetEdgeColor(ix.ag.C.combine)

	local lbl = eqWrap:Add("DLabel")
	lbl:SetText("БЫСТРЫЙ ДОСТУП // ЭКИПИРОВКА  (ЛКМ — снять/применить • ПКМ — все действия)")
	lbl:SetFont("AG.Tiny")
	lbl:SetTextColor(ix.ag.C.textDim)
	lbl:SizeToContents()
	lbl:SetPos(8, 4)

	local sx = 8
	for _, slot in ipairs(EQUIP_SLOTS) do
		local found
		for _, item in pairs(inventory:GetItems()) do
			if (slot.match(item)) then found = item break end
		end

		local card = eqWrap:Add("Panel")
		card:SetPos(sx, 22)
		card:SetSize(170, 68)
		card.item = found
		card.slotName = slot.name
		card.Paint = function(c, cw, ch)
			local hovered = c:IsHovered() and c.item
			surface.SetDrawColor(6, 9, 13, 230)
			surface.DrawRect(0, 0, cw, ch)
			local col = c.item and (hovered and ix.ag.C.neonSoft or ix.ag.C.neon) or ix.ag.C.stroke
			surface.SetDrawColor(col)
			surface.DrawOutlinedRect(0, 0, cw, ch, 1)
			draw.SimpleText(c.slotName, "AG.Tiny", 6, 4, ix.ag.C.textMute)
			if (c.item) then
				draw.SimpleText(c.item:GetName(), "AG.Tiny", 46, 22, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, 118)
			else
				draw.SimpleText("— пусто —", "AG.Small", cw / 2, ch / 2 + 8, ix.ag.C.textMute, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			end
		end

		if (card.item) then
			local icon = card:Add("SpawnIcon")
			icon:SetPos(6, 20)
			icon:SetSize(36, 36)
			icon:SetModel(card.item:GetModel())
			icon:SetToolTip(false)
			icon:SetMouseInputEnabled(false)

			local btn = card:Add("DButton")
			btn:SetText("")
			btn:Dock(FILL)
			btn.Paint = function() end
			btn.item = card.item
			btn.DoClick = function()
				ix.ag.Click()
				local key = FirstFunctionKey(btn.item, UNEQUIP_KEYS)
				if (key) then
					InventoryAction(key, btn.item:GetID(), inventory:GetID(), {})
				end
			end
			btn.DoRightClick = function()
				ix.ag.Click()
				local menu = DermaMenu()
				for k, _ in pairs(btn.item.functions or {}) do
					menu:AddOption(k, function()
						InventoryAction(k, btn.item:GetID(), inventory:GetID(), {})
					end)
				end
				menu:Open()
			end
		end

		sx = sx + 178
	end

	-- ============== НИЖНЯЯ ЧАСТЬ: СЕТКА + БРАУЗЕР ==============
	local split = self:Add("Panel")
	split:Dock(FILL)

	local invPanel = split:Add("ixInventory")
	invPanel:Dock(LEFT)
	invPanel:SetWide(math.max(w * 0.6, 420))
	invPanel:DockMargin(0, 0, 0, 0)
	invPanel:SetDraggable(false)
	invPanel:SetSizable(false)
	invPanel:SetTitle("")
	invPanel:SetShowCloseButton(false)
	invPanel.bNoBackgroundBlur = true
	invPanel.childPanels = {}
	invPanel:SetInventory(inventory)
	ix.gui.inv1 = invPanel

	local browser = split:Add("AGPanel")
	browser:Dock(FILL)
	browser:DockMargin(10, 0, 0, 0)
	browser:SetEdgeColor(ix.ag.C.violet)
	browser.PaintOver = function(_, bw, bh)
		draw.SimpleText("СОДЕРЖИМОЕ // НАВЕДИТЕ ДЛЯ АНАЛИЗА", "AG.Tiny", 8, 6, ix.ag.C.textDim)
	end

	local list = browser:Add("AGScrollPanel")
	list:Dock(FILL)
	list:DockMargin(6, 24, 6, 6)

	local items = {}
	for _, item in pairs(inventory:GetItems()) do items[#items + 1] = item end
	table.sort(items, function(a, b) return a:GetName() < b:GetName() end)

	for _, item in ipairs(items) do
		local row = vgui.Create("DButton")
		row:SetText("")
		row:SetTall(34)
		row:Dock(TOP)
		row:DockMargin(0, 0, 4, 2)
		row.item = item
		row.Paint = function(r, rw, rh)
			local col = r:IsHovered() and ix.ag.C.violet or ix.ag.C.stroke
			surface.SetDrawColor(255, 255, 255, r:IsHovered() and 14 or 5)
			surface.DrawRect(0, 0, rw, rh)
			surface.SetDrawColor(col)
			surface.DrawRect(0, 0, 3, rh)
			draw.SimpleText(r.item:GetName(), "AG.SmallB", 10, rh / 2, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText((r.item.width or 1) .. "×" .. (r.item.height or 1), "AG.Tiny", rw - 8, rh / 2, ix.ag.C.textMute, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		row.DoClick = function() ix.ag.Click() end
		row.OnCursorEntered = function(r)
			local tip = ix.ag.ShowTooltip(r.item:GetName(), ix.ag.C.violet)
			tip:AddText(r.item:GetDescription())
			tip:AddRow("Слот", (r.item.width or 1) .. "×" .. (r.item.height or 1))
			tip:AddRow("Категория", r.item.category or "—")
			if (r.item.price and r.item.price > 0) then tip:AddRow("Ценность", r.item.price .. " ☼") end

			local filterV = r.item.GetData and (r.item:GetData("filter") or r.item:GetData("amount"))
			if (filterV) then tip:AddRow("ЗАРЯД ФИЛЬТРА", math.floor(filterV) .. "%", ix.ag.C.green) end
			local amount = r.item.GetData and r.item:GetData("amount")
			if (amount and amount > 1) then tip:AddRow("Количество", amount, ix.ag.C.amber) end
			ix.ag.PlaceTooltip(tip)
		end
		row.OnCursorExited = function() ix.ag.HideTooltip() end
		list:AddItem(row)
		row:Dock(TOP)
	end
end

vgui.Register("AGTabInventory", PANEL, "Panel")

ix.ag.RegisterMenuTab({
	id = "inventory",
	name = "ИНВЕНТАРЬ",
	icon = "icon16/bricks.png",
	order = 2,
	build = function(menu, parent)
		local pnl = parent:Add("AGTabInventory")
		pnl:Dock(FILL)
		return pnl
	end
})
