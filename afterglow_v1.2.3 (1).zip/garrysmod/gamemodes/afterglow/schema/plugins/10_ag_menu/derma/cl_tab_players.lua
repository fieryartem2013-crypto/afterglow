-- Вкладка «Игроки»: статистика сервера + список по фракциям + контекстные действия
local PANEL = {}

-- фракции, скрытые от обычных игроков в списке (uniqueID)
PANEL.HIDDEN_FACTIONS = {}

function PANEL:Init() end

function PANEL:PerformLayout(w, h)
	if (self.built or w < 50 or h < 50) then return end
	self.built = true
	self:Build(w, h)
end

local function StatCard(parent, label, value, x, w)
	local card = parent:Add("Panel")
	card:SetPos(x, 0)
	card:SetSize(w, 56)
	card.value = value
	card.label = label
	card.Paint = function(c, cw, ch)
		surface.SetDrawColor(10, 14, 19, 235)
		surface.DrawRect(0, 0, cw, ch)
		ix.ag.DrawNeonEdge(0, 0, cw, ix.ag.C.neon, 90)
		surface.SetDrawColor(ix.ag.C.stroke)
		surface.DrawOutlinedRect(0, 0, cw, ch, 1)
		draw.SimpleText(c.label, "AG.Tiny", 10, 8, ix.ag.C.textMute)
		draw.SimpleText(tostring(c.value), "AG.MediumB", 10, 26, ix.ag.C.neon)
	end
	return card
end

function PANEL:Build(w, h)
	local ply = LocalPlayer()
	local isStaff = ply.IsAGStaff and ply:IsAGStaff()

	-- ============ СТАТИСТИКА СЕРВЕРА ============
	local stats = self:Add("Panel")
	stats:Dock(TOP)
	stats:SetTall(64)

	local cw = (w - 50) / 6
	StatCard(stats, "КАРТА", game.GetMap(), 0, cw)
	StatCard(stats, "ОНЛАЙН", #player.GetAll() .. "/" .. game.MaxPlayers(), cw + 10, cw)
	StatCard(stats, "МОЙ ПИНГ", ply:Ping() .. "ms", cw * 2 + 20, cw)
	StatCard(stats, "АПТАЙМ", ix.ag.FormatTime(CurTime()), cw * 3 + 30, cw)

	local staffCount, staffNames = 0, {}
	for _, p in player.Iterator() do
		local g = p.AGGroup and p:AGGroup() or "user"
		if (g ~= "user" and ix.ag.GROUPS and ix.ag.GROUPS[g] and ix.ag.GROUPS[g].staff) then
			staffCount = staffCount + 1
			if (#staffNames < 3) then staffNames[#staffNames + 1] = p:Nick() end
		end
	end
	StatCard(stats, "СТАФФ ОНЛАЙН", staffCount, cw * 4 + 40, cw)
	StatCard(stats, "СБОРКА", "AfterGlow v1.2.3", cw * 5 + 50, cw)

	if (staffCount > 0) then
		local hint = stats:Add("DLabel")
		hint:SetPos(cw * 4 + 40, 42)
		hint:SetText(table.concat(staffNames, ", ") .. (staffCount > 3 and "…" or ""))
		hint:SetFont("AG.Tiny")
		hint:SetTextColor(ix.ag.C.textDim)
		hint:SizeToContents()
	end

	-- ============ СПИСОК ============
	local list = self:Add("AGScrollPanel")
	list:Dock(FILL)
	list:DockMargin(0, 8, 0, 0)
	self.list = list
	self:RebuildList(isStaff)
end

function PANEL:RebuildList(isStaff)
	local list = self.list
	if (!IsValid(list)) then return end
	list:Clear()

	if (isStaff == nil) then
		local ply = LocalPlayer()
		isStaff = ply.IsAGStaff and ply:IsAGStaff()
	end

	local dw = self:GetWide() - 10

	local byFaction = {}
	for _, p in player.Iterator() do
		local ch = p:GetCharacter()
		local f = ch and ch:GetFaction() or 0
		byFaction[f] = byFaction[f] or {}
		byFaction[f][#byFaction[f] + 1] = p
	end

	local factions = {}
	for fIndex, players_ in pairs(byFaction) do
		local faction = ix.faction.indices[fIndex]
		local hidden = faction and (self.HIDDEN_FACTIONS[fIndex] or self.HIDDEN_FACTIONS[faction.uniqueID])
		if (faction and !hidden) or (hidden and isStaff) then
			if (faction) then
				factions[#factions + 1] = {faction = faction, players = players_}
			end
		end
	end
	table.sort(factions, function(a, b) return a.faction.index < b.faction.index end)

	for _, data in ipairs(factions) do
		local header = vgui.Create("Panel")
		header:Dock(TOP)
		header:DockMargin(0, 0, 4, 2)
		header:SetTall(30)
		header.faction = data.faction
		header.count = #data.players
		header.Paint = function(h2, hw, hh)
			local f = h2.faction
			surface.SetDrawColor(f.color.r, f.color.g, f.color.b, 26)
			surface.DrawRect(0, 0, hw, hh)
			surface.SetDrawColor(f.color)
			surface.DrawRect(0, 0, 4, hh)
			draw.SimpleText(f.name:upper(), "AG.SmallB", 12, hh / 2, f.color, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText(h2.count .. " чел.", "AG.Tiny", hw - 8, hh / 2, ix.ag.C.textDim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		list:AddItem(header)

		table.sort(data.players, function(a, b) return a:Nick() < b:Nick() end)
		for _, p in ipairs(data.players) do
			local row = self:CreatePlayerRow(p)
			list:AddItem(row)
		end

		local spacer = vgui.Create("Panel")
		spacer:Dock(TOP)
		spacer:SetTall(8)
		list:AddItem(spacer)
	end
end

function PANEL:CreatePlayerRow(p)
	local ch = p:GetCharacter()
	local class = ch and ix.class.list[ch:GetClass()]
	local group = p.AGGroup and p:AGGroup() or "user"
	local gData = ix.ag.GROUPS and ix.ag.GROUPS[group]
	local prefix = (gData and gData.prefix ~= "") and ("[" .. gData.prefix .. "]") or nil

	local row = vgui.Create("DButton")
	row:SetText("")
	row:Dock(TOP)
	row:DockMargin(0, 0, 4, 1)
	row:SetTall(30)
	row.player = p
	row.prefix = prefix
	row.nameColor = prefix and gData.color or ix.ag.C.text
	row.Paint = function(r, rw, rh)
		if (!IsValid(r.player)) then
			draw.SimpleText("[отключился]", "AG.Small", 8, rh / 2, ix.ag.C.textMute, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			return
		end
		local hovered = r:IsHovered()
		surface.SetDrawColor(255, 255, 255, hovered and 14 or 5)
		surface.DrawRect(0, 0, rw, rh)

		surface.SetFont("AG.SmallB")
		local x = 8
		if (r.prefix) then
			draw.SimpleText(r.prefix, "AG.SmallB", x, rh / 2, r.nameColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			x = x + surface.GetTextSize(r.prefix) + 8
		end
		local ch2 = r.player:GetCharacter()
		draw.SimpleText(ch2 and ch2:GetName() or r.player:Nick(), "AG.Small", x, rh / 2, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText(class and class.name or "", "AG.Tiny", rw - 70, rh / 2, ix.ag.C.textDim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		draw.SimpleText(r.player:Ping() .. "ms", "AG.Tiny", rw - 8, rh / 2, ix.ag.C.textMute, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
	end
	row.DoClick = function()
		if (IsValid(p)) then
			ix.ag.Click()
			self:OpenContextMenu(p)
		end
	end
	return row
end

-- контекстное меню по игроку
function PANEL:OpenContextMenu(target)
	if (!IsValid(target) or target == LocalPlayer()) then return end

	local ch = target:GetCharacter()
	local ply = LocalPlayer()

	local entries = {}
	local function AddEntry(label, icon, col, func)
		entries[#entries + 1] = {label = label, icon = icon, col = col, func = func}
	end

	AddEntry("Скопировать SteamID", "icon16/page_copy.png", nil, function()
		SetClipboardText(target:SteamID())
		ply:Notify("SteamID скопирован: " .. target:SteamID())
	end)
	AddEntry("Открыть профиль", "icon16/world_link.png", nil, function()
		gui.OpenURL("https://steamcommunity.com/profiles/" .. target:SteamID64())
	end)
	AddEntry("Личное сообщение", "icon16/email.png", nil, function()
		ix.ag.CloseMenu()
		ix.ag.Prompt("ЛС → " .. target:Nick(), "", function(text)
			if (text ~= "") then
				LocalPlayer():ConCommand("say /pm \"" .. target:Nick() .. "\" " .. text)
			end
		end)
	end)
	AddEntry("Пожаловаться", "icon16/report.png", ix.ag.C.amber, function()
		ix.ag.CloseMenu()
		ix.ag.Prompt("ЖАЛОБА НА: " .. target:Nick(), "", function(text)
			if (text ~= "") then
				net.Start("agTicket")
					net.WriteUInt(0, 4)
					net.WriteString(text)
					net.WriteEntity(target)
				net.SendToServer()
			end
		end)
	end)

	if (ply.AGHasPerm) then
		local adminActs = {
			{"spectate", "Наблюдать", "icon16/eye.png", function() RunConsoleCommand("say", "/agspectate \"" .. target:Nick() .. "\"") end},
			{"goto", "ТП к игроку", "icon16/arrow_right.png", function() RunConsoleCommand("say", "/aggoto \"" .. target:Nick() .. "\"") end},
			{"bring", "ТП к себе", "icon16/arrow_left.png", function() RunConsoleCommand("say", "/agbring \"" .. target:Nick() .. "\"") end},
			{"freeze", "Заморозить / разморозить", "icon16/lock.png", function() RunConsoleCommand("say", "/agfreeze \"" .. target:Nick() .. "\"") end},
			{"warn", "Выдать варн", "icon16/error.png", function()
				ix.ag.Prompt("ВАРН: причина", "", function(text)
					if (text ~= "") then RunConsoleCommand("say", "/agwarn \"" .. target:Nick() .. "\" " .. text) end
				end)
			end},
			{"kick", "Кикнуть", "icon16/door_out.png", function()
				ix.ag.Prompt("КИК: причина", "", function(text)
					RunConsoleCommand("say", "/agkick \"" .. target:Nick() .. "\" " .. (text ~= "" and text or "не указана"))
				end)
			end},
			{"ban", "Забанить", "icon16/cancel.png", function()
				ix.ag.Prompt("БАН: минуты затем причина (пример: 60 RDM)", "", function(text)
					if (text ~= "") then RunConsoleCommand("say", "/agban \"" .. target:Nick() .. "\" " .. text) end
				end)
			end},
			{"setname", "Сменить имя", "icon16/font.png", function()
				ix.ag.Prompt("НОВОЕ ИМЯ ПЕРСОНАЖА", ch and ch:GetName() or "", function(text)
					if (text ~= "") then RunConsoleCommand("say", "/agsetname \"" .. target:Nick() .. "\" " .. text) end
				end)
			end},
			{"setfaction", "Сменить фракцию", "icon16/group_gear.png", function()
				ix.ag.Prompt("ФРАКЦИЯ (citizen/cp/overwatch/resistance/administration)", "citizen", function(text)
					if (text ~= "") then RunConsoleCommand("say", "/agsetfaction \"" .. target:Nick() .. "\" " .. text) end
				end)
			end}
		}
		for _, act in ipairs(adminActs) do
			if (ply:AGHasPerm(act[1])) then
				AddEntry(act[2], act[3], ix.ag.C.combine, act[4])
			end
		end
	end

	-- панель меню
	local mh = 38 + #entries * 27 + 10
	local menuPanel = vgui.Create("AGPanel")
	menuPanel:SetSize(250, mh)
	menuPanel:SetDrawOnTop(true)
	local cx, cy = input.GetCursorPos()
	if (cx + 250 > ScrW()) then cx = ScrW() - 262 end
	if (cy + mh > ScrH()) then cy = ScrH() - mh - 12 end
	menuPanel:SetPos(cx, cy)
	menuPanel:MakePopup()
	menuPanel:SetKeyboardInputEnabled(false)

	local titleL = menuPanel:Add("DLabel")
	titleL:SetText(ch and ch:GetName() or target:Nick())
	titleL:SetFont("AG.SmallB")
	titleL:SetTextColor(ix.ag.C.text)
	titleL:SizeToContents()
	titleL:SetPos(10, 6)
	local sid = menuPanel:Add("DLabel")
	sid:SetText(target:SteamID())
	sid:SetFont("AG.Tiny")
	sid:SetTextColor(ix.ag.C.textMute)
	sid:SizeToContents()
	sid:SetPos(10, 22)

	local ey = 40
	for _, e in ipairs(entries) do
		local b = menuPanel:Add("AGButton")
		b:SetText(e.label)
		b:SetVariant("ghost")
		b:SetSize(230, 25)
		b:SetPos(10, ey)
		if (e.icon) then b:SetIcon(Material(e.icon)) end
		if (e.col and not e.icon) then b:SetVariant("primary") end
		b.PaintOver = function(btn, bw, bh)
			if (btn:IsHovered() and e.col) then
				surface.SetDrawColor(e.col.r, e.col.g, e.col.b, 30)
				surface.DrawRect(0, 0, bw, bh)
			end
		end
		b.DoClick = function()
			ix.ag.Click()
			menuPanel:Remove()
			e.func()
		end
		ey = ey + 27
	end

	menuPanel.Think = function(mp)
		if (input.IsMouseDown(MOUSE_LEFT)) then
			local mx, my = gui.MouseX(), gui.MouseY()
			local px, py = mp:GetPos()
			if (mx < px - 40 or mx > px + mp:GetWide() + 40 or my < py - 40 or my > py + mp:GetTall() + 40) then
				mp:Remove()
			end
		end
	end
end

vgui.Register("AGTabPlayers", PANEL, "Panel")

ix.ag.RegisterMenuTab({
	id = "players",
	name = "ИГРОКИ",
	icon = "icon16/group.png",
	order = 3,
	build = function(menu, parent)
		local pnl = parent:Add("AGTabPlayers")
		pnl:Dock(FILL)
		return pnl
	end
})
