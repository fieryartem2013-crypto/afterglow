-- Вкладка «Настройки & Правила»: опции Helix (auto-render) + правила/лор
local PANEL = {}

PANEL.RULES = {
	{title = "§1. ОБЩИЕ ПРАВИЛА", color = ix.ag.C.neon, lines = {
		"1.1. Уважение к игрокам и отыгрышу. Без оскорблений в OOC.",
		"1.2. Metagaming и Powergaming запрещены.",
		"1.3. RDM/VDM запрещены. Бой — только с RP-предысторией.",
		"1.4. FearRP обязателен: угроза жизни — это угроза жизни."
	}},
	{title = "§2. КАРАНТИННАЯ ЗОНА", color = ix.ag.C.green, lines = {
		"2.1. Без противогаза/фильтра находиться в КЗ — суицидальный FearRP.",
		"2.2. Фауна Зена смертельно опасна. Стаи убивают одиночек.",
		"2.3. Контрабанда смолы карается конфискацией + арест (IC)."
	}},
	{title = "§3. АЛЬЯНС И ГРАЖДАНЕ", color = ix.ag.C.combine, lines = {
		"3.1. Приказы ГО/ОВА выполняются, если они не идиотичны.",
		"3.2. Проверка CID при КПП — не увиливать.",
		"3.3. Оружие в руках гражданского — повод для задержания."
	}},
	{title = "§4. СОПРОТИВЛЕНИЕ", color = ix.ag.C.amber, lines = {
		"4.1. Ячейка — это доверие. Слив — вечный бан фракции.",
		"4.2. Диверсии только с ведома старшего ячейки.",
		"4.3. Вортигонты — равноправные игроки: не выдавайте себя мелочью."
	}},
	{title = "ЛОР // CITY-17 PRECURSOR", color = ix.ag.C.violet, lines = {
		"Цитадель ещё строится. Альянс консолидирует Землю после",
		"Семичасовой войны. Город 17 латан ранними силовыми полями,",
		"а Карантинная Зона доедает старые блоки. Сопротивление —",
		"уже не слухи, но ещё не сеть. Всё, что будет потом,",
		"— напишем вместе."
	}}
}

function PANEL:Init() end

function PANEL:PerformLayout(w, h)
	if (self.built or w < 50 or h < 50) then return end
	self.built = true
	self:Build(w, h)
end

function PANEL:Build(w, h)
	-- ====== ЛЕВАЯ КОЛОНКА: НАСТРОЙКИ ======
	local optsPanel = self:Add("AGPanel")
	optsPanel:SetPos(0, 0)
	optsPanel:SetSize(w * 0.46, h)

	local title = optsPanel:Add("DLabel")
	title:SetText("НАСТРОЙКИ ИНТЕРФЕЙСА & ИГРЫ")
	title:SetFont("AG.SmallB")
	title:SetTextColor(ix.ag.C.textDim)
	title:SizeToContents()
	title:SetPos(10, 8)

	local scroll = optsPanel:Add("AGScrollPanel")
	scroll:SetPos(6, 30)
	scroll:SetSize(w * 0.46 - 12, h - 40)

	local catColors = {
		["AfterGlow UI"] = ix.ag.C.neon,
		["AfterGlow Admin"] = ix.ag.C.violet,
		["interface"] = ix.ag.C.combine,
		["misc"] = ix.ag.C.amber,
		["general"] = ix.ag.C.green
	}

	local options = ix.option.GetAllByCategories and ix.option.GetAllByCategories(true) or {}
	local cats = {}
	for cat, opts in pairs(options) do cats[#cats + 1] = {name = cat, opts = opts} end
	table.sort(cats, function(a, b) return a.name < b.name end)

	for _, cat in ipairs(cats) do
		local head = vgui.Create("Panel")
		head:Dock(TOP)
		head:DockMargin(0, 6, 4, 2)
		head:SetTall(24)
		head.catColor = catColors[cat.name] or ix.ag.C.combine
		head.catName = cat.name
		head.Paint = function(hh, hw, hh2)
			draw.SimpleText(hh.catName:upper(), "AG.SmallB", 4, hh2 / 2, hh.catColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			ix.ag.DrawNeonEdge(0, hh2 - 1, hw, hh.catColor, 80)
		end
		scroll:AddItem(head)

		local keys = {}
		for k, _ in pairs(cat.opts) do keys[#keys + 1] = k end
		table.sort(keys)

		for _, key in ipairs(keys) do
			local option = cat.opts[key]
			local row = self:BuildOptionRow(key, option)
			if (row) then scroll:AddItem(row) end
		end
	end

	-- ====== ПРАВАЯ КОЛОНКА: ПРАВИЛА/ЛОР ======
	local rulesPanel = self:Add("AGPanel")
	rulesPanel:SetPos(w * 0.47 + 12, 0)
	rulesPanel:SetSize(w * 0.53 - 12, h)
	rulesPanel:SetEdgeColor(ix.ag.C.amber)

	local rTitle = rulesPanel:Add("DLabel")
	rTitle:SetText("ПРАВИЛА & СПРАВКА ПО ЛОРУ")
	rTitle:SetFont("AG.SmallB")
	rTitle:SetTextColor(ix.ag.C.textDim)
	rTitle:SizeToContents()
	rTitle:SetPos(10, 8)

	local rScroll = rulesPanel:Add("AGScrollPanel")
	rScroll:SetPos(6, 30)
	rScroll:SetSize(w * 0.53 - 24, h - 40)

	for _, section in ipairs(self.RULES) do
		local head = vgui.Create("Panel")
		head:Dock(TOP)
		head:DockMargin(0, 4, 4, 2)
		head:SetTall(22)
		head.col = section.color
		head.txt = section.title
		head.Paint = function(hh, hw, hh2)
			surface.SetDrawColor(hh.col.r, hh.col.g, hh.col.b, 20)
			surface.DrawRect(0, 0, hw, hh2)
			surface.SetDrawColor(hh.col)
			surface.DrawRect(0, 0, 3, hh2)
			draw.SimpleText(hh.txt, "AG.SmallB", 8, hh2 / 2, hh.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		end
		rScroll:AddItem(head)

		for _, line in ipairs(section.lines) do
			local ln = vgui.Create("Panel")
			ln:Dock(TOP)
			ln:DockMargin(8, 0, 4, 0)
			ln:SetTall(15)
			ln.txt = line
			ln.Paint = function(l, lw, lh)
				draw.SimpleText(l.txt, "AG.Small", 4, lh / 2, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			end
			rScroll:AddItem(ln)
		end
	end
end

function PANEL:BuildOptionRow(key, option)
	if (option.type == ix.type.bool) then
		local t = vgui.Create("AGToggle")
		t:Dock(TOP)
		t:DockMargin(0, 0, 4, 2)
		t:SetTall(22)
		t:SetLabel(L(option.phrase or key))
		t:SetChecked(ix.option.Get(key))
		t.OnChange = function(_, state)
			ix.option.Set(key, state)
		end
		return t
	end

	if (option.type == ix.type.number) then
		local s = vgui.Create("AGNumSlider")
		s:Dock(TOP)
		s:DockMargin(0, 0, 4, 2)
		s:SetTall(36)
		s:SetRange(option.min or 0, option.max or 10, ix.option.Get(key), option.decimals or 0)
		s:SetLabel(L(option.phrase or key))
		s.OnValueChanged = function(_, val)
			ix.option.Set(key, val)
		end
		return s
	end
end

vgui.Register("AGTabSettings", PANEL, "Panel")

ix.ag.RegisterMenuTab({
	id = "settings",
	name = "НАСТРОЙКИ",
	icon = "icon16/cog.png",
	order = 4,
	build = function(menu, parent)
		local pnl = parent:Add("AGTabSettings")
		pnl:Dock(FILL)
		return pnl
	end
})
