-- Вкладка «Персонаж & Статистика»: 3D-виджет + живые показатели HL:A style
ix.ag.RegisterMenuTab({
	id = "character",
	name = "ПЕРСОНАЖ",
	icon = "icon16/user_suit.png",
	order = 1,
	build = function(menu, parent)
		local ply = LocalPlayer()
		local char = ply:GetCharacter()
		if (!char) then return parent end

		local w, h = parent:GetWide(), parent:GetTall()

		-- ============ 3D-ВИДЖЕТ ============
		local stage = parent:Add("AGPanel")
		stage:SetPos(0, 0)
		stage:SetSize(w * 0.44, h)
		stage:SetEdgeColor(ix.ag.C.combine)

		local title = stage:Add("DLabel")
		title:SetPos(10, 8)
		title:SetText("ЛИЧНОЕ ДЕЛО // 3D-ОСМОТР")
		title:SetFont("AG.SmallB")
		title:SetTextColor(ix.ag.C.textDim)
		title:SizeToContents()

		local mv = stage:Add("AGModelView")
		mv:SetPos(8, 30)
		mv:SetSize(w * 0.44 - 16, h - 74)
		mv:SetFOV(30)
		mv:SetToolTip(false)
		mv:ShowModel(char:GetModel())

		local hint = stage:Add("DLabel")
		hint:SetPos(10, h - 40)
		hint:SetText("ЛКМ — вращение  •  Колесо — масштаб")
		hint:SetFont("AG.Tiny")
		hint:SetTextColor(ix.ag.C.textMute)
		hint:SizeToContents()

		-- ============ ДАННЫЕ И ШКАЛЫ ============
		local info = parent:Add("AGScrollPanel")
		info:SetPos(w * 0.44 + 12, 0)
		info:SetSize(w * 0.56 - 12, h)

		local function AddDataRow(label, value, valueColor)
			local row = vgui.Create("Panel")
			row:Dock(TOP)
			row:DockMargin(0, 0, 4, 2)
			row:SetTall(26)
			row.Paint = function(_, rw, rh)
				surface.SetDrawColor(255, 255, 255, 5)
				surface.DrawRect(0, 0, rw, rh)
				draw.SimpleText(label, "AG.Small", 6, rh / 2, ix.ag.C.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
				draw.SimpleText(tostring(value), "AG.SmallB", rw - 6, rh / 2, valueColor or ix.ag.C.text, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
			end
			info:AddItem(row)
			return row
		end

		local faction = ix.faction.indices[char:GetFaction()]
		local class = ix.class.list[char:GetClass()]
		local cid = char:GetData("cid", "—")
		local rank = char:GetData("rank")
		local digits = char:GetData("digits")

		AddDataRow("ИМЯ", char:GetName())
		AddDataRow("CID", tostring(cid) .. (digits and ("  (dev " .. tostring(digits) .. ")") or ""), ix.ag.C.amber)
		AddDataRow("ФРАКЦИЯ", faction and faction.name or "?", faction and faction.color)
		AddDataRow("КЛАСС / ДОЛЖНОСТЬ", class and class.name or "?")
		if (rank) then AddDataRow("ЗВАНИЕ", rank, ix.ag.C.combine) end
		AddDataRow("ГРАЖДАНСКИЙ СТАТУС", cid ~= "—" and "ЗАРЕГИСТРИРОВАН" or "НЕ УЧТЁН",
			cid ~= "—" and ix.ag.C.green or ix.ag.C.red)
		AddDataRow("ТОКЕНЫ", tostring(char:GetMoney()) .. " ☼", ix.ag.C.amber)

		local spacer = vgui.Create("Panel")
		spacer:Dock(TOP) spacer:SetTall(6)
		info:AddItem(spacer)

		local function AddBar(label, live, col)
			local bar = vgui.Create("AGProgressBar")
			bar:Dock(TOP)
			bar:DockMargin(0, 0, 8, 3)
			bar:SetTall(22)
			bar:SetLabel(label)
			bar:SetColor(col)
			bar.live = live
			bar:SetFraction(live())
			info:AddItem(bar)
			return bar
		end

		AddBar("ЗДОРОВЬЕ", function()
			if (!IsValid(ply)) then return 0 end
			local f = math.Clamp(ply:Health() / math.max(ply:GetMaxHealth(), 1), 0, 1)
			return f
		end, ix.ag.C.green)

		AddBar("БРОНЯ", function()
			if (!IsValid(ply)) then return 0 end
			return math.Clamp(ply:Armor() / 100, 0, 1)
		end, ix.ag.C.combine)

		AddBar("ВЫНОСЛИВОСТЬ", function()
			if (!IsValid(ply)) then return 0 end
			return (ply:GetNetVar("stamina", 100) or 100) / 100
		end, ix.ag.C.amber)

		AddBar("ЦЕЛОСТНОСТЬ ФИЛЬТРА", function()
			if (!IsValid(ply) or !ply.GetFilterFraction) then return 0 end
			return ply:GetFilterFraction() or 0
		end, ix.ag.C.neon)

		-- КЗ и мед. сводка (однократно при открытии)
		local zone = ply.GetNetVar and ply:GetNetVar("qzZone")
		if (zone) then
			AddDataRow("СТАТУС КЗ", "В ЗОНЕ: " .. zone.name .. " (ур. " .. tostring(zone.level) .. ")", ix.ag.C.red)
		else
			AddDataRow("СТАТУС КЗ", "ВНЕ ЗАРАЖЁННОЙ ОБЛАСТИ", ix.ag.C.green)
		end

		if (ix.medical) then
			local wnd = ix.medical.GetWounds(ply)
			if ((wnd.bleed or 0) > 0) then AddDataRow("СОСТОЯНИЕ", "КРОВОТЕЧЕНИЕ ур." .. wnd.bleed, ix.ag.C.red) end
			if ((wnd.infection or 0) > 0) then AddDataRow("СОСТОЯНИЕ", "ЗАРАЖЕНИЕ СПОРАМИ " .. (wnd.infection == 2 and "II" or "I"), ix.ag.C.green) end
			if (wnd.fracture) then AddDataRow("СОСТОЯНИЕ", "ПЕРЕЛОМ" .. (wnd.splinted and " (шина)" or ""), ix.ag.C.text) end
			if (wnd.burn) then AddDataRow("СОСТОЯНИЕ", "ПЛАЗМЕННЫЙ ОЖОГ", ix.ag.C.combine) end
			if ((wnd.bleed or 0) == 0 and (wnd.infection or 0) == 0 and !wnd.fracture and !wnd.burn) then
				AddDataRow("СОСТОЯНИЕ", "СТАБИЛЕН", ix.ag.C.green)
			end
		end

		return parent
	end
})
