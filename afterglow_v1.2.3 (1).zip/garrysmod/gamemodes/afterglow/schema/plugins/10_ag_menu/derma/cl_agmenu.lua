-- AGMenu — каркас единого меню: шапка, рейка вкладок, тело, футер
local PANEL = {}

local RAIL_W = 250

function PANEL:Init()
	self:SetSize(ScrW(), ScrH())
	self:MakePopup()
	self:SetKeyboardInputEnabled(false)
	self:SetMouseInputEnabled(true)
	ix.gui.agMenu = self

	self.created = RealTime()
	self.activeTab = nil
	self.tabPanels = {}
	self.tabButtons = {}

	-- встроенные вкладки (регистрируются в cl_tab_*.lua через ix.ag.RegisterMenuTab)
	self:BuildRail()
end

function PANEL:VisibleTabs()
	local out = {}
	for _, tab in ipairs(ix.ag.menuTabs) do
		if (!tab.visible or tab.visible()) then
			out[#out + 1] = tab
		end
	end
	table.sort(out, function(a, b) return (a.order or 99) < (b.order or 99) end)
	return out
end

function PANEL:BuildRail()
	local railY = 130
	self.railButtons = {}

	for _, tab in ipairs(self:VisibleTabs()) do
		local btn = self:Add("AGButton")
		btn:SetText("  " .. tab.name)
		btn:SetVariant("ghost")
		btn:SetFont("AG.MediumB")
		btn:SetSize(RAIL_W - 24, 44)
		btn:SetPos(16, railY)
		btn.tabID = tab.id
		if (tab.icon) then btn.icon = Material(tab.icon) btn:SetText("      " .. tab.name) end
		btn.Paint = function(b, w, h)
			AGButtonTabPaint(b, w, h, self.activeTab == tab.id)
		end
		btn.DoClick = function()
			self:SelectTab(tab.id)
		end

		railY = railY + 48
		self.tabButtons[tab.id] = btn
	end

	-- кнопка закрытия внизу рейки
	local close = self:Add("AGButton")
	close:SetText("  ЗАКРЫТЬ  [TAB]")
	close:SetFont("AG.SmallB")
	close:SetVariant("danger")
	close:SetSize(RAIL_W - 24, 36)
	close:SetPos(16, ScrH() - 56)
	close.DoClick = function() ix.ag.CloseMenu() end
end

-- отрисовка кнопки вкладки с полосой-индикатором (компактный вариант)
function AGButtonTabPaint(btn, w, h, selected)
	btn.hover = ix.ag.Dampen(12, btn.hover or 0, btn:IsHovered() and 1 or 0)
	local glow = math.max(btn.hover, selected and 1 or 0)

	local col = ix.ag.C.neon
	surface.SetDrawColor(col.r, col.g, col.b, 6 + 40 * glow)
	surface.DrawRect(0, 0, w, h)

	-- полоса-индикатор
	btn.indW = ix.ag.Dampen(10, btn.indW or 0, selected and 4 or 0)
	surface.SetDrawColor(col.r, col.g, col.b, 200 + 55 * btn.hover)
	surface.DrawRect(0, 0, btn.indW, h)

	if (btn.icon) then
		surface.SetDrawColor(selected and col or ix.ag.C.textDim)
		surface.SetMaterial(btn.icon)
		surface.DrawTexturedRect(14, h / 2 - 8, 16, 16)
	end

	draw.SimpleText(btn:GetText():gsub("^%s+", ""), "AG.MediumB", btn.icon and 38 or 12, h / 2,
		selected and ix.ag.C.text or ix.ag.C.textDim, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
end

function PANEL:SelectTab(id)
	self.activeTab = id
	ix.ag.Click()
	ix.ag.HideTooltip()

	-- скрыть/создать/показать панель
	for tabID, pnl in pairs(self.tabPanels) do
		pnl:SetVisible(tabID == id)
	end

	if (!IsValid(self.tabPanels[id])) then
		local def
		for _, tab in ipairs(ix.ag.menuTabs) do
			if (tab.id == id) then def = tab break end
		end
		if (!def or !def.build) then return end

		local body = self:AddPanel()
		local pnl = def.build(self, body)
		if (!IsValid(pnl)) then pnl = body end
		self.tabPanels[id] = pnl
	end

	local pnl = self.tabPanels[id]
	if (IsValid(pnl)) then
		pnl.frac = 0
		pnl:SetVisible(true)
	end
end

function PANEL:AddPanel()
	local pnl = self:Add("Panel")
	pnl:SetPos(RAIL_W + 18, 118)
	pnl:SetSize(ScrW() - RAIL_W - 40, ScrH() - 160)
	return pnl
end

function PANEL:Paint(w, h)
	-- блюр всего экрана + затемнение
	ix.ag.DrawBlur(self, 2)
	local t = (RealTime() - self.created)
	local appear = ix.option.Get("agAnimations", true) and math.Clamp(t * 2.2, 0, 1) or 1

	surface.SetDrawColor(5, 8, 12, 225 * appear)
	surface.DrawRect(0, 0, w, h)

	-- градиент снизу
	for i = 0, 9 do
		surface.SetDrawColor(0, 212, 255, (1.6 - i * 0.14) * appear)
		surface.DrawRect(0, h - (10 - i) * 26, w, 26)
	end

	-- шапка
	self:PaintHeader(w)

	-- футер
	draw.SimpleText("AFTERGLOW v1.2.3", "AG.Tiny", w / 2, h - 22, ix.ag.C.textMute, TEXT_ALIGN_CENTER)
	local group = LocalPlayer().AGGroup and LocalPlayer():AGGroup() or "user"
	local gData = ix.ag.GROUPS and ix.ag.GROUPS[group]
	if (gData and gData.prefix ~= "") then
		draw.SimpleText("[" .. gData.prefix .. "] " .. gData.name, "AG.SmallB", w - 18, h - 22, gData.color, TEXT_ALIGN_RIGHT)
	end

	-- плавное появление активной вкладки
	local pnl = self.tabPanels[self.activeTab]
	if (IsValid(pnl) and (pnl.frac or 1) < 1) then
		pnl.frac = ix.ag.Dampen(8, pnl.frac, 1)
		pnl:SetAlpha(pnl.frac * 255)
	end

	ix.ag.DrawScanlines(0, 0, w, h, 3)
end

function PANEL:PaintHeader(w)
	-- лого блок
	surface.SetDrawColor(ix.ag.C.neon.r, ix.ag.C.neon.g, ix.ag.C.neon.b, 12)
	surface.DrawRect(0, 0, w, 92)
	ix.ag.DrawNeonEdge(0, 92, w, ix.ag.C.neon, 110)

	draw.SimpleText("λ", "AG.HL2Icons", 26, 12, ix.ag.C.amber)
	draw.SimpleText("AFTERGLOW", "AG.BigB", 52, 12, ix.ag.C.text)
	draw.SimpleText("// CITY-17 EARLY NETWORK", "AG.Mono", 52, 44, ix.ag.C.neon)

	local ply = LocalPlayer()
	local char = ply:GetCharacter()
	local right = w - 20

	draw.SimpleText(GetHostName(), "AG.Small", right, 10, ix.ag.C.textDim, TEXT_ALIGN_RIGHT)
	draw.SimpleText("map: " .. game.GetMap() .. "  •  " .. #player.GetAll() .. "/" .. game.MaxPlayers() .. " online  •  " .. os.date("%H:%M"), "AG.MonoSmall", right, 30, ix.ag.C.textMute, TEXT_ALIGN_RIGHT)
	if (char) then
		draw.SimpleText(char:GetName(), "AG.SmallB", right, 50, ix.ag.C.neon, TEXT_ALIGN_RIGHT)
		local faction = ix.faction.indices[char:GetFaction()]
		if (faction) then
			draw.SimpleText(faction.name, "AG.Tiny", right, 70, faction.color, TEXT_ALIGN_RIGHT)
		end
	end
end

function PANEL:Think()
	if (gui.IsGameUIVisible() and !self.bClosing) then
		self.bClosing = true
		ix.ag.CloseMenu()
	end
end

function PANEL:OnRemove()
	gui.EnableScreenClicker(false)
end

vgui.Register("AGMenu", PANEL, "EditablePanel")
