-- ============================================================
-- МОДУЛЬ 2: Граво-перчатки (Russell's Gloves)
-- SWEP: addons/hlarp/lua/weapons/weapon_gravgloves
-- Плагин: трекинг притянутых предметов, авто-поглощение lut'а,
-- выдача, наручный HUD (derma/cl_wrist.lua).
-- ============================================================
PLUGIN.name = "Gravity Gloves"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Мультифункциональные граво-перчатки сопротивления: притягивание лёгкого lut'а на расстоянии."

if (CLIENT) then
	ix.util.Include("derma/cl_wrist.lua")
end

ix.config.Add("gravPullSpeed", 1100, "Скорость притягивания снаряда-импульса перчаток.")
ix.config.Add("gravMaxMass", 20, "Максимальная масса притягиваемого пропа (кг).")
ix.config.Add("gravReach", 420, "Дальность захвата перчаток (юниты).")
ix.config.Add("gravPickupDist", 72, "Дистанция авто-поглощения предмета.")

ix.gravgloves = {pulls = {}}

-- Регистрация притянутого объекта (вызывается SWEP'ом, сервер)
function ix.gravgloves.Track(entity, owner)
	if (SERVER) then
		ix.gravgloves.pulls[entity] = {owner = owner, time = CurTime()}
		entity:EmitSound("weapons/physcannon/physcannon_drop.wav", 55, 120)
	end
end

if (SERVER) then
	function PLUGIN:Think()
		local now = CurTime()
		local pickupDist = ix.config.Get("gravPickupDist", 72) ^ 2

		for entity, data in pairs(ix.gravgloves.pulls) do
			if (!IsValid(entity) or !IsValid(data.owner) or now - data.time > 4) then
				ix.gravgloves.pulls[entity] = nil
				continue
			end

			-- Догнали снаряд импульса → стремимся прямо в руку
			local aimPos = data.owner:GetShootPos()
			local pos = entity:GetPos()

			if (pos:DistToSqr(aimPos) < pickupDist) then
				ix.gravgloves.pulls[entity] = nil
				if (entity:GetClass() == "ix_item") then
					self:AbsorbItem(data.owner, entity)
				end
			else
				-- плавная коррекция курса к цели
				local phys = entity:GetPhysicsObject()
				if (IsValid(phys)) then
					local dir = (aimPos - pos):GetNormalized()
					phys:SetVelocity(dir * 900 + Vector(0, 0, 40))
				end
			end
		end
	end

	-- Переложить world-item в инвентарь (сохраняя data)
	function PLUGIN:AbsorbItem(client, entity)
		local item = entity.GetItemTable and entity:GetItemTable() or ix.item.instances[entity.ixItemID]
		local character = client:GetCharacter()
		if (!item or !character) then return end

		local inventory = character:GetInventory()
		local data = table.Copy(item.data or {})

		local ok = inventory:Add(item.uniqueID, 1, data)
		if (ok) then
			item:Remove() -- снимает и инстанс, и world-энтити
			client:EmitSound("items/ammo_pickup.wav", 60)
			client:Notify("Поглощено перчатками: " .. item:GetName())
		else
			-- инвентарь полон — выронить у ног
			local phys = entity:GetPhysicsObject()
			if (IsValid(phys)) then phys:SetVelocity(Vector(0, 0, 60)) end
			client:Notify("Инвентарь полон — предмет падает у ваших ног.")
		end
	end
end

-- Контрабанда: ГО/ОВА видят перчатки — это сразу «комитет по амнистии»
function PLUGIN:PlayerWeaponChanged(client, weapon) end -- зарезервировано под уведомления КПП

-- Выдача перчаток (админ/ивент-мастер)
ix.command.Add("CharGiveGravGloves", {
	description = "Выдать цели граво-перчатки (предмет в инвентарь).",
	adminOnly = true,
	arguments = {ix.type.character},
	OnRun = function(self, client, target)
		local ok = target:GetInventory():Add("gravgloves_item", 1)
		if (ok) then
			client:Notify("Перчатки выданы: " .. target:GetName())
		else
			client:Notify("Не удалось выдать (инвентарь?).")
		end
	end
})
