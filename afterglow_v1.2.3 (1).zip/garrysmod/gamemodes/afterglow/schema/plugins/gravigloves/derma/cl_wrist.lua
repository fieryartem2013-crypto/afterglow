-- Наручный интерфейс: HP/патроны, как на тыльной стороне перчаток Аликс.
-- Рисуется при взятых граво-перчатках (или предмете в руках).
local PLUGIN = PLUGIN

local function DrawRing(x, y, r, frac, color, label, value)
	-- основание
	surface.SetDrawColor(0, 0, 0, 150)
	draw.NoTexture()
	surface.DrawCircle(x, y, r, 20, 20, 20, 200)

	-- дуга значения: аппроксимация сегментами
	local segments = 48
	local filled = math.floor(frac * segments + 0.5)
	for i = 1, filled do
		local a = math.rad(-90 + (i / segments) * 360)
		surface.SetDrawColor(color)
		surface.DrawRect(x + math.cos(a) * r - 3, y + math.sin(a) * r - 3, 6, 6)
	end

	draw.SimpleText(value, "ixMediumLightFont", x, y - 4, color, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw.SimpleText(label, "ixSmallFont", x, y + 16, Color(190, 190, 190), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

function PLUGIN:HUDPaint()
	local client = LocalPlayer()
	if (!client:GetCharacter() or !client:Alive()) then return end

	local weapon = client:GetActiveWeapon()
	if (!IsValid(weapon) or weapon:GetClass() != "weapon_gravgloves") then return end

	local x, y = ScrW() * 0.12, ScrH() * 0.78
	local hpFrac = math.Clamp(client:Health() / client:GetMaxHealth(), 0, 1)
	DrawRing(x, y, 34, hpFrac, Color(120, 230, 120), "ЖИВУЧЕСТЬ", client:Health())

	ix.util.DrawText("GRAV-GLOVES :: МАГНИТ ГОТОВ", x, y - 58, Color(120, 200, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, "ixSmallFont")
end
