-- AGDispatchBanner — полноэкранный баннер директивы (HL:A style)
local PANEL = {}

local SEVERITY = {
	[0] = {col = ix.ag.C.green,   tag = "ИНФОРМАЦИЯ"},
	[1] = {col = ix.ag.C.amber,   tag = "ПРЕДУПРЕЖДЕНИЕ"},
	[2] = {col = ix.ag.C.red,     tag = "ТРЕВОГА"}
}

function PANEL:Init()
	self:SetSize(ScrW(), ScrH())
	self:SetPos(0, 0)
	self:MakePopup()
	self:SetDrawOnTop(true)
	self:SetKeyboardInputEnabled(false)
	self:SetMouseInputEnabled(false)

	self.startT = RealTime()
	self.life = 7
	self.panelH = 86
end

function PANEL:SetDirective(text, severity, sender)
	self.text = text
	self.sev = SEVERITY[severity] or SEVERITY[1]
	self.sender = sender or "ДИСПАТЧ"
end

function PANEL:Paint(w, h)
	local t = RealTime() - self.startT
	local appear = math.Clamp(t * 3, 0, 1)
	local fade = math.Clamp((self.life - t) / 1.2, 0, 1)
	local alpha = appear * fade
	if (alpha <= 0) then return end

	local ph = self.panelH * appear
	local y = h * 0.16
	local c = self.sev.col
	local pulse = math.sin(RealTime() * 8) * 0.5 + 0.5

	-- полоса-фон
	surface.SetDrawColor(6, 8, 11, 232 * alpha)
	surface.DrawRect(0, y, w, ph)

	surface.SetDrawColor(c.r, c.g, c.b, (40 + 60 * pulse) * alpha)
	surface.DrawRect(0, y, w, ph)

	-- неоновые кромки
	ix.ag.DrawNeonEdge(0, y, w, c, 230 * alpha)
	ix.ag.DrawNeonEdge(0, y + ph - 2, w, c, 230 * alpha)

	-- боковые стрелки-индикаторы
	local a = RealTime() * 4 % 2 - 1
	surface.SetDrawColor(c.r, c.g, c.b, 180 * alpha)
	draw.NoTexture()
	local function Arrow(x, dir)
		surface.DrawPoly({
			{x, y + ph / 2}, {x + 26 * dir, y + ph / 2 - 18}, {x + 26 * dir, y + ph / 2 + 18}
		})
	end
	Arrow(40 + math.abs(a) * 20, 1)
	Arrow(w - 40 - math.abs(a) * 20, -1)

	-- текст
	draw.SimpleText("//  ДИСПАТЧ АЛЬЯНСА  —  " .. self.sev.tag .. "  //", "AG.SmallB",
		w / 2, y + 12, c, TEXT_ALIGN_CENTER)
	draw.SimpleText(self.text or "", "AG.MediumB",
		w / 2, y + ph / 2 + 10, Color(255, 255, 255, 255 * alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

function PANEL:Think()
	if (RealTime() - self.startT > self.life) then
		self:Remove()
	end
end

vgui.Register("AGDispatchBanner", PANEL, "EditablePanel")

-- ---------- единый приёмник ----------
net.Receive("agDispatch", function()
	local op = net.ReadUInt(4)

	if (op == 9) then -- открыть панель диспатчера
		if (IsValid(ix.gui.agDispatchPanel)) then return end
		vgui.Create("AGDispatchPanel")
		return
	end

	if (op == 1) then -- директива всем игрокам
		local text = net.ReadString()
		local severity = net.ReadUInt(2)
		local sender = net.ReadString()
		local sound = net.ReadString()

		if (IsValid(ix.gui.agDispatchBanner)) then
			ix.gui.agDispatchBanner:Remove()
		end
		local b = vgui.Create("AGDispatchBanner")
		b:SetDirective(text, severity, sender)
		b:SetKeyboardInputEnabled(false)
		b:SetMouseInputEnabled(false)
		ix.gui.agDispatchBanner = b

		if (sound ~= "") then
			surface.PlaySound(sound)
		elseif (severity >= 2) then
			surface.PlaySound("ambient/alarms/klaxon1.wav")
		else
			surface.PlaySound("ambient/alarms/warningbell1.wav")
		end
	end
end)
