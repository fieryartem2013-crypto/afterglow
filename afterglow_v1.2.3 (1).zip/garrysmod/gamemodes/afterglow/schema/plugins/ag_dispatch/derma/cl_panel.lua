-- AGDispatchPanel — панель диспатчера: пресеты, быстрые тревоги, кастомный текст
local PANEL = {}

local SEV = {
	[0] = {name = "ИНФОРМАЦИЯ", col = ix.ag.C.green},
	[1] = {name = "ПРЕДУПРЕЖДЕНИЕ", col = ix.ag.C.amber},
	[2] = {name = "ТРЕВОГА", col = ix.ag.C.red}
}

function PANEL:Init()
	ix.gui.agDispatchPanel = self
	local w, h = 720, 620
	self:SetSize(w, h)
	self:Center()
	self:MakePopup()
	self:SetTitle("АЛЬЯНС // ПАНЕЛЬ ДИСПАТЧЕРА")

	local plugin = ix.plugin.Get("ag_dispatch")
	self.presets = plugin and plugin.presets or {}
	self.severity = 1

	-- ---------- БЫСТРЫЕ ТРЕВОГИ ----------
	local alarmWrap = self:Add("Panel")
	alarmWrap:SetPos(10, 42)
	alarmWrap:SetSize(w - 20, 60)

	local at = alarmWrap:Add("DLabel")
	at:SetText("БЫСТРЫЕ ТРЕВОГИ:")
	at:SetFont("AG.SmallB")
	at:SetTextColor(ix.ag.C.textDim)
	at:SizeToContents()
	at:SetPos(2, 0)

	local ax = 2
	for _, pr in ipairs(self.presets) do
		if (pr.severity >= 1) then
			local b = alarmWrap:Add("AGButton")
			b:SetSize(172, 34)
			b:SetPos(ax, 22)
			b:SetText("! " .. pr.name)
			b:SetVariant("danger")
			b.preset = pr
			b.DoClick = function(btn)
				ix.ag.Click()
				net.Start("agDispatch")
					net.WriteUInt(0, 4)
					net.WriteString(btn.preset.id)
				net.SendToServer()
				self:Remove()
			end
			ax = ax + 177
		end
	end

	-- ---------- ПРЕСЕТЫ ----------
	local pt = self:Add("DLabel")
	pt:SetPos(12, 116)
	pt:SetText("БИБЛИОТЕКА ДИРЕКТИВ:")
	pt:SetFont("AG.SmallB")
	pt:SetTextColor(ix.ag.C.textDim)
	pt:SizeToContents()

	self.presetList = self:Add("AGScrollPanel")
	self.presetList:SetPos(10, 136)
	self.presetList:SetSize(w - 20, 152)

	for _, pr in ipairs(self.presets) do
		local card = self.presetList:Add("Panel")
		card:Dock(TOP)
		card:DockMargin(0, 0, 6, 4)
		card:SetTall(56)
		card.pr = pr
		card.Paint = function(c, cw, ch)
			local cSev = SEV[c.pr.severity] or SEV[1]
			surface.SetDrawColor(8, 12, 17, 235)
			surface.DrawRect(0, 0, cw, ch)
			surface.SetDrawColor(cSev.col)
			surface.DrawRect(0, 0, 4, ch)
			draw.SimpleText(c.pr.name, "AG.SmallB", 12, 8, cSev.col)
			draw.SimpleText(c.pr.text, "AG.Tiny", 12, 26, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP, cw - 130)
		end
		local send = card:Add("AGButton")
		send:SetText("ТРАНСЛИРОВАТЬ")
		send:SetSize(120, 24)
		send:SetPos(math.max(6, self.presetList:GetWide() - 136), 26)
		send:SetVariant("primary")
		send.pid = pr.id
		send.DoClick = function(btn)
			ix.ag.Click()
			net.Start("agDispatch")
				net.WriteUInt(0, 4)
				net.WriteString(btn.pid)
			net.SendToServer()
			self:Remove()
		end
	end

	-- ---------- КАСТОМНЫЙ ТЕКСТ ----------
	local ct = self:Add("DLabel")
	ct:SetPos(12, 300)
	ct:SetText("КАСТОМНАЯ ДИРЕКТИВА:")
	ct:SetFont("AG.SmallB")
	ct:SetTextColor(ix.ag.C.textDim)
	ct:SizeToContents()

	self.textEntry = self:Add("DTextEntry")
	self.textEntry:SetPos(12, 320)
	self.textEntry:SetSize(w - 24, 74)
	self.textEntry:SetMultiline(true)
	self.textEntry:SetFont("AG.Small")
	self.textEntry:SetTextColor(ix.ag.C.text)
	self.textEntry:SetPlaceholderText("ВНИМАНИЕ. <текст директивы, максимум 220 символов>")
	self.textEntry.Paint = function(te, tw, th)
		surface.SetDrawColor(10, 14, 19, 235)
		surface.DrawRect(0, 0, tw, th)
		surface.SetDrawColor(ix.ag.C.neon)
		surface.DrawOutlinedRect(0, 0, tw, th, 1)
		te:DrawTextEntryText(ix.ag.C.text, ix.ag.C.neon, ix.ag.C.text)
	end

	-- важность
	local sevL = self:Add("DLabel")
	sevL:SetPos(12, 404)
	sevL:SetText("УРОВЕНЬ ВАЖНОСТИ:")
	sevL:SetFont("AG.SmallB")
	sevL:SetTextColor(ix.ag.C.textDim)
	sevL:SizeToContents()

	local sx = 160
	for i = 0, 2 do
		local b = self:Add("AGButton")
		b:SetText(SEV[i].name)
		b:SetSize(150, 28)
		b:SetPos(sx, 398)
		b:SetVariant("ghost")
		b.sid = i
		b.DoClick = function(btn)
			ix.ag.Click()
			self.severity = btn.sid
			for _, ob in ipairs(self:GetChildren()) do
				if (ob.sid != nil) then ob.selectedSev = false end
			end
			btn.selectedSev = true
		end
		b.PaintOver = function(btn, bw, bh)
			if (btn.selectedSev) then
				local c2 = SEV[btn.sid].col
				surface.SetDrawColor(c2.r, c2.g, c2.b, 40)
				surface.DrawRect(0, 0, bw, bh)
				surface.DrawOutlinedRect(0, 0, bw, bh, 2)
			end
		end
		sx = sx + 156
	end

	-- кнопка отправки
	local go = self:Add("AGButton")
	go:SetText("ОТПРАВИТЬ ДИРЕКТИВУ")
	go:SetVariant("amber")
	go:SetSize(w - 24, 40)
	go:SetPos(12, 440)
	go.DoClick = function()
		local text = string.Trim(self.textEntry:GetValue())
		if (text == "") then return end
		ix.ag.Click()
		net.Start("agDispatch")
			net.WriteUInt(1, 4)
			net.WriteString(text)
			net.WriteUInt(self.severity, 2)
		net.SendToServer()
		self:Remove()
	end

	-- справка о допуске
	local help = self:Add("DLabel")
	help:SetPos(12, 492)
	help:SetText(
		"Доступ: командование администрации / стафф с правом dispatch. \\n" ..
		"Директива транслируется баннером + звуком всем игрокам. \\n" ..
		"Кулдаун: " .. ix.config.Get("dispatchCooldown", 12) .. " секунд между отправками."
	)
	help:SetFont("AG.Small")
	help:SetTextColor(ix.ag.C.textMute)
	help:SetAutoStretchVertical(true)
	help:SetWrap(true)
	help:SetWide(w - 24)
end

function PANEL:OnRemove()
	ix.gui.agDispatchPanel = nil
end

vgui.Register("AGDispatchPanel", PANEL, "AGFrame")
