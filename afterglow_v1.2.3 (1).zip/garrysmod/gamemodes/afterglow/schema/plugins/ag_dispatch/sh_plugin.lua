-- ============================================================
-- AFTERGLOW DISPATCH — оповещения Альянса
-- Панель диспатчера (/agdispatch): готовые фразы HL:A/HL2,
-- кастомный текст, быстрые тревоги. Баннер + звук всем игрокам.
-- ============================================================
PLUGIN.name = "AfterGlow Dispatch"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "Система оповещений Альянса: панель диспатчера, баннеры, звук."

local PLUGIN = PLUGIN  -- захват глобала: в колбэках hook.Add/net.Receive глобал PLUGIN после загрузки указывает на другой плагин/nil

if (SERVER) then
	util.AddNetworkString("agDispatch")
else
	ix.util.IncludeDir(PLUGIN.folder .. "/derma")
end

ix.config.Add("dispatchCooldown", 12, "Кулдаун между оповещениями одного диспатчера (сек).")

-- ------------------------------------------------------------
-- ПРЕСЕТЫ (HL2 cityvoice — стоковые звуки, гарантированно есть у клиента)
-- ------------------------------------------------------------
PLUGIN.presets = {
	{
		id = "qzbreech", name = "ПРОРЫВ КАРАНТИННОЙ ЗОНЫ",
		text = "ВНИМАНИЕ. ЗАФИКСИРОВАН ПРОРЫВ ПЕРИМЕТРА КАРАНТИННОЙ ЗОНЫ. ГРАЖДАНАМ ПОКИНУТЬ СЕКТОР.",
		sound = "npc/overwatch/cityvoice/f_anticivilevidence_3_spkr.wav",
		severity = 2 -- 0 info, 1 warn, 2 alarm
	},
	{
		id = "evader", name = "УКЛОНИСТ В СЕКТОРЕ",
		text = "БЛОК ЗАКРЫТ. НЕЗАФИКСИРОВАННАЯ ЛИЧНОСТЬ В СЕКТОРЕ. ОСТАВАЙТЕСЬ В ПОМЕЩЕНИЯХ.",
		sound = "npc/overwatch/cityvoice/f_ceaseevasionlevelfive_spkr.wav",
		severity = 2
	},
	{
		id = "curfew", name = "ИНСПЕКЦИОННЫЙ КОМЕНДАНТСКИЙ ЧАС",
		text = "ОБЪЯВЛЕН КОМЕНДАНТСКИЙ ЧАС. РАЗДЕЛЬНОЕ СОБИРАНИЕ ЗАПРЕЩЕНО. СЛЕДУЙТЕ УКАЗАНИЯМ ГО.",
		sound = "npc/overwatch/cityvoice/f_innactionisconspiracy_spkr.wav",
		severity = 1
	},
	{
		id = "purge", name = "АКТИВАЦИЯ ОЧИСТКИ",
		text = "ЗАПУЩЕН ПРОТОКОЛ ОЧИСТКИ СЕКТОРА. ГРАЖДАНАМ СОБЛЮДАТЬ СПОКОЙСТВИЕ И ПОРЯДОК.",
		sound = "npc/overwatch/cityvoice/f_unrestprocedure1_spkr.wav",
		severity = 1
	},
	{
		id = "ration", name = "ВЫДАЧА РАЦИОНОВ",
		text = "РАСПРЕДЕЛЕНИЕ ПАЙКОВ НАЧАЛОСЬ. ЯВКА К ПУНКТУ ВЫДАЧИ ОБЯЗАТЕЛЬНА.",
		sound = "npc/overwatch/cityvoice/f_rationunitsdeduct_3_spkr.wav",
		severity = 0
	},
	{
		id = "assemble", name = "ПОГРАНИЧНЫЙ СБОР",
		text = "ВНИМАНИЕ. ГРАЖДАНАМ ПРОСЛЕДОВАТЬ К СВОИМ БЛОКАМ СОГЛАСНО РАСПИСАНИЮ.",
		sound = "npc/overwatch/cityvoice/f_trainstation_assemble_spkr.wav",
		severity = 0
	}
}

-- ------------------------------------------------------------
-- ДОПУСК К ПАНЕЛИ
-- ------------------------------------------------------------
function PLUGIN:CanDispatch(ply)
	if (!IsValid(ply)) then return false end
	if (ply.AGHasPerm and ply:AGHasPerm("dispatch")) then return true end
	local char = ply:GetCharacter()
	if (!char) then return false end
	local faction = ix.faction.indices[char:GetFaction()]
	-- высший состав: фракция администрации Городского Объединения
	if (faction and faction.uniqueID == "administration") then return true end
	return false
end

-- ------------------------------------------------------------
-- РАССЫЛКА
-- ------------------------------------------------------------
if (SERVER) then
	function PLUGIN:Broadcast(text, severity, senderName, sound)
		text = string.sub(string.Trim(text or ""), 1, 220)
		if (text == "") then return end
		severity = math.Clamp(tonumber(severity) or 1, 0, 2)

		net.Start("agDispatch")
			net.WriteUInt(1, 4) -- op: директива всем
			net.WriteString(text)
			net.WriteUInt(severity, 2)
			net.WriteString(senderName or "ДИСПАТЧ")
			net.WriteString(sound or "")
		net.Broadcast()

		-- красивая рамка в чат всем
		local frame = "▬▬▬▬▬▬"
		for _, p in player.Iterator() do
			p:ChatPrint(Color(255, 60, 60) and string.format("%s ДИРЕКТИВА АЛЬЯНСА %s", frame, frame))
			p:ChatPrint("  " .. text)
		end

		-- лог
		ix.log.AddRaw(senderName .. " dispatched: " .. text)
	end

	net.Receive("agDispatch", function(_, ply)
		local op = net.ReadUInt(4)
		if (!PLUGIN:CanDispatch(ply)) then return end

		if (!ply.dispatchCD or ply.dispatchCD < CurTime()) then
			ply.dispatchCD = CurTime() + ix.config.Get("dispatchCooldown", 12)
		else
			ply:Notify("Диспетчерская линия занята: подождите " ..
				math.ceil(ply.dispatchCD - CurTime()) .. "с.")
			return
		end

		local senderName = ply.GetCharacter and ply:GetCharacter() and ply:GetCharacter():GetName() or ply:Nick()

		if (op == 0) then -- пресет
			local presetID = net.ReadString()
			for _, pr in ipairs(PLUGIN.presets) do
				if (pr.id == presetID) then
					PLUGIN:Broadcast(pr.text, pr.severity, senderName, pr.sound)
					ply:Notify("Директива транслирована: " .. pr.name)
					return
				end
			end
		elseif (op == 1) then -- кастом
			local text = net.ReadString()
			local severity = net.ReadUInt(2)
			PLUGIN:Broadcast(text, severity, senderName,
				severity >= 2 and "ambient/alarms/klaxon1.wav" or "ambient/alarms/warningbell1.wav")
			ply:Notify("Директива транслирована.")
		end
	end)
end

-- ------------------------------------------------------------
-- КОМАНДА ОТКРЫТИЯ ПАНЕЛИ
-- ------------------------------------------------------------
ix.command.Add("AGDispatch", {
	description = "Открыть панель диспетчерских оповещений Альянса.",
	superAdminOnly = false,
	OnRun = function(self, client)
		if (!PLUGIN:CanDispatch(client)) then
			return "Панель диспатча доступна командованию (фракция администрации) и стаффу с правом dispatch."
		end
		if (SERVER) then
			net.Start("agDispatch")
				net.WriteUInt(9, 4) -- op: open panel
			net.Send(client)
		end
	end
})
