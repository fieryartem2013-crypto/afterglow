-- ============================================================
-- AFTERGLOW CWU / ГСР — станочный геймплей
-- Станок переработки (стейджинг сырья → рецепт → продукция),
-- очистители воздуха (обслуживание → локальный иммунитет QZ),
-- терминал нарядов (заказы с прогрессом и наградой).
-- Энтити: addons/afterglow/lua/entities/ix_cwu_*/  (shared/init/cl_init)
-- ============================================================
PLUGIN.name = "AfterGlow CWU"
PLUGIN.author = "AfterGlow Team"
PLUGIN.description = "ГСР: станки переработки, очистители воздуха, терминал нарядов."

local PLUGIN = PLUGIN  -- захват глобала: в колбэках hook.Add/net.Receive глобал PLUGIN после загрузки указывает на другой плагин/nil

if (SERVER) then
	util.AddNetworkString("cwuBench")
	util.AddNetworkString("cwuTerminal")
	util.AddNetworkString("cwuCleaner")
else
	ix.util.IncludeDir(PLUGIN.folder .. "/derma")
end

ix.config.Add("cwuMeritValue", 20, "Стоимость чека заслуг ГСР в токенах.")
ix.config.Add("cwuCleanerRadius", 1000, "Радиус действия исправного очистителя воздуха.")
ix.config.Add("cwuCleanerDrain", 4, "Потеря состояния очистителя за цикл (см. cwuCleanerDecay).")
ix.config.Add("cwuCleanerDecay", 600, "Интервал деградации очистителя (сек).")
ix.config.Add("cwuCleanerServiceTime", 5, "Длительность обслуживания очистителя (сек).")
ix.config.Add("cwuCleanerReward", 12, "Токены за обслуживание очистителя.")

-- ------------------------------------------------------------
-- РЕЦЕПТЫ СТАНКА (inputs: uid→count; outputs: uid→count)
-- ------------------------------------------------------------
PLUGIN.recipes = {
	sort = {
		name = "СОРТИРОВКА",
		desc = "Разобрать вторсырьё на чистые детали.",
		inputs  = {scrap_junk = 2},
		outputs = {scrap_parts = 1},
		tokens  = 4,
		time    = 6,
		quota   = "sort"
	},
	clean = {
		name = "ОЧИСТКА ФИЛЬТРОВ",
		desc = "Отмыть грязный фильтр до рабочего состояния.",
		inputs  = {dirty_filter = 1},
		outputs = {filter = 1},
		tokens  = 8,
		time    = 8,
		quota   = "clean"
	},
	ration = {
		name = "СБОРКА РАЦИОНОВ",
		desc = "Запечатать компоненты в полноценный паёк Альянса.",
		inputs  = {ration_components = 3},
		outputs = {sealed_ration = 1},
		tokens  = 6,
		time    = 7,
		quota   = "ration"
	},
	press = {
		name = "ПРЕССОВАНИЕ ЛОМА",
		desc = "Спрессовать детали в металлический блок.",
		inputs  = {scrap_parts = 2, scrap_junk = 1},
		outputs = {metal_block = 1},
		tokens  = 10,
		time    = 10,
		quota   = "press"
	}
}

-- ------------------------------------------------------------
-- НАРЯДЫ ТЕРМИНАЛА (key привязан к recipe.quota; progress через хук)
-- ------------------------------------------------------------
PLUGIN.orders = {
	{
		id = "ration5", name = "Собрать 5 упаковок рационов",
		desc = "Линия снабжения требует упакованные пайки.",
		quota = "ration", need = 5,
		reward = 30, merit = true
	},
	{
		id = "clean3", name = "Очистить 3 фильтра",
		desc = "ГО запросила партию обслуженных фильтров.",
		quota = "clean", need = 3,
		reward = 24, merit = true
	},
	{
		id = "press4", name = "Спрессовать 4 металлоблока",
		desc = "Фабрика цитадельного литья принимает блоки.",
		quota = "press", need = 4,
		reward = 36, merit = true
	},
	{
		id = "sort10", name = "Отсортировать 10 партий вторсырья",
		desc = "Сортировочный конвейер должен работать без остановки.",
		quota = "sort", need = 10,
		reward = 30, merit = true
	}
}

-- ------------------------------------------------------------
-- ХУКИ КВОТА: станок вызывает hook.Run("CWUQuotaProduced", ply, key)
-- ------------------------------------------------------------
if (SERVER) then
	function PLUGIN:CWUQuotaProduced(ply, quotaKey)
		local char = ply:GetCharacter()
		if (!char) then return end
		local active = char:GetData("cwuOrder")
		if (!active or active.done) then return end

		local tpl = self:GetOrder(active.id)
		if (!tpl or tpl.quota != quotaKey) then return end

		active.progress = math.min((active.progress or 0) + 1, tpl.need)
		char:SetData("cwuOrder", active)
		if (active.progress >= tpl.need) then
			ply:Notify("НАРЯД ВЫПОЛНЕН: «" .. tpl.name .. "». Сдайте его в терминале ГСР.")
		else
			ply:Notify(("Наряд «%s»: %d/%d"):format(tpl.name, active.progress, tpl.need))
		end
	end
end

function PLUGIN:GetOrder(id)
	for _, o in ipairs(self.orders) do
		if (o.id == id) then return o end
	end
end

-- ------------------------------------------------------------
-- СЕРВЕР: сеть станка
-- ops c→s: 2 stage {items uid→count}, 3 start {job}, 4 cancel
-- ops s→c: 0 open {ent}, 1 sync {staged, busy, prog, job}
-- ------------------------------------------------------------
if (SERVER) then
	-- Открыть UI (вызывается из entity Use)
	function PLUGIN:OpenWorkbench(ent, ply, benchPlugin)
		ent.cwuOperator = ply
		ent.cwuStaged = ent.cwuStaged or {}
		net.Start("cwuBench")
			net.WriteUInt(0, 4)
			net.WriteEntity(ent)
		net.Send(ply)
		self:SyncWorkbench(ent)
	end

	function PLUGIN:SyncWorkbench(ent)
		local op = ent.cwuOperator
		if (!IsValid(op)) then return end
		net.Start("cwuBench")
			net.WriteUInt(1, 4)
			net.WriteTable(ent.cwuStaged or {})
			net.WriteBool(ent.cwuBusy or false)
			net.WriteFloat(ent.cwuProgress or 0)
			net.WriteString(ent.cwuJob or "")
		net.Send(op)
	end

	-- посчитать в инвентаре по uniqueID
	local function CountByUID(ply, uid)
		local inv = ply:GetCharacter() and ply:GetCharacter():GetInventory()
		if (!inv) then return 0 end
		local n = 0
		for _, item in pairs(inv:GetItems()) do
			if (item.uniqueID == uid) then n = n + 1 end
		end
		return n
	end

	local function ConsumeByUID(ply, uid, count)
		local inv = ply:GetCharacter():GetInventory()
		local left = count
		for _, item in pairs(inv:GetItems()) do
			if (item.uniqueID == uid and left > 0) then
				item:Remove()
				left = left - 1
			end
			if (left <= 0) then break end
		end
		return left <= 0
	end

	net.Receive("cwuBench", function(_, ply)
		local op = net.ReadUInt(4)
		local ent = net.ReadEntity()
		if (!IsValid(ent) or ent:GetClass() != "ix_cwu_workbench") then return end
		if (ent.cwuOperator != ply) then return end
		if (ply:GetPos():DistToSqr(ent:GetPos()) > 250 * 250) then return end

		local char = ply:GetCharacter()
		if (!char) then return end

		if (op == 2) then -- stage uid → +1
			if (ent.cwuBusy) then return end
			local uid = string.sub(net.ReadString(), 1, 40)
			-- uid допускается только если участвует в рецептах
			local valid
			for _, r in pairs(PLUGIN.recipes) do
				if (r.inputs[uid]) then valid = true break end
			end
			if (!valid) then return end
			local staged = ent.cwuStaged
			local cur = staged[uid] or 0
			if (cur + 1 > CountByUID(ply, uid)) then
				ply:Notify("У вас больше нет: " .. (ix.item.list[uid] and ix.item.list[uid].name or uid))
				return
			end
			staged[uid] = cur + 1
			PLUGIN:SyncWorkbench(ent)

		elseif (op == 3) then -- unstage uid → -1
			if (ent.cwuBusy) then return end
			local uid = string.sub(net.ReadString(), 1, 40)
			local staged = ent.cwuStaged
			if ((staged[uid] or 0) > 0) then
				staged[uid] = staged[uid] - 1
				if (staged[uid] == 0) then staged[uid] = nil end
			end
			PLUGIN:SyncWorkbench(ent)

		elseif (op == 5) then -- start job
			if (ent.cwuBusy) then return end
			local jobID = net.ReadString()
			local recipe = PLUGIN.recipes[jobID]
			if (!recipe) then return end

			-- проверка: стейджинг полностью покрывает входы
			local staged = ent.cwuStaged or {}
			for uid, need in pairs(recipe.inputs) do
				if ((staged[uid] or 0) < need) then
					ply:Notify("Не хватает сырья для работы: «" .. recipe.name .. "»")
					return
				end
			end
			-- и реально есть в инвентаре
			for uid, need in pairs(recipe.inputs) do
				if (CountByUID(ply, uid) < need) then
					ply:Notify("Сырьё пропало из инвентаря. Повторите стейджинг.")
					ent.cwuStaged = {}
					PLUGIN:SyncWorkbench(ent)
					return
				end
			end

			-- расходуем
			for uid, need in pairs(recipe.inputs) do
				ConsumeByUID(ply, uid, need)
			end

			ent.cwuBusy = true
			ent.cwuJob = jobID
			ent.cwuProgress = 0
			ent.cwuStaged = {}
			ent:SetNWBool("cwuBusy", true)
			ent:EmitSound("ambient/machines/machine6.wav", 65)
			PLUGIN:SyncWorkbench(ent)

			local dur = recipe.time
			local t0 = CurTime()
			local uidTimer = "cwuBench_" .. ent:EntIndex()
			timer.Create(uidTimer, 0.25, math.ceil(dur / 0.25), function()
				if (!IsValid(ent)) then return end
				local p = math.Clamp((CurTime() - t0) / dur, 0, 1)
				ent.cwuProgress = p
				ent:SetNWFloat("cwuProg", p)
				PLUGIN:SyncWorkbench(ent)

				if (p >= 1) then
					ent.cwuBusy = false
					ent.cwuJob = nil
					ent.cwuProgress = 0
					ent:SetNWBool("cwuBusy", false)
					ent:SetNWFloat("cwuProg", 0)
					ent:EmitSound("buttons/button9.wav", 65)

					if (IsValid(ply) and ply:GetCharacter()) then
						local inv2 = ply:GetCharacter():GetInventory()
						for uidOut, cnt in pairs(recipe.outputs) do
							for _ = 1, cnt do
								if (!inv2:Add(uidOut)) then
									ix.item.Spawn(uidOut, ent:GetPos() + ent:GetUp() * 40)
								end
							end
						end
						ply:GetCharacter():GiveMoney(recipe.tokens)
						ply:Notify(("ГОТОВО: %s — оплата +%d ☼ на CID"):format(recipe.name, recipe.tokens))
						hook.Run("CWUQuotaProduced", ply, recipe.quota)
					end
					PLUGIN:SyncWorkbench(ent)
				end
			end)
		end
	end)

	-- ---------- СЕРВЕР: терминал нарядов ----------
	-- ops c→s: 0 take {orderID}, 1 abandon, 2 complete
	-- op s→c: 0 open {active table or nil}
	function PLUGIN:OpenTerminal(ent, ply)
		local char = ply:GetCharacter()
		if (!char) then return end
		net.Start("cwuTerminal")
			net.WriteUInt(0, 4)
			net.WriteTable(char:GetData("cwuOrder", {}) or {})
		net.Send(ply)
	end

	net.Receive("cwuTerminal", function(_, ply)
		local op = net.ReadUInt(4)
		local char = ply:GetCharacter()
		if (!char) then return end

		-- допуск: рабочий класс или любой гражданин (вилка нарядов — для всех)
		if (op == 0) then -- взять
			local faction = ix.faction.indices[char:GetFaction()]
			if (faction and faction.uniqueID and faction.uniqueID != "citizen"
				and !(ply.AGHasPerm and ply:AGHasPerm("logs"))) then
				return ply:Notify("Терминал нарядов ГСР доступен гражданским.")
			end
			local id = net.ReadString()
			local tpl = PLUGIN:GetOrder(id)
			if (!tpl) then return end
			if (char:GetData("cwuOrder") and !char:GetData("cwuOrder").done) then
				ply:Notify("Сначала завершите текущий наряд.")
				return
			end
			char:SetData("cwuOrder", {id = id, progress = 0})
			ply:Notify("НАРЯД ПРИНЯТ: «" .. tpl.name .. "»")
		elseif (op == 1) then -- отказаться
			char:SetData("cwuOrder", nil)
			ply:Notify("Наряд отменён.")
		elseif (op == 2) then -- сдать
			local active = char:GetData("cwuOrder")
			if (!active) then return end
			local tpl = PLUGIN:GetOrder(active.id)
			if (!tpl) then char:SetData("cwuOrder", nil) return end
			if ((active.progress or 0) < tpl.need) then
				ply:Notify(("Наряд не выполнен: %d/%d"):format(active.progress or 0, tpl.need))
				return
			end
			char:GiveMoney(tpl.reward)
			if (tpl.merit) then
				local inv = char:GetInventory()
				if (!inv:Add("merit_check")) then
					ix.item.Spawn("merit_check", ply:GetPos() + Vector(0, 0, 16))
				end
			end
			char:SetData("cwuOrder", nil)
			ply:Notify(("НАРЯД СДАН: +%d ☼%s"):format(tpl.reward, tpl.merit and " + чек заслуг" or ""))
		end
	end)

	-- ---------- ОЧИСТИТЕЛИ ВОЗДУХА ----------
	PLUGIN.cleaners = PLUGIN.cleaners or {}

	function PLUGIN:RegisterCleaner(ent)
		for _, c in ipairs(self.cleaners) do
			if (c == ent) then return end
		end
		self.cleaners[#self.cleaners + 1] = ent
	end

	function PLUGIN:Tick()
		local now = CurTime()
		if ((self.nextCleanerDecay or 0) > now) then return end
		self.nextCleanerDecay = now + ix.config.Get("cwuCleanerDecay", 600)
		for _, c in ipairs(self.cleaners) do
			if (IsValid(c) and (c:GetNWFloat("cond", 100) > 0)) then
				c:SetNWFloat("cond", math.max(0, c:GetNWFloat("cond", 100) - ix.config.Get("cwuCleanerDrain", 4)))
			end
		end
	end

	-- обслуживание: consume dirty_filter+scrap_parts → cond 100
	function PLUGIN:ServiceCleaner(ent, ply)
		local char = ply:GetCharacter()
		if (!char) then return end
		if (ent.servicing) then return end

		local inv = char:GetInventory()
		local function CountUID(uid)
			local n = 0
			for _, it in pairs(inv:GetItems()) do
				if (it.uniqueID == uid) then n = n + 1 end
			end
			return n
		end
		if (CountUID("dirty_filter") < 1 or CountUID("scrap_parts") < 1) then
			ply:Notify("Для обслуживания нужны: 1× грязный фильтр и 1× отсортированные детали.")
			return
		end

		ent.servicing = true
		ent:EmitSound("ambient/machines/electric_machine.wav", 60)
		net.Start("cwuCleaner")
			net.WriteFloat(ix.config.Get("cwuCleanerServiceTime", 5))
		net.Send(ply)

		timer.Simple(ix.config.Get("cwuCleanerServiceTime", 5), function()
			if (!IsValid(ent)) then return end
			ent.servicing = false
			if (!IsValid(ply) or !ply:GetCharacter()) then return end
			if (ply:GetPos():DistToSqr(ent:GetPos()) > 300 * 300) then return end

			local inv2 = ply:GetCharacter():GetInventory()
			local removedD, removedP = false, false
			for _, it in pairs(inv2:GetItems()) do
				if (!removedD and it.uniqueID == "dirty_filter") then it:Remove() removedD = true continue end
				if (!removedP and it.uniqueID == "scrap_parts") then it:Remove() removedP = true end
			end
			if (!removedD or !removedP) then return end

			ent:SetNWFloat("cond", 100)
			ent:EmitSound("ambient/levels/citadel/pod_open1.wav", 70)
			ply:GetCharacter():GiveMoney(ix.config.Get("cwuCleanerReward", 12))
			ply:Notify(("ОЧИСТИТЕЛЬ ОБСЛУЖЕН: сектор очищен, +%d ☼"):format(ix.config.Get("cwuCleanerReward", 12)))
			hook.Run("CwuCleanerServiced", ply, ent)
		end)
	end

	-- Иммунитет от токсина возле исправного очистителя (вызывается quarantine)
	hook.Add("AGZoneToxinImmune", "CWUCleaner", function(ply, zone)
		local radius = ix.config.Get("cwuCleanerRadius", 1000)
		local r2 = radius * radius
		for _, c in ipairs(PLUGIN.cleaners) do
			if (IsValid(c) and c:GetNWFloat("cond", 0) > 0
				and ply:GetPos():DistToSqr(c:GetPos()) <= r2) then
				return true
			end
		end
	end)
end

-- ------------------------------------------------------------
-- КЛИЕНТ: приём сети
-- ------------------------------------------------------------
if (CLIENT) then
	net.Receive("cwuBench", function()
		local op = net.ReadUInt(4)
		if (op == 0) then
			local ent = net.ReadEntity()
			if (IsValid(ent)) then
				vgui.Create("AGCWUBench").ent = ent
				if (IsValid(ix.gui.agCWUBench)) then ix.gui.agCWUBench.ent = ent end
			end
		elseif (op == 1) then
			if (IsValid(ix.gui.agCWUBench)) then
				ix.gui.agCWUBench:OnSync(net.ReadTable(), net.ReadBool(), net.ReadFloat(), net.ReadString())
			end
		end
	end)

	net.Receive("cwuTerminal", function()
		local op = net.ReadUInt(4)
		if (op == 0) then
			local active = net.ReadTable()
			vgui.Create("AGCWUTerminal").active = (active and active.id) and active or nil
		end
	end)

	net.Receive("cwuCleaner", function()
		local dur = net.ReadFloat()
		ix.ag.Prompt("ОБСЛУЖИВАНИЕ ОЧИСТИТЕЛЯ…", ("%.0f сек — не уходите"):format(dur), function() end)
	end)
end
