-- AGCWUBench — UI станка ГСР: стейджинг сырья, выбор работы, прогресс
local PANEL = {}

function PANEL:Init()
	ix.gui.agCWUBench = self
	local w, h = 780, 560
	self:SetSize(w, h)
	self:Center()
	self:MakePopup()
	self:SetTitle("ГСР // ЦЕХ ПЕРЕРАБОТКИ И СБОРКИ")

	self.staged = {}
	self.busy = false
	self.prog = 0
	self.job = ""

	local plugin = ix.plugin.Get("cwu")
	self.recipes = plugin and plugin.recipes or {}

	-- ===== левая колонка: инвентарь сырья =====
	local leftP = self:Add("Panel")
	leftP:SetPos(10, 44)
	leftP:SetSize(240, h - 90)

	local lt = leftP:Add("DLabel")
	lt:SetText("ВАШЕ СЫРЬЁ")
	lt:SetFont("AG.SmallB")
	lt:SetTextColor(ix.ag.C.textDim)
	lt:SizeToContents()
	lt:SetPos(2, 0)

	self.rawList = leftP:Add("AGScrollPanel")
	self.rawList:SetPos(0, 20)
	self.rawList:SetSize(238, h - 114)

	-- ===== центр: стейджинг =====
	local midP = self:Add("Panel")
	midP:SetPos(258, 44)
	midP:SetSize(250, h - 90)

	local mt = midP:Add("DLabel")
	mt:SetText("ЗАГРУЖЕНО В СТАНОК")
	mt:SetFont("AG.SmallB")
	mt:SetTextColor(ix.ag.C.textDim)
	mt:SizeToContents()
	mt:SetPos(2, 0)

	self.stageList = midP:Add("AGScrollPanel")
	self.stageList:SetPos(0, 20)
	self.stageList:SetSize(248, h - 114)

	-- ===== правая колонка: работы =====
	local rightP = self:Add("Panel")
	rightP:SetPos(516, 44)
	rightP:SetSize(w - 526, h - 90)

	local rt = rightP:Add("DLabel")
	rt:SetText("ТИП РАБОТЫ")
	rt:SetFont("AG.SmallB")
	rt:SetTextColor(ix.ag.C.textDim)
	rt:SizeToContents()
	rt:SetPos(2, 0)

	self.jobList = rightP:Add("AGScrollPanel")
	self.jobList:SetPos(0, 20)
	self.jobList:SetSize(w - 532, h - 200)

	-- прогресс
	self.progBar = rightP:Add("AGProgressBar")
	self.progBar:SetPos(0, h - 92)
	self.progBar:SetSize(w - 560, 24)
	self.progBar:SetLabel("ПРОГРЕСС")
	self.progBar:SetColor(ix.ag.C.amber)
	self.progBar.live = function() return self.prog or 0 end

	-- статусная строка
	self.status = self:Add("DLabel")
	self.status:SetPos(12, h - 40)
	self.status:SetText("ГОТОВ К РАБОТЕ")
	self.status:SetFont("AG.SmallB")
	self.status:SetTextColor(ix.ag.C.green)
	self.status:SizeToContents()

	self:RebuildRaw()
	self:RebuildStage()
	self:RebuildJobs()
end

function PANEL:OnRemove()
	ix.gui.agCWUBench = nil
end

-- ---------- список сырья из инвентаря ----------
function PANEL:RebuildRaw()
	if (!IsValid(self.rawList)) then return end
	self.rawList:Clear()

	local ply = LocalPlayer()
	local inv = ply:GetCharacter() and ply:GetCharacter():GetInventory()
	if (!inv) then return end

	-- uniqueID'ы, участвующие в рецептах
	local wanted = {}
	for _, r in pairs(self.recipes) do
		for uid, _ in pairs(r.inputs) do wanted[uid] = true end
	end

	local byUID = {}
	for _, item in pairs(inv:GetItems()) do
		if (wanted[item.uniqueID]) then
			byUID[item.uniqueID] = byUID[item.uniqueID] or {item = item, n = 0}
			byUID[item.uniqueID].n = byUID[item.uniqueID].n + 1
		end
	end

	for uid, data in pairs(byUID) do
		local row = vgui.Create("DButton")
		row:Dock(TOP)
		row:DockMargin(0, 0, 4, 3)
		row:SetTall(30)
		row:SetText("")
		row.name = data.item:GetName()
		row.n = data.n
		row.Paint = function(r2, rw, rh)
			surface.SetDrawColor(255, 255, 255, r2:IsHovered() and 16 or 6)
			surface.DrawRect(0, 0, rw, rh)
			surface.SetDrawColor(ix.ag.C.green)
			surface.DrawRect(0, 0, 3, rh)
			draw.SimpleText(r2.name, "AG.Small", 10, rh / 2, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("×" .. r2.n .. "  [+] ", "AG.SmallB", rw - 8, rh / 2, ix.ag.C.green, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		row.DoClick = function()
			ix.ag.Click()
			net.Start("cwuBench")
				net.WriteUInt(2, 4) -- stage
				net.WriteEntity(self.ent)
				net.WriteString(uid)
			net.SendToServer()
		end
		self.rawList:AddItem(row)
	end
end

-- ---------- стейджинг ----------
function PANEL:RebuildStage()
	if (!IsValid(self.stageList)) then return end
	self.stageList:Clear()

	local any = false
	for uid, n in pairs(self.staged) do
		any = true
		local itemDef = ix.item.list[uid]
		local row = vgui.Create("DButton")
		row:Dock(TOP)
		row:DockMargin(0, 0, 4, 3)
		row:SetTall(30)
		row:SetText("")
		row.label = (itemDef and itemDef.name or uid) .. " ×" .. n
		row.Paint = function(r2, rw, rh)
			surface.SetDrawColor(ix.ag.C.amber.r, ix.ag.C.amber.g, ix.ag.C.amber.b, r2:IsHovered() and 30 or 14)
			surface.DrawRect(0, 0, rw, rh)
			draw.SimpleText(r2.label, "AG.Small", 10, rh / 2, ix.ag.C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
			draw.SimpleText("[−]", "AG.SmallB", rw - 8, rh / 2, ix.ag.C.amber, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
		end
		row.DoClick = function()
			ix.ag.Click()
			net.Start("cwuBench")
				net.WriteUInt(3, 4) -- unstage
				net.WriteEntity(self.ent)
				net.WriteString(uid)
			net.SendToServer()
		end
		self.stageList:AddItem(row)
	end

	if (!any) then
		local empty = vgui.Create("Panel")
		empty:Dock(TOP)
		empty:SetTall(60)
		empty.Paint = function(_, ew, eh)
			draw.SimpleText("— станок пуст —", "AG.Small", ew / 2, eh / 2, ix.ag.C.textMute, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		self.stageList:AddItem(empty)
	end
end

-- ---------- работы ----------
function PANEL:RebuildJobs()
	if (!IsValid(self.jobList)) then return end
	self.jobList:Clear()

	for id, r in pairs(self.recipes) do
		local card = vgui.Create("Panel")
		card:Dock(TOP)
		card:DockMargin(0, 0, 4, 6)
		card:SetTall(96)
		card.recipe = r
		card.id = id
		card.Paint = function(c, cw, ch)
			local canRun = true
			for uid, need in pairs(c.recipe.inputs) do
				if ((self.staged[uid] or 0) < need) then canRun = false break end
			end
			canRun = canRun and !self.busy

			surface.SetDrawColor(8, 12, 17, 235)
			surface.DrawRect(0, 0, cw, ch)
			local edge = canRun and ix.ag.C.green or ix.ag.C.stroke
			surface.SetDrawColor(edge)
			surface.DrawOutlinedRect(0, 0, cw, ch, 1)
			surface.SetDrawColor(edge.r, edge.g, edge.b, 16)
			surface.DrawRect(0, 0, 4, ch)

			draw.SimpleText(c.recipe.name, "AG.SmallB", 12, 8, canRun and ix.ag.C.green or ix.ag.C.textDim)
			draw.SimpleText(c.recipe.desc, "AG.Tiny", 12, 26, ix.ag.C.text)

			local io = 44
			local line = "ВХОД: "
			for uid, need in pairs(c.recipe.inputs) do
				local def = ix.item.list[uid]
				line = line .. (def and def.name or uid) .. "×" .. need .. "  "
			end
			draw.SimpleText(line, "AG.Tiny", 12, io, ix.ag.C.amber)
			io = io + 13
			line = "ВЫХОД: "
			for uid, cnt in pairs(c.recipe.outputs) do
				local def = ix.item.list[uid]
				line = line .. (def and def.name or uid) .. "×" .. cnt .. "  "
			end
			draw.SimpleText(line, "AG.Tiny", 12, io, ix.ag.C.green)
			draw.SimpleText("+" .. c.recipe.tokens .. " ☼  •  " .. c.recipe.time .. "с", "AG.Tiny", cw - 10, 8, ix.ag.C.textDim, TEXT_ALIGN_RIGHT)
		end

		local run = card:Add("AGButton")
		run:SetText(self.busy and "ЗАНЯТО" or "ЗАПУСТИТЬ")
		run:SetSize(110, 24)
		run:SetPos(math.max(6, self.jobList:GetWide() - 132), 62)
		run:SetVariant("green")
		run.jobID = id
		run.DoClick = function(btn)
			if (self.busy) then return end
			ix.ag.Click()
			net.Start("cwuBench")
				net.WriteUInt(5, 4) -- start
				net.WriteEntity(self.ent)
				net.WriteString(btn.jobID)
			net.SendToServer()
		end
	end
end

function PANEL:OnSync(staged, busy, prog, job)
	self.staged = staged or {}
	self.busy = busy
	self.prog = prog
	self.job = job
	self.prog = prog or 0
	self:RebuildRaw()
	self:RebuildStage()
	self:RebuildJobs()
	if (IsValid(self.status)) then
		self.status:SetText(busy and ("РАБОТА: " .. (self.recipes[job or ""] and self.recipes[job].name or job)) or "ГОТОВ К РАБОТЕ")
		self.status:SetTextColor(busy and ix.ag.C.amber or ix.ag.C.green)
		self.status:SizeToContents()
	end
end

vgui.Register("AGCWUBench", PANEL, "AGFrame")
