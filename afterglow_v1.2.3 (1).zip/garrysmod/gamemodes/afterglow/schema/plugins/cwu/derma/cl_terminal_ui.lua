-- AGCWUTerminal — терминал нарядов ГСР
local PANEL = {}

function PANEL:Init()
	local w, h = 640, 500
	self:SetSize(w, h)
	self:Center()
	self:MakePopup()
	self:SetTitle("ГСР // ТЕРМИНАЛ РАБОЧИХ НАРЯДОВ")

	local plugin = ix.plugin.Get("cwu")
	self.orders = plugin and plugin.orders or {}

	-- активный наряд
	self.activeCard = self:Add("Panel")
	self.activeCard:SetPos(10, 44)
	self.activeCard:SetSize(w - 20, 88)
	self.activeCard.Paint = function(c, cw, ch)
		surface.SetDrawColor(10, 14, 19, 235)
		surface.DrawRect(0, 0, cw, ch)
		surface.SetDrawColor(ix.ag.C.neon)
		surface.DrawOutlinedRect(0, 0, cw, ch, 1)
		local a = self.active
		if (!a) then
			draw.SimpleText("АКТИВНЫХ НАРЯДОВ НЕТ", "AG.MediumB", cw / 2, ch / 2, ix.ag.C.textMute, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return
		end
		local tpl = self:GetTemplate(a.id)
		draw.SimpleText("АКТИВНЫЙ НАРЯД: " .. (tpl and tpl.name or a.id), "AG.SmallB", 12, 10, ix.ag.C.neon)
		local frac = tpl and math.min((a.progress or 0) / tpl.need, 1) or 0
		draw.SimpleText(("%d / %d"):format(a.progress or 0, tpl and tpl.need or 0), "AG.MediumB", cw - 16, 12, ix.ag.C.amber, TEXT_ALIGN_RIGHT)

		-- полоса прогресса
		surface.SetDrawColor(30, 38, 48, 255)
		surface.DrawRect(12, 44, cw - 24, 14)
		surface.SetDrawColor(ix.ag.C.green)
		surface.DrawRect(12, 44, (cw - 24) * frac, 14)
		draw.SimpleText(tpl and tpl.desc or "", "AG.Tiny", 12, 66, ix.ag.C.textDim)
	end

	-- кнопки активного наряда
	self.btns = self:Add("Panel")
	self.btns:SetPos(10, 140)
	self.btns:SetSize(w - 20, 34)

	local complete = self.btns:Add("AGButton")
	complete:SetText("СДАТЬ НАРЯД")
	complete:SetVariant("green")
	complete:SetSize(200, 32)
	complete:SetPos(0, 0)
	complete.DoClick = function()
		ix.ag.Click()
		net.Start("cwuTerminal") net.WriteUInt(2, 4) net.SendToServer()
		self:Remove()
	end

	local abandon = self.btns:Add("AGButton")
	abandon:SetText("ОТКАЗАТЬСЯ")
	abandon:SetVariant("danger")
	abandon:SetSize(160, 32)
	abandon:SetPos(210, 0)
	abandon.DoClick = function()
		ix.ag.Click()
		net.Start("cwuTerminal") net.WriteUInt(1, 4) net.SendToServer()
		self:Remove()
	end

	-- список доступных нарядов
	local lt = self:Add("DLabel")
	lt:SetText("ДОСТУПНЫЕ НАРЯДЫ:")
	lt:SetFont("AG.SmallB")
	lt:SetTextColor(ix.ag.C.textDim)
	lt:SizeToContents()
	lt:SetPos(12, 184)

	self.list = self:Add("AGScrollPanel")
	self.list:SetPos(10, 204)
	self.list:SetSize(w - 20, h - 214)

	for _, o in ipairs(self.orders) do
		local card = self.list:Add("Panel")
		card:Dock(TOP)
		card:DockMargin(0, 0, 6, 6)
		card:SetTall(70)
		card.order = o
		card.Paint = function(c, cw, ch)
			surface.SetDrawColor(8, 12, 17, 235)
			surface.DrawRect(0, 0, cw, ch)
			surface.SetDrawColor(ix.ag.C.combine)
			surface.DrawRect(0, 0, 4, ch)
			draw.SimpleText(c.order.name, "AG.SmallB", 12, 10, ix.ag.C.text)
			draw.SimpleText(c.order.desc, "AG.Tiny", 12, 30, ix.ag.C.textDim)
			draw.SimpleText(("награда: %d ☼%s"):format(c.order.reward, c.order.merit and " + чек заслуг" or ""),
				"AG.Tiny", 12, 48, ix.ag.C.amber)
			draw.SimpleText(("норма: %d"):format(c.order.need), "AG.Tiny", cw - 130, 48, ix.ag.C.textDim)
		end

		local take = card:Add("AGButton")
		take:SetText("ВЗЯТЬ")
		take:SetSize(90, 26)
		take:SetPos(math.max(6, self.list:GetWide() - 108), 10)
		take:SetVariant("primary")
		take.orderID = o.id
		take.DoClick = function(btn)
			ix.ag.Click()
			net.Start("cwuTerminal")
				net.WriteUInt(0, 4)
				net.WriteString(btn.orderID)
			net.SendToServer()
			self:Remove()
		end
	end
end

function PANEL:GetTemplate(id)
	for _, o in ipairs(self.orders) do
		if (o.id == id) then return o end
	end
end

vgui.Register("AGCWUTerminal", PANEL, "AGFrame")
