CLASS.name = "ОВА | Combine Captain"
CLASS.description = "Командир отряда ОВА. Оперативное руководство зачистками, связь с ядром города."
CLASS.faction = FACTION_OVERWATCH
CLASS.isDefault = false
CLASS.models = {"models/combine_super_soldier.mdl"} -- заменить на HL:A Captain
CLASS.loadout = {"weapon_ar2", "weapon_frag"}
CLASS.ammo = {{"ar2", 150}, {"AR2AltFire", 1}}

CLASS_OW_CAPTAIN = CLASS.index
