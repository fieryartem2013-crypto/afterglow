CLASS.name = "ГО | Дивизион HELIX"
CLASS.description = "Медико-стабилизационный дивизион. Полевая медицина, вакцинация от спор Зена, госпиталь."
CLASS.faction = FACTION_CP
CLASS.isDefault = false
CLASS.divisionCode = "HELIX"
CLASS.loadout = {"weapon_stunstick", "weapon_pistol", "weapon_medkit"} -- weapon_medkit: workshop-аддон
CLASS.ammo = {{"pistol", 36}}

CLASS_CP_HELIX = CLASS.index
