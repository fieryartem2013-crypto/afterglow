CLASS.name = "ГО | Дивизион GRID"
CLASS.description = "Инженерный дивизион. Терминалы, силовые поля, сканеры, ликвидация последствий взломов в КЗ."
CLASS.faction = FACTION_CP
CLASS.isDefault = false
CLASS.divisionCode = "GRID"
CLASS.loadout = {"weapon_stunstick", "weapon_pistol"}
CLASS.ammo = {{"pistol", 18}}

CLASS_CP_GRID = CLASS.index
