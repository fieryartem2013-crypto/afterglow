CLASS.name = "ОВА | Combine Charger"
CLASS.description = "Тяжёлый штурмовик с дробовиком и штурмовым щитом (щит — workshop-аддон)."
CLASS.faction = FACTION_OVERWATCH
CLASS.isDefault = false
CLASS.models = {"models/combine_super_soldier.mdl"} -- заменить на HL:A Charger/Heavy
CLASS.loadout = {"weapon_shotgun"}
CLASS.ammo = {{"buckshot", 24}}

CLASS_OW_CHARGER = CLASS.index
