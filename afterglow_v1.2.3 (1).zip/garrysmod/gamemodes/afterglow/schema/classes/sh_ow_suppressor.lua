CLASS.name = "ОВА | Combine Suppressor"
CLASS.description = "Подавитель. Тяжёлая импульсная платформа, сдерживание биомассы и беспорядков."
CLASS.faction = FACTION_OVERWATCH
CLASS.isDefault = false
CLASS.models = {"models/combine_soldier_prisonguard.mdl"} -- заменить на HL:A Suppressor
CLASS.loadout = {"weapon_ar2"}
CLASS.ammo = {{"ar2", 120}}

CLASS_OW_SUPPRESSOR = CLASS.index
