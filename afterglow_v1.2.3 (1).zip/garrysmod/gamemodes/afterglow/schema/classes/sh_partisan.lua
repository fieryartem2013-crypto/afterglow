CLASS.name = "Партизан"
CLASS.description = "Боец ячейки. Край КЗ, диверсии, конвоирование беженцев из города."
CLASS.faction = FACTION_RESISTANCE
CLASS.isDefault = true
CLASS.loadout = {"weapon_crowbar"}

CLASS_PARTISAN = CLASS.index
