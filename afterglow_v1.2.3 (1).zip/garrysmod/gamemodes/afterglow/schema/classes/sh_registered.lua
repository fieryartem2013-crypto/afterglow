-- Зарегистрированный горожанин. Класс выдаётся ТОЛЬКО через регистрацию
-- (см. plugins/cid: /RegisterCitizen) или персоналом.
CLASS.name = "Зарегистрированный горожанин"
CLASS.description = "Обладатель CID-карты. Рацион лояльности, базовая зарплата токенами, трудовые смены."
CLASS.faction = FACTION_CITIZEN
CLASS.isDefault = false
CLASS.models = {
	"models/humans/group01/male_01.mdl",
	"models/humans/group01/male_02.mdl",
	"models/humans/group01/female_01.mdl",
	"models/humans/group01/female_02.mdl"
}

CLASS_REGISTERED = CLASS.index
