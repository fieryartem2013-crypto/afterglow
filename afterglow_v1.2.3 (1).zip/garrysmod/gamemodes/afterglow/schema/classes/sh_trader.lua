-- Торговец чёрного рынка / КЗ (вайтлист)
CLASS.name = "Торговец КЗ"
CLASS.description = "Выживальщик, торгующий фильтрами, патронами и биоматериалом Зена. Знает все ходы трущоб."
CLASS.faction = FACTION_CITIZEN
CLASS.isDefault = false
CLASS.models = {
	"models/humans/group02/male_06.mdl",
	"models/humans/group02/male_08.mdl",
	"models/humans/group02/female_02.mdl"
}

CLASS_TRADER = CLASS.index
