CLASS.name = "ОВА | Combine Grunt"
CLASS.description = "Базовый пехотинец Карантинной Зоны. Пистолет-пулемёт, зачистка экзогенных очагов."
CLASS.faction = FACTION_OVERWATCH
CLASS.isDefault = true
CLASS.models = {"models/combine_soldier.mdl"} -- заменить на HL:A Grunt модель из Workshop
CLASS.loadout = {"weapon_smg1"}
CLASS.ammo = {{"smg1", 135}, {"smg1_grenade", 1}}

CLASS_OW_GRUNT = CLASS.index
