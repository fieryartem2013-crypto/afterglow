-- Незарегистрированный (Вастлендер) — стартовый статус всех персонажей.
CLASS.name = "Незарегистрированный"
CLASS.description = "Беженец без CID-карты. Минимальный рацион, блоки D-F, постоянный риск рейдов ГО."
CLASS.faction = FACTION_CITIZEN
CLASS.isDefault = true
CLASS.models = {
	"models/humans/group02/male_02.mdl",
	"models/humans/group02/male_04.mdl",
	"models/humans/group02/female_01.mdl",
	"models/humans/group02/female_03.mdl"
}

CLASS_UNREGISTERED = CLASS.index
