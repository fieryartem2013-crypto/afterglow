CLASS.name = "Техник / Взломщик"
CLASS.description = "Кустарные девайсы, перепрошивка техники Альянса, работа на верстаках за смолу."
CLASS.faction = FACTION_RESISTANCE
CLASS.isDefault = false
CLASS.loadout = {"weapon_pistol"}
CLASS.ammo = {{"pistol", 18}}

CLASS_TECHNICIAN = CLASS.index
