CLASS.name = "ГО | Дивизион UNION"
CLASS.description = "Патрульный дивизион. Кварталы, КПП, проверки CID, подавление беспорядков."
CLASS.faction = FACTION_CP
CLASS.isDefault = true
CLASS.divisionCode = "UNION"
CLASS.loadout = {"weapon_stunstick", "weapon_pistol"}
CLASS.ammo = {{"pistol", 36}}

CLASS_CP_UNION = CLASS.index
