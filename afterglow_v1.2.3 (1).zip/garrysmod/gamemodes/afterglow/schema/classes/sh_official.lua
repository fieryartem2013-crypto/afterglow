CLASS.name = "Чиновник администрации"
CLASS.description = "Регистрация, протоколы лояльности, пропагандистские трансляции, распределение рационов."
CLASS.faction = FACTION_ADMINISTRATION
CLASS.isDefault = true

CLASS_OFFICIAL = CLASS.index
