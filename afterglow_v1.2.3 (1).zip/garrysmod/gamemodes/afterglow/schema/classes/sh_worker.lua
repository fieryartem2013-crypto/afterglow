-- Рабочий Гражданской Народной Армии (строительный корпус)
CLASS.name = "Рабочий ГНА"
CLASS.description = "Строитель и наладчик инфраструктуры Цитадели. Оранжевый комбинезон, допуск на стройобъекты."
CLASS.faction = FACTION_CITIZEN
CLASS.isDefault = false
CLASS.models = {
	"models/humans/group03/male_01.mdl",
	"models/humans/group03/male_02.mdl",
	"models/humans/group03/female_01.mdl"
}

CLASS_WORKER = CLASS.index
