CLASS.name = "Освобождённый вортигонт"
CLASS.description = "Победитель орязальных уз. Вортэссенция, целительство, чутьё Зена."
CLASS.faction = FACTION_RESISTANCE
CLASS.isDefault = false
CLASS.models = {"models/vortigaunt.mdl"}
CLASS.loadout = {} -- суть не в оружии; см. /EssenceExtract (plugins/medical)

CLASS_VORTIGAUNT = CLASS.index
