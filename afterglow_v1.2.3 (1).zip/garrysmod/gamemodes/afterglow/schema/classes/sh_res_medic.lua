CLASS.name = "Полевой медик"
CLASS.description = "Хирургия в условиях КЗ, лечение заражения спорами, перегон ворт-эссенции."
CLASS.faction = FACTION_RESISTANCE
CLASS.isDefault = false
CLASS.models = {
	"models/humans/group03m/male_01.mdl",
	"models/humans/group03m/female_01.mdl"
}
CLASS.loadout = {"weapon_medkit"} -- workshop-аддон

CLASS_RES_MEDIC = CLASS.index
