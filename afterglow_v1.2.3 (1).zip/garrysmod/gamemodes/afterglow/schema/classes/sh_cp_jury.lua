CLASS.name = "ГО | Дивизион JURY"
CLASS.description = "Следственный дивизион. Допросы, регистрация граждан, инквизиторские протоколы."
CLASS.faction = FACTION_CP
CLASS.isDefault = false
CLASS.divisionCode = "JURY"
CLASS.loadout = {"weapon_stunstick", "weapon_pistol"}
CLASS.ammo = {{"pistol", 18}}

CLASS_CP_JURY = CLASS.index
