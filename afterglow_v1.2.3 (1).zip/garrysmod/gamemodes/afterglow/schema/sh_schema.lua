-- ============================================================
-- HL:A RP — sh_schema.lua
-- Общая точка входа схемы (shared). Классы/фракции/предметы/
-- плагины подгружаются фреймворком автоматически.
-- ============================================================

Schema.name = "AfterGlow"
Schema.author = "AfterGlow Team"
Schema.description = "Город 17 эпохи строительства Цитадели. Карантинная Зона, ранний Альянс и зарождающееся Сопротивление."

ix.util.Include("cl_schema.lua")
ix.util.Include("sv_schema.lua")

-- ------------------------------------------------------------
-- Валюта: токены
-- ------------------------------------------------------------
if (ix.currency and ix.currency.Set) then
	ix.currency.Set("☼", "токен", "токенов")
end

-- ------------------------------------------------------------
-- Анимации playermodel'ей под классы HL:N анимаций Helix
-- ------------------------------------------------------------
ix.anim.SetModelClass("models/police.mdl", "metrocop")
ix.anim.SetModelClass("models/combine_soldier.mdl", "overwatch")
ix.anim.SetModelClass("models/combine_soldier_prisonguard.mdl", "overwatch")
ix.anim.SetModelClass("models/combine_super_soldier.mdl", "overwatch")
ix.anim.SetModelClass("models/vortigaunt.mdl", "vortigaunt")
-- После установки HL:A модель-паков (Workshop) добавьте сюда их пути:
-- ix.anim.SetModelClass("models/hla/combine_grunt.mdl", "overwatch")

-- ------------------------------------------------------------
-- Константы схемы: индексы фракций заполняются при загрузке
-- (FACTION_CITIZEN и т.д. — глобальные после загрузки factions/)
-- ------------------------------------------------------------

-- Фракции Альянса (нужны плагинам: радио, оповещения, зарплата и пр.)
function Schema:IsCombineFaction(factionIndex)
	return factionIndex == FACTION_CP
		or factionIndex == FACTION_OVERWATCH
		or factionIndex == FACTION_ADMINISTRATION
end

-- Фракции с доступом к боевому оружию с рождения
function Schema:IsMilitaryFaction(factionIndex)
	return factionIndex == FACTION_CP or factionIndex == FACTION_OVERWATCH
end

-- Выбор модели персонажа по классу (детерминированно от ID персонажа,
-- чтобы модель не менялась при каждом спавне)
function Schema:GetClassModel(client)
	local character = client:GetCharacter()
	if (!character) then return end

	local class = ix.class.list[character:GetClass()]
	if (class and class.models and #class.models > 0) then
		return class.models[(character:GetID() % #class.models) + 1]
	end

	return character:GetModel()
end

-- ------------------------------------------------------------
-- Выдача снаряжения: перекрываем стандартный лоадаут Helix
-- ------------------------------------------------------------
function Schema:PlayerLoadout(client)
	client:StripWeapons()
	client:RemoveAllAmmo()

	if (weapons.Get("ix_hands")) then
		client:Give("ix_hands")
	end

	local character = client:GetCharacter()
	if (character) then
		-- Классовая модель (дивизион ГО / тип юнита ОВА / одежда граждан)
		local model = self:GetClassModel(client)
		if (model) then
			character:SetModel(model)
			client:SetModel(model)
			client:SetupHands()
		end

		local class = ix.class.list[character:GetClass()]
		if (class) then
			if (class.loadout) then
				for _, weapon in ipairs(class.loadout) do
					if (weapons.Get(weapon)) then
						client:Give(weapon)
					end
				end
			end

			if (class.ammo) then
				for _, v in ipairs(class.ammo) do
					client:GiveAmmo(v[2], v[1], true)
				end
			end
		end
	end

	return true -- блокируем лоадаут фреймворка по умолчанию
end

-- ------------------------------------------------------------
-- Тюнинг конфигурации Helix при инициализации
-- ------------------------------------------------------------
-- Установить конфиг, только если ключ существует в текущей сборке Helix
local function SafeConfig(key, value)
	if (ix.config.stored and ix.config.stored[key]) then
		ix.config.Set(key, value)
	end
end

function Schema:InitializedConfig()
	-- Скорости/радиусы — «медленное» HL:A RP
	SafeConfig("walkSpeed", 90)
	SafeConfig("runSpeed", 200)
	SafeConfig("voiceDistance", 450)
	SafeConfig("chatRange", 400)
	SafeConfig("weaponRaiseTime", 1)
	SafeConfig("defaultInventoryWeight", 45)   -- переносимый вес инвентаря
	SafeConfig("saveInterval", 300)
	SafeConfig("music", "music/hl2_song19.mp3") -- меню
end

-- AfterGlow v1.1.0: стоковые плагины Helix, заменённые собственными системами
ix.plugin.SetUnloaded("stamina", true)
